import { e as createAstro, f as createComponent, m as maybeRenderHead, r as renderTemplate, s as spreadAttributes, u as unescapeHTML, n as defineScriptVars, k as renderComponent, h as addAttribute, l as renderScript, o as renderSlot } from './astro/server_C-hQQPI9.mjs';
import 'piccolore';
import 'clsx';
import { u as useI18n } from './Footer_BplOwl4A.mjs';
import { $ as $$Container } from './Container_BHgm3nJG.mjs';
/* empty css                         */

const $$Astro$a = createAstro("https://bmg-granite.com");
const $$Hero = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$a, $$props, $$slots);
  Astro2.self = $$Hero;
  useI18n(Astro2.url);
  return renderTemplate`${maybeRenderHead()}<section id="home" class="relative h-screen min-h-[600px] max-h-[800px] pt-20 lg:pt-24"> <!-- Background Video --> <div class="absolute inset-0 z-0"> <video autoplay muted loop playsinline class="w-full h-full object-cover" poster="/images/Landing/HeroSection/background_1.png"> <source src="https://videos.pexels.com/video-files/3129671/3129671-uhd_2560_1440_30fps.mp4" type="video/mp4"> </video> <!-- Purple overlay --> <div class="absolute inset-0 bg-map-blue/20"></div> </div> </section>`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/Hero.astro", void 0);

function createSvgComponent({ meta, attributes, children }) {
  const Component = createComponent((_, props) => {
    const normalizedProps = normalizeProps(attributes, props);
    return renderTemplate`<svg${spreadAttributes(normalizedProps)}>${unescapeHTML(children)}</svg>`;
  });
  Object.defineProperty(Component, "toJSON", {
    value: () => meta,
    enumerable: false
  });
  return Object.assign(Component, meta);
}
const ATTRS_TO_DROP = ["xmlns", "xmlns:xlink", "version"];
const DEFAULT_ATTRS = {};
function dropAttributes(attributes) {
  for (const attr of ATTRS_TO_DROP) {
    delete attributes[attr];
  }
  return attributes;
}
function normalizeProps(attributes, props) {
  return dropAttributes({ ...DEFAULT_ATTRS, ...attributes, ...props });
}

const thumbnail1 = createSvgComponent({"meta":{"src":"/_astro/thumbnail-1.B5g8HyMK.svg","width":200,"height":200,"format":"svg"},"attributes":{"viewBox":"0 0 200 200","fill":"none"},"children":"\n  <defs>\n    <pattern id=\"granite1\" patternUnits=\"userSpaceOnUse\" width=\"20\" height=\"20\">\n      <rect width=\"20\" height=\"20\" fill=\"#374151\" />\n      <circle cx=\"5\" cy=\"5\" r=\"2\" fill=\"#4b5563\" opacity=\"0.6\" />\n      <circle cx=\"15\" cy=\"12\" r=\"1.5\" fill=\"#6b7280\" opacity=\"0.4\" />\n      <circle cx=\"8\" cy=\"16\" r=\"1\" fill=\"#9ca3af\" opacity=\"0.3\" />\n    </pattern>\n  </defs>\n  <rect width=\"200\" height=\"200\" fill=\"url(#granite1)\" />\n  <rect width=\"200\" height=\"200\" fill=\"#1f2937\" opacity=\"0.3\" />\n"});

const thumbnail2 = createSvgComponent({"meta":{"src":"/_astro/thumbnail-2.67qRhDCT.svg","width":200,"height":200,"format":"svg"},"attributes":{"viewBox":"0 0 200 200","fill":"none"},"children":"\n  <defs>\n    <pattern id=\"marble1\" patternUnits=\"userSpaceOnUse\" width=\"40\" height=\"40\">\n      <rect width=\"40\" height=\"40\" fill=\"#f3f4f6\" />\n      <path d=\"M0 20 Q10 15 20 20 T40 20\" stroke=\"#d1d5db\" stroke-width=\"1\" fill=\"none\" opacity=\"0.5\" />\n      <path d=\"M0 30 Q15 25 30 30 T60 30\" stroke=\"#e5e7eb\" stroke-width=\"0.5\" fill=\"none\" opacity=\"0.4\" />\n    </pattern>\n  </defs>\n  <rect width=\"200\" height=\"200\" fill=\"url(#marble1)\" />\n  <rect width=\"200\" height=\"200\" fill=\"#e5e7eb\" opacity=\"0.2\" />\n"});

const thumbnail3 = createSvgComponent({"meta":{"src":"/_astro/thumbnail-3.D8qmQlur.svg","width":200,"height":200,"format":"svg"},"attributes":{"viewBox":"0 0 200 200","fill":"none"},"children":"\n  <defs>\n    <pattern id=\"granite2\" patternUnits=\"userSpaceOnUse\" width=\"25\" height=\"25\">\n      <rect width=\"25\" height=\"25\" fill=\"#78716c\" />\n      <circle cx=\"6\" cy=\"6\" r=\"2.5\" fill=\"#a8a29e\" opacity=\"0.5\" />\n      <circle cx=\"18\" cy=\"10\" r=\"2\" fill=\"#57534e\" opacity=\"0.6\" />\n      <circle cx=\"10\" cy=\"20\" r=\"1.5\" fill=\"#d6d3d1\" opacity=\"0.4\" />\n      <circle cx=\"22\" cy=\"22\" r=\"1\" fill=\"#44403c\" opacity=\"0.5\" />\n    </pattern>\n  </defs>\n  <rect width=\"200\" height=\"200\" fill=\"url(#granite2)\" />\n  <rect width=\"200\" height=\"200\" fill=\"#44403c\" opacity=\"0.2\" />\n"});

var __freeze$1 = Object.freeze;
var __defProp$1 = Object.defineProperty;
var __template$1 = (cooked, raw) => __freeze$1(__defProp$1(cooked, "raw", { value: __freeze$1(cooked.slice()) }));
var _a$1;
const $$Astro$9 = createAstro("https://bmg-granite.com");
const $$Showcase = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$9, $$props, $$slots);
  Astro2.self = $$Showcase;
  const { t } = useI18n(Astro2.url);
  const images = [
    { src: thumbnail1, modelId: "1" },
    { src: thumbnail2, modelId: "2" },
    { src: thumbnail3, modelId: "3" },
    { src: thumbnail1, modelId: "4" },
    { src: thumbnail2, modelId: "5" },
    { src: thumbnail3, modelId: "6" }
  ];
  const placeholderModelUrl = "/models/Buddha.glb";
  const modelsData = {
    "1": t.showcase.models["1"],
    "2": t.showcase.models["2"],
    "3": t.showcase.models["3"],
    "4": t.showcase.models["4"],
    "5": t.showcase.models["5"],
    "6": t.showcase.models["6"]
  };
  return renderTemplate(_a$1 || (_a$1 = __template$1(['<!-- Load Google Model Viewer --><script type="module" src="https://ajax.googleapis.com/ajax/libs/model-viewer/3.5.0/model-viewer.min.js"><\/script> ', '<section id="product" class="py-16 lg:py-24 bg-white"> ', " </section> <script>(function(){", "\n  // DOM Elements\n  const defaultView = document.getElementById('showcase-default');\n  const selectedView = document.getElementById('showcase-selected');\n  const modelName = document.getElementById('model-name');\n  const modelDescription = document.getElementById('model-description');\n  const closeButton = document.getElementById('close-viewer');\n  const thumbnails = document.querySelectorAll('.showcase-thumbnail');\n  const modelViewer = document.getElementById('model-viewer');\n  const modelLoading = document.getElementById('model-loading');\n\n  // Hide loading indicator when model loads\n  if (modelViewer && modelLoading) {\n    modelViewer.addEventListener('load', () => {\n      modelLoading.style.display = 'none';\n    });\n\n    // Also handle progress for immediate feedback\n    modelViewer.addEventListener('progress', (event) => {\n      if (event.detail.totalProgress === 1) {\n        modelLoading.style.display = 'none';\n      }\n    });\n  }\n\n  // Show selected state with model details\n  function showModel(modelId) {\n    const model = modelsData[modelId];\n\n    if (model) {\n      modelName.textContent = model.name;\n      modelDescription.textContent = model.description;\n    }\n\n    // Switch views\n    defaultView.classList.add('hidden');\n    selectedView.classList.remove('hidden');\n  }\n\n  // Return to default state\n  function closeViewer() {\n    selectedView.classList.add('hidden');\n    defaultView.classList.remove('hidden');\n  }\n\n  // Event Listeners - Grid thumbnails\n  thumbnails.forEach(thumb => {\n    thumb.addEventListener('click', () => {\n      const modelId = thumb.getAttribute('data-model-id');\n      showModel(modelId);\n    });\n  });\n\n  // Event Listener - Close button\n  closeButton.addEventListener('click', closeViewer);\n})();<\/script>"])), maybeRenderHead(), renderComponent($$result, "Container", $$Container, {}, { "default": ($$result2) => renderTemplate`  <div id="showcase-default" class="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center"> <!-- Text Content (Default) --> <div> <h2 class="text-4xl lg:text-5xl font-bold text-[#2C266C] mb-6 uppercase"> ${t.mission.title} </h2> <p class="text-gray-600 text-lg leading-relaxed"> ${t.mission.description} </p> </div> <!-- Image Grid (3x2) --> <div class="grid grid-cols-3 gap-4 max-w-lg mx-auto lg:mx-0"> ${images.map((img, index) => renderTemplate`<button type="button"${addAttribute(img.modelId, "data-model-id")} class="showcase-thumbnail group cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#2C266C] focus:ring-offset-2 rounded-[22px] transition-transform hover:scale-105"> <img${addAttribute(img.src.src, "src")}${addAttribute(`${t.showcase.viewModel} ${index + 1}`, "alt")} width="200" height="200" loading="lazy" decoding="async" class="w-full aspect-square rounded-[22px] object-cover"> </button>`)} </div> </div>  <div id="showcase-selected" class="hidden"> <div class="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center"> <!-- Model Details (Left) - Centered vertically --> <div class="text-center lg:text-left"> <h2 id="model-name" class="text-4xl lg:text-5xl font-bold text-[#2C266C] mb-6 uppercase"> <!-- Dynamically updated --> </h2> <p id="model-description" class="text-gray-600 text-lg leading-relaxed"> <!-- Dynamically updated --> </p> </div> <!-- 3D Model Viewer (Right) --> <div class="relative"> <!-- Close Button --> <button id="close-viewer" type="button" class="absolute top-4 right-4 z-10 w-10 h-10 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-lg transition-all hover:scale-110 focus:outline-none focus:ring-2 focus:ring-[#2C266C]"${addAttribute(t.showcase.close, "aria-label")}> <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-700" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"> <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path> </svg> </button> <!-- Model Viewer Container --> <div class="rounded-[22px] overflow-hidden aspect-square"> ${renderComponent($$result2, "model-viewer", "model-viewer", { "id": "model-viewer", "src": placeholderModelUrl, "alt": t.showcase.modelAlt, "camera-controls": true, "disable-zoom": true, "disable-pan": true, "disable-tap": true, "auto-rotate": true, "shadow-intensity": "1", "exposure": "1", "interaction-prompt": "none", "class": "w-full h-full bg-transparent", "style": "--poster-color: transparent; background-color: transparent;", "loading": "eager" }, { "default": () => renderTemplate` <!-- Custom loading indicator (hidden when model loads) --> <div id="model-loading" class="absolute inset-0 flex items-center justify-center pointer-events-none"> <div class="text-center"> <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-[#2C266C] mx-auto mb-2"></div> <p class="text-sm text-gray-600">${t.showcase.loading}</p> </div> </div> ` })} </div> </div> </div> </div> ` }), defineScriptVars({ modelsData }));
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/Showcase.astro", void 0);

const $$Astro$8 = createAstro("https://bmg-granite.com");
const $$Process = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$8, $$props, $$slots);
  Astro2.self = $$Process;
  const { t, isRTL } = useI18n(Astro2.url);
  const steps = [
    {
      number: t.process.steps["1"].number,
      title: t.process.steps["1"].title,
      titleShort: t.process.steps["1"].titleShort,
      description: t.process.steps["1"].description,
      image: "/images/Landing/ProcessImage.jpg"
    },
    {
      number: t.process.steps["2"].number,
      title: t.process.steps["2"].title,
      titleShort: t.process.steps["2"].titleShort,
      description: t.process.steps["2"].description,
      image: "/images/Product/14f34ea2cb60093c0f497dfe6d8813a559d4e77e.png"
    },
    {
      number: t.process.steps["3"].number,
      title: t.process.steps["3"].title,
      titleShort: t.process.steps["3"].titleShort,
      description: t.process.steps["3"].description,
      image: "/images/Product/5699ac09f2407f7415000dada3fa4ccf742d51a6.png"
    },
    {
      number: t.process.steps["4"].number,
      title: t.process.steps["4"].title,
      titleShort: t.process.steps["4"].titleShort,
      description: t.process.steps["4"].description,
      image: "/images/Product/61721bfd3545cc1f28b7d88df67402d03a702c72.png"
    },
    {
      number: t.process.steps["5"].number,
      title: t.process.steps["5"].title,
      titleShort: t.process.steps["5"].titleShort,
      description: t.process.steps["5"].description,
      image: "/images/Product/85bb80af71d14ba9f96b4618f1d257cc7e95d757.png"
    }
  ];
  const icons = [
    // Lightbulb - Initial Idea
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><path d="M9 18h6M10 22h4M12 2a7 7 0 0 0-4 12.9V17a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-2.1A7 7 0 0 0 12 2Z"/></svg>`,
    // Cube - 3D Modeling
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>`,
    // Settings/Cog - CNC
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>`,
    // Hand - Hand Finishing
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><path d="M18 11V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2"/><path d="M14 10V4a2 2 0 0 0-2-2a2 2 0 0 0-2 2v2"/><path d="M10 10.5V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2v8"/><path d="M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15"/></svg>`,
    // Truck - Delivery
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><path d="M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2"/><path d="M15 18h2"/><path d="M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14"/><circle cx="17" cy="18" r="2"/><circle cx="7" cy="18" r="2"/></svg>`
  ];
  return renderTemplate`${maybeRenderHead()}<section id="process" class="py-16 lg:py-24 bg-gray-50" data-astro-cid-gto3gzpn> ${renderComponent($$result, "Container", $$Container, { "data-astro-cid-gto3gzpn": true }, { "default": ($$result2) => renderTemplate`  <h2 class="text-3xl lg:text-4xl font-bold text-center mb-12 lg:mb-16 text-brand-primary uppercase" data-astro-cid-gto3gzpn> ${t.process.title} </h2>  <div class="accordion-container"${addAttribute(isRTL ? "rtl" : "ltr", "dir")} data-astro-cid-gto3gzpn> ${steps.map((step, index) => renderTemplate`<div${addAttribute(["accordion-card", index === 0 && "expanded"], "class:list")}${addAttribute(index, "data-step")} role="button" tabindex="0"${addAttribute(index === 0 ? "true" : "false", "aria-expanded")} data-astro-cid-gto3gzpn> <!-- Background Image --> <img${addAttribute(step.image, "src")}${addAttribute(step.title, "alt")} class="card-bg" loading="lazy" data-astro-cid-gto3gzpn> <!-- Dark overlay for better text readability --> <div class="card-overlay" data-astro-cid-gto3gzpn></div> <!-- Collapsed Content (visible when not expanded) --> <div class="collapsed-content" data-astro-cid-gto3gzpn> <span class="step-number" data-astro-cid-gto3gzpn>${step.number}</span> <span class="step-title-short" data-astro-cid-gto3gzpn>${step.titleShort}</span> <div class="step-icon-container" data-astro-cid-gto3gzpn> <div class="step-icon" data-astro-cid-gto3gzpn>${unescapeHTML(icons[index])}</div> </div> </div> <!-- Expanded Content (visible when expanded) --> <div class="expanded-content" data-astro-cid-gto3gzpn> <div class="expanded-header" data-astro-cid-gto3gzpn> <span class="step-number" data-astro-cid-gto3gzpn>${step.number}</span> <span class="step-title" data-astro-cid-gto3gzpn>${step.title}</span> </div> <div class="description-panel" data-astro-cid-gto3gzpn> <div class="description-icon" data-astro-cid-gto3gzpn>${unescapeHTML(icons[index])}</div> <p class="description-text" data-astro-cid-gto3gzpn>${step.description}</p> </div> </div> </div>`)} </div> ` })} </section>  ${renderScript($$result, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/Process.astro?astro&type=script&index=0&lang.ts")}`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/Process.astro", void 0);

const $$Astro$7 = createAstro("https://bmg-granite.com");
const $$PriceEstimation = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$7, $$props, $$slots);
  Astro2.self = $$PriceEstimation;
  const { t, lang } = useI18n(Astro2.url);
  const stoneImages = {
    aPlusPlus: "/images/26d483a8073164eff5528e49cd44d914e594b8e5.png",
    aPlus: "/images/c267197a2cfe6eb447d0bc2c28a0208a6d93b89e.png",
    a: "/images/a04e88f2456f5503d20950b28dd386f0f8b55b3b.png"
  };
  const detailImages = {
    minimal: "/images/13ba63e01b4af986d598682d96e0f684ab188e70.png",
    refine: "/images/13ba63e01b4af986d598682d96e0f684ab188e70.png",
    // Using minimal as placeholder
    realistic: "/images/e1c52a1a4e99255d1ee041a902eb29a962d3d593.png"
  };
  const tabImages = {
    bust: "/images/13ba63e01b4af986d598682d96e0f684ab188e70.png",
    relief: "/images/e1c52a1a4e99255d1ee041a902eb29a962d3d593.png"
  };
  const stoneData = [
    {
      id: "aPlusPlus",
      image: stoneImages.aPlusPlus,
      name: t.priceEstimation.steps.stoneCategory.grades.aPlusPlus.label
    },
    {
      id: "aPlus",
      image: stoneImages.aPlus,
      name: t.priceEstimation.steps.stoneCategory.grades.aPlus.label
    },
    {
      id: "a",
      image: stoneImages.a,
      name: t.priceEstimation.steps.stoneCategory.grades.a.label
    }
  ];
  const detailData = [
    {
      id: "minimal",
      image: detailImages.minimal,
      name: t.priceEstimation.steps.detailLevel.levels.minimal.label,
      desc: t.priceEstimation.steps.detailLevel.levels.minimal.description
    },
    {
      id: "refine",
      image: detailImages.refine,
      name: t.priceEstimation.steps.detailLevel.levels.refine.label,
      desc: t.priceEstimation.steps.detailLevel.levels.refine.description
    },
    {
      id: "realistic",
      image: detailImages.realistic,
      name: t.priceEstimation.steps.detailLevel.levels.realistic.label,
      desc: t.priceEstimation.steps.detailLevel.levels.realistic.description
    }
  ];
  const materialsLink = lang === "en" ? "/materials" : `/${lang}/materials`;
  return renderTemplate`${maybeRenderHead()}<section class="py-16 lg:py-24 bg-gray-50" id="price-estimation" data-astro-cid-tsywcdjl> ${renderComponent($$result, "Container", $$Container, { "data-astro-cid-tsywcdjl": true }, { "default": async ($$result2) => renderTemplate` <div class="mx-auto max-w-[700px]" data-astro-cid-tsywcdjl> <!-- Section Header --> <div class="text-center mb-8" id="section-header" data-astro-cid-tsywcdjl> <h2 class="text-3xl lg:text-4xl font-bold text-brand-primary mb-4 uppercase" data-astro-cid-tsywcdjl> ${t.priceEstimation.title} </h2> <p class="text-gray-600 text-base lg:text-lg max-w-2xl mx-auto" data-astro-cid-tsywcdjl> ${t.priceEstimation.subtitle} </p> </div> <!-- Main Calculator Card --> <!-- Added mx-auto to center it when width changes --> <div class="bg-white rounded-2xl shadow-xl overflow-hidden mx-auto" data-calculator data-state="initial" id="calculator-container" data-astro-cid-tsywcdjl> <!-- Tab Header --> <div class="flex flex-row border-b border-brand-medium/30 relative h-[200px] sm:h-[300px]" role="tablist" aria-label="Sculpture type" id="tab-container" data-astro-cid-tsywcdjl> <button id="bust-tab" role="tab" aria-selected="false" aria-controls="bust-panel" class="group flex-1 flex flex-col items-center justify-center overflow-hidden bg-[#9b96d3] hover:bg-[#8a85c2] transition-colors duration-300 focus:outline-none relative" data-tab="bust" data-astro-cid-tsywcdjl> <div class="absolute inset-0 group-hover:scale-105 transition-transform duration-500 tab-image-container" data-astro-cid-tsywcdjl> <img${addAttribute(tabImages.bust, "src")} alt="Bust sculpture" class="w-full h-full object-cover" loading="lazy" data-astro-cid-tsywcdjl> <div class="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition-colors tab-overlay" data-astro-cid-tsywcdjl></div> </div> <div class="relative z-10 py-3 px-2 sm:px-6 text-sm sm:text-xl lg:text-3xl font-extrabold text-white uppercase tracking-wider tab-text text-center" data-astro-cid-tsywcdjl> <span class="tab-text-short" data-astro-cid-tsywcdjl>${t.priceEstimation.bust.tabShort}</span> <span class="tab-text-full" data-astro-cid-tsywcdjl>${t.priceEstimation.bust.tab}</span> </div> </button> <button id="relief-tab" role="tab" aria-selected="false" aria-controls="relief-panel" class="group flex-1 flex flex-col items-center justify-center overflow-hidden bg-[#9b96d3] hover:bg-[#8a85c2] transition-colors duration-300 focus:outline-none relative" data-tab="relief" data-astro-cid-tsywcdjl> <div class="absolute inset-0 group-hover:scale-105 transition-transform duration-500 tab-image-container" data-astro-cid-tsywcdjl> <img${addAttribute(tabImages.relief, "src")} alt="Relief sculpture" class="w-full h-full object-cover" loading="lazy" data-astro-cid-tsywcdjl> <div class="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition-colors tab-overlay" data-astro-cid-tsywcdjl></div> </div> <div class="relative z-10 py-3 px-2 sm:px-6 text-sm sm:text-xl lg:text-3xl font-extrabold text-white uppercase tracking-wider tab-text text-center" data-astro-cid-tsywcdjl> <span class="tab-text-short" data-astro-cid-tsywcdjl>${t.priceEstimation.relief.tabShort}</span> <span class="tab-text-full" data-astro-cid-tsywcdjl>${t.priceEstimation.relief.tab}</span> </div> </button> </div> <!-- Calculator Content (hidden until tab selected) --> <!-- Calculator Content (hidden until tab selected) --> <div class="p-6 lg:p-8 space-y-8 opacity-0 hidden" id="calculator-content" data-astro-cid-tsywcdjl> <!-- Step 1: Dimensions --> <div class="space-y-4" data-step="dimensions" data-astro-cid-tsywcdjl> <h3 class="text-base font-normal text-gray-800" data-astro-cid-tsywcdjl> ${t.priceEstimation.steps.dimensions.title} </h3> <!-- Dimension Inputs --> <div class="grid grid-cols-3 gap-4" data-astro-cid-tsywcdjl> <!-- Height --> <div class="space-y-2" data-astro-cid-tsywcdjl> <label for="dimension-height" class="block text-sm text-gray-600" data-astro-cid-tsywcdjl> ${t.priceEstimation.steps.dimensions.height} </label> <input type="number" id="dimension-height" name="height" min="1" max="3000" placeholder="e.g., 600" class="dimension-input w-full h-[50px] px-4 border border-gray-300 rounded-lg text-base focus:outline-none focus:border-brand-primary focus:ring-2 focus:ring-brand-primary/20 transition-colors" data-dimension="height" data-astro-cid-tsywcdjl> <p class="text-xs text-gray-500" data-astro-cid-tsywcdjl>${t.priceEstimation.steps.dimensions.maxHint}</p> </div> <!-- Width --> <div class="space-y-2" data-astro-cid-tsywcdjl> <label for="dimension-width" class="block text-sm text-gray-600" data-astro-cid-tsywcdjl> ${t.priceEstimation.steps.dimensions.width} </label> <input type="number" id="dimension-width" name="width" min="1" max="3000" placeholder="e.g., 450" class="dimension-input w-full h-[50px] px-4 border border-gray-300 rounded-lg text-base focus:outline-none focus:border-brand-primary focus:ring-2 focus:ring-brand-primary/20 transition-colors" data-dimension="width" data-astro-cid-tsywcdjl> <p class="text-xs text-gray-500" data-astro-cid-tsywcdjl>${t.priceEstimation.steps.dimensions.maxHint}</p> </div> <!-- Depth --> <div class="space-y-2" data-astro-cid-tsywcdjl> <label for="dimension-depth" class="block text-sm text-gray-600" data-astro-cid-tsywcdjl> ${t.priceEstimation.steps.dimensions.depth} </label> <input type="number" id="dimension-depth" name="depth" min="1" max="3000" placeholder="e.g., 300" class="dimension-input w-full h-[50px] px-4 border border-gray-300 rounded-lg text-base focus:outline-none focus:border-brand-primary focus:ring-2 focus:ring-brand-primary/20 transition-colors" data-dimension="depth" data-astro-cid-tsywcdjl> <p class="text-xs text-gray-500" data-astro-cid-tsywcdjl>${t.priceEstimation.steps.dimensions.maxHint}</p> </div> </div> <!-- Remark Box --> <div class="bg-[#fff6f6] border-l-4 border-accent-red rounded-r px-3 py-2 sm:px-4 sm:py-3" data-astro-cid-tsywcdjl> <p class="text-xs sm:text-sm text-accent-red" data-astro-cid-tsywcdjl>${unescapeHTML(t.priceEstimation.steps.dimensions.remark)}</p> </div> </div> <!-- Step 2: Stone Category --> <div class="space-y-4" data-step="stone" data-astro-cid-tsywcdjl> <h3 class="text-base font-normal text-gray-800" data-astro-cid-tsywcdjl> ${t.priceEstimation.steps.stoneCategory.title} </h3> <!-- Stone Category Grid --> <div class="grid grid-cols-3 gap-2 sm:gap-4 mb-4 sm:mb-6" data-astro-cid-tsywcdjl> ${stoneData.map((stone) => renderTemplate`<label class="cursor-pointer group relative" data-astro-cid-tsywcdjl> <input type="radio" name="stoneType"${addAttribute(stone.id, "value")} class="peer sr-only" data-astro-cid-tsywcdjl> <div class="
                      bg-white rounded-[14px] sm:rounded-[22px] border-2 border-transparent 
                      p-2 sm:p-4 text-center transition-all duration-300
                      peer-checked:border-[#2C266C] peer-checked:shadow-lg
                      hover:shadow-md h-full flex flex-col justify-between
                    " data-astro-cid-tsywcdjl> <div class="w-full aspect-square bg-gray-100 rounded-[10px] sm:rounded-[18px] mb-2 sm:mb-3 overflow-hidden" data-astro-cid-tsywcdjl> <img${addAttribute(stone.image, "src")}${addAttribute(stone.name, "alt")} class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" data-astro-cid-tsywcdjl> </div> <span class="block text-xs sm:text-base font-medium text-[#2C266C]" data-astro-cid-tsywcdjl> ${stone.name} </span> </div> </label>`)} </div> <!-- Help Box --> <div class="bg-[#fef2f2] border-l-4 border-accent-red rounded-r px-3 py-2 sm:px-4 sm:py-3" data-astro-cid-tsywcdjl> <p class="text-xs sm:text-sm text-[#9f0712]" data-astro-cid-tsywcdjl> <span data-astro-cid-tsywcdjl>${unescapeHTML(t.priceEstimation.steps.stoneCategory.help.split("Visit")[0])}</span> <a${addAttribute(materialsLink, "href")} class="underline hover:no-underline" data-astro-cid-tsywcdjl>Visit our Materials Page</a> ${t.priceEstimation.steps.stoneCategory.help.split("Materials Page")[1]?.replace("</strong>", "") || " to learn more about stone categories and find the right grade for your project."} </p> </div> </div> <!-- Step 3: Detail Level --> <div class="space-y-4" data-step="detail" data-astro-cid-tsywcdjl> <h3 class="text-base font-normal text-gray-800" data-astro-cid-tsywcdjl> ${t.priceEstimation.steps.detailLevel.title} </h3> <!-- Detail Level Cards --> <div class="grid grid-cols-3 gap-2 sm:gap-4 mb-4 sm:mb-6" data-astro-cid-tsywcdjl> ${detailData.map((level) => renderTemplate`<label class="cursor-pointer group relative" data-astro-cid-tsywcdjl> <input type="radio" name="detailLevel"${addAttribute(level.id, "value")} class="peer sr-only" data-astro-cid-tsywcdjl> <div class="
                      bg-white rounded-[14px] sm:rounded-[22px] border-2 border-transparent 
                      p-2 sm:p-4 text-center transition-all duration-300
                      peer-checked:border-[#2C266C] peer-checked:shadow-lg
                      hover:shadow-md h-full flex flex-col justify-between
                    " data-astro-cid-tsywcdjl> <div class="w-full aspect-square bg-gray-100 rounded-[10px] sm:rounded-[18px] mb-2 sm:mb-3 overflow-hidden" data-astro-cid-tsywcdjl> <img${addAttribute(level.image, "src")}${addAttribute(level.name, "alt")} class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" data-astro-cid-tsywcdjl> </div> <span class="block text-xs sm:text-base font-medium text-[#2C266C] mb-0.5 sm:mb-1" data-astro-cid-tsywcdjl> ${level.name} </span> <span class="block text-[10px] sm:text-sm text-gray-500 leading-tight line-clamp-2" data-astro-cid-tsywcdjl> ${level.desc} </span> </div> </label>`)} </div> </div> <!-- Calculate Button --> <button type="button" id="calculate-btn" disabled class="w-full h-14 rounded-lg text-base font-normal transition-all duration-300 bg-gray-300 text-gray-500 cursor-not-allowed disabled:bg-gray-300 disabled:text-gray-500 disabled:cursor-not-allowed enabled:bg-brand-primary enabled:text-white enabled:cursor-pointer enabled:hover:bg-brand-primary/90 flex items-center justify-center gap-2" data-calculate data-astro-cid-tsywcdjl> <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true" data-astro-cid-tsywcdjl> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" data-astro-cid-tsywcdjl></path> </svg> <span data-astro-cid-tsywcdjl>${t.priceEstimation.calculateButton}</span> </button> <!-- Price Result (Hidden initially) --> <div id="price-result" class="hidden mt-6 p-6 bg-brand-primary rounded-lg text-center" aria-live="polite" data-astro-cid-tsywcdjl> <p class="text-white/80 text-sm mb-2" data-astro-cid-tsywcdjl>${t.priceEstimation.estimatedPrice}</p> <p id="price-value" class="text-4xl font-bold text-white mb-2" data-astro-cid-tsywcdjl>$0.00</p> <p class="text-white/60 text-xs" data-astro-cid-tsywcdjl>${t.priceEstimation.priceDisclaimer}</p> </div> <!-- Contact CTA --> <div class="text-center pt-4" data-astro-cid-tsywcdjl> <a href="#contact" class="inline-block px-8 py-3 bg-bmg-gold text-white font-semibold rounded-lg hover:bg-bmg-gold/90 transition-colors" data-astro-cid-tsywcdjl> ${t.priceEstimation.getCustomQuote} </a> </div> </div> </div> </div> ` })} </section> ${renderScript($$result, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/PriceEstimation.astro?astro&type=script&index=0&lang.ts")} `;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/PriceEstimation.astro", void 0);

const $$Astro$6 = createAstro("https://bmg-granite.com");
const $$StatItem = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$6, $$props, $$slots);
  Astro2.self = $$StatItem;
  const { value, label } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div class="text-center"> <div class="text-lg sm:text-2xl font-medium text-black leading-[150%] mb-2">${value}</div> <div class="text-[10px] sm:text-base font-normal text-center leading-[150%] text-text-muted whitespace-normal sm:whitespace-nowrap">${label}</div> </div>`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/ui/StatItem.astro", void 0);

const regions = [{"id":"north-america","name":"North America","cx":250,"cy":200,"r":70,"project":{"name":"Empire State Plaza","description":"Premium marble and granite installation for iconic landmark renovation in New York.","image":"https://picsum.photos/128/128?random=1"}},{"id":"mexico","name":"Mexico","cx":195,"cy":310,"r":35,"project":{"name":"Cancun Resort Collection","description":"Natural stone facades for beachfront luxury hospitality venues.","image":"https://picsum.photos/128/128?random=2"}},{"id":"south-america","name":"South America","cx":335,"cy":450,"r":60,"project":{"name":"Sao Paulo Tower","description":"Contemporary granite application for South America's tallest residential building.","image":"https://picsum.photos/128/128?random=3"}},{"id":"uk-ireland","name":"United Kingdom","cx":575,"cy":170,"r":30,"project":{"name":"London Heritage Collection","description":"Restoration-grade limestone for historic preservation projects.","image":"https://picsum.photos/128/128?random=4"}},{"id":"western-europe","name":"Western Europe","cx":600,"cy":230,"r":40,"project":{"name":"Paris Luxury Residences","description":"Elegant marble finishes for high-end European apartments.","image":"https://picsum.photos/128/128?random=5"}},{"id":"central-europe","name":"Central Europe","cx":670,"cy":175,"r":40,"project":{"name":"Berlin Modern Complex","description":"Precision-cut stone for contemporary European architecture.","image":"https://picsum.photos/128/128?random=6"}},{"id":"middle-east","name":"Middle East","cx":765,"cy":320,"r":50,"project":{"name":"Dubai Luxury Towers","description":"Opulent marble and onyx installations for ultra-premium developments.","image":"https://picsum.photos/128/128?random=7"}},{"id":"africa","name":"Africa","cx":660,"cy":420,"r":70,"project":{"name":"Cape Town Luxury Villas","description":"Natural stone installations for exclusive coastal residences.","image":"https://picsum.photos/128/128?random=8"}},{"id":"india","name":"India","cx":870,"cy":330,"r":50,"project":{"name":"Mumbai Sky Gardens","description":"Innovative stone landscaping for vertical garden developments.","image":"https://picsum.photos/128/128?random=9"}},{"id":"east-asia","name":"East Asia","cx":1020,"cy":250,"r":70,"project":{"name":"Tokyo Zen Collection","description":"Minimalist stone designs blending tradition with modernity.","image":"https://picsum.photos/128/128?random=10"}},{"id":"southeast-asia","name":"Southeast Asia","cx":970,"cy":400,"r":40,"project":{"name":"Marina Bay Collection","description":"Sophisticated stone finishes for Singapore's iconic skyline.","image":"https://picsum.photos/128/128?random=11"}},{"id":"oceania","name":"Oceania","cx":1100,"cy":500,"r":70,"project":{"name":"Sydney Harbor Residences","description":"Coastal-inspired stone designs for waterfront living.","image":"https://picsum.photos/128/128?random=12"}}];
const regionsData = {
  regions,
};

const $$InteractiveMap = createComponent(($$result, $$props, $$slots) => {
  const regions = regionsData.regions;
  return renderTemplate`${maybeRenderHead()}<div class="interactive-map-wrapper" data-astro-cid-oreptmz5> <div class="interactive-map-container relative" data-astro-cid-oreptmz5> <!-- Map SVG Container --> <div id="map-svg-container" class="rounded-2xl overflow-hidden relative" data-astro-cid-oreptmz5> <!-- Static map image --> <img id="map-image" src="/images/Landing/Map.svg" alt="World map showing global reach" class="w-full h-auto block" data-astro-cid-oreptmz5> </div> <!-- Project Tooltip --> <div id="map-tooltip" class="absolute pointer-events-none bg-white p-3 rounded-xl shadow-xl opacity-0 transition-all duration-200 z-50 border border-gray-100 max-w-[300px]" style="transform: translate(-50%, -100%); margin-top: -16px;" data-astro-cid-oreptmz5> <div class="flex items-start gap-3" data-astro-cid-oreptmz5> <img id="tooltip-image" class="w-16 h-16 rounded-lg object-cover flex-shrink-0 bg-gray-100" alt="" data-astro-cid-oreptmz5> <div class="min-w-0 flex-1" data-astro-cid-oreptmz5> <div class="flex items-center gap-2 mb-1" data-astro-cid-oreptmz5> <span id="tooltip-region" class="text-xs text-gray-400 truncate" data-astro-cid-oreptmz5></span> </div> <h4 id="tooltip-project-name" class="font-semibold text-sm text-brand-primary leading-tight mb-1" data-astro-cid-oreptmz5></h4> <p id="tooltip-description" class="text-xs text-gray-500 line-clamp-2" data-astro-cid-oreptmz5></p> </div> </div> </div> <!-- Region overlay - circle zones for hover detection with visible indicators --> <svg id="region-overlay" class="absolute top-0 left-0 w-full h-full pointer-events-none" viewBox="0 0 1311 672" preserveAspectRatio="xMidYMid meet" data-astro-cid-oreptmz5> ${regions.map((region) => renderTemplate`<g class="region-group" data-astro-cid-oreptmz5> <!-- Visible indicator dot --> <circle class="region-dot"${addAttribute(region.cx, "cx")}${addAttribute(region.cy, "cy")} r="8" fill="#392DCA" data-astro-cid-oreptmz5></circle> <!-- Invisible hover zone --> <circle class="region-zone pointer-events-auto cursor-pointer"${addAttribute(region.id, "data-region-id")}${addAttribute(region.name, "data-region-name")}${addAttribute(region.project.name, "data-project-name")}${addAttribute(region.project.description, "data-project-description")}${addAttribute(region.project.image, "data-project-image")}${addAttribute(region.cx, "cx")}${addAttribute(region.cy, "cy")}${addAttribute(region.r, "r")} fill="transparent" data-astro-cid-oreptmz5></circle> </g>`)} </svg> </div> </div>  ${renderScript($$result, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/ui/InteractiveMap.astro?astro&type=script&index=0&lang.ts")}`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/ui/InteractiveMap.astro", void 0);

const $$Astro$5 = createAstro("https://bmg-granite.com");
const $$TrustedCultures = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$TrustedCultures;
  const { t } = useI18n(Astro2.url);
  const stats = [
    { value: "24", label: t.trustedCultures.stats.countriesDelivered },
    { value: "24", label: t.trustedCultures.stats.projectsCompleted },
    { value: "30+", label: t.trustedCultures.stats.yearsExperience }
  ];
  return renderTemplate`${maybeRenderHead()}<section id="delivery" class="py-16 lg:py-24 bg-bmg-light"> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"> <!-- Section Header --> <h2 class="text-3xl lg:text-4xl font-bold text-center mb-12 lg:mb-16 text-brand-primary"> ${t.trustedCultures.title} </h2> <!-- Interactive World Map --> <div class="relative max-w-5xl mx-auto mb-12 lg:mb-16"> ${renderComponent($$result, "InteractiveMap", $$InteractiveMap, {})} </div> <!-- Statistics --> <div class="grid grid-cols-3 gap-2 sm:gap-8 max-w-3xl mx-auto"> ${stats.map((stat) => renderTemplate`${renderComponent($$result, "StatItem", $$StatItem, { "value": stat.value, "label": stat.label })}`)} </div> </div> </section>`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/TrustedCultures.astro", void 0);

const $$Astro$4 = createAstro("https://bmg-granite.com");
const $$TestimonialCard = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$TestimonialCard;
  const { name, role, quote, rating = 5 } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div class="testimonial-card bg-white p-6 lg:p-8 rounded-2xl" data-astro-cid-ysasvp6c> <!-- Star Rating --> <div class="flex gap-0.5 mb-4" style="width: 101.002px; height: 17.216px;" data-astro-cid-ysasvp6c> ${Array.from({ length: 5 }).map((_, i) => renderTemplate`<img src="/images/Landing/star.png" alt="Star"${addAttribute(`h-full ${i < rating ? "" : "opacity-30"}`, "class")} style="height: 17.216px; width: auto;" data-astro-cid-ysasvp6c>`)} </div> <!-- Quote --> <p class="testimonial-quote mb-6" data-astro-cid-ysasvp6c> ${quote} </p> <!-- Author --> <div data-astro-cid-ysasvp6c> <p class="testimonial-name" data-astro-cid-ysasvp6c>${name}</p> <p class="testimonial-role" data-astro-cid-ysasvp6c>${role}</p> </div> </div> `;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/ui/TestimonialCard.astro", void 0);

const $$Astro$3 = createAstro("https://bmg-granite.com");
const $$Testimonials = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$Testimonials;
  const { t } = useI18n(Astro2.url);
  const testimonials = [
    {
      name: "Sabo Masties",
      role: "Founder @ Rolex",
      quote: "Yet preference connection unpleasant yet melancholy but end appearance. And excellence partiality estimating terminated day everything.",
      rating: 5
    },
    {
      name: "Sam",
      role: "Founder @ Migelko",
      quote: "Yet preference connection unpleasant yet melancholy but end appearance. And excellence partiality estimating terminated day everything.",
      rating: 5
    },
    {
      name: "Mansur",
      role: "Founder @ Google",
      quote: "Yet preference connection unpleasant yet melancholy but end appearance. And excellence partiality estimating terminated day everything.",
      rating: 5
    },
    {
      name: "Sarah Chen",
      role: "CEO @ TechVentures",
      quote: "Yet preference connection unpleasant yet melancholy but end appearance. And excellence partiality estimating terminated day everything.",
      rating: 5
    },
    {
      name: "Michael Brown",
      role: "Director @ Artisan Co",
      quote: "Yet preference connection unpleasant yet melancholy but end appearance. And excellence partiality estimating terminated day everything.",
      rating: 5
    },
    {
      name: "Emma Wilson",
      role: "Partner @ Design Studio",
      quote: "Yet preference connection unpleasant yet melancholy but end appearance. And excellence partiality estimating terminated day everything.",
      rating: 5
    }
  ];
  return renderTemplate`${maybeRenderHead()}<section id="about" class="py-16 lg:py-24 bg-white" data-astro-cid-dnksfipb> ${renderComponent($$result, "Container", $$Container, { "maxWidth": "screen-2xl", "data-astro-cid-dnksfipb": true }, { "default": ($$result2) => renderTemplate`  <div class="text-center mb-8 lg:mb-16 max-w-2xl mx-auto" data-astro-cid-dnksfipb> <h2 class="text-2xl lg:text-4xl font-bold mb-4 uppercase text-brand-primary" style="font-family: 'Montserrat', sans-serif;" data-astro-cid-dnksfipb> ${t.testimonials.title} </h2> <p class="text-gray-600" style="font-family: 'Montserrat', sans-serif;" data-astro-cid-dnksfipb> ${t.testimonials.description} </p> </div>  <div class="relative" data-astro-cid-dnksfipb> <!-- Blue Background Block --> <div class="blue-background-block absolute left-4 right-4 lg:left-6 lg:right-6 bg-brand-primary" data-astro-cid-dnksfipb></div> <!-- Carousel Wrapper --> <div class="relative carousel-wrapper" data-astro-cid-dnksfipb> <!-- Testimonials Carousel --> <div class="testimonials-carousel px-2 lg:px-0" data-astro-cid-dnksfipb> <div class="testimonials-track flex items-center transition-transform duration-500 ease-in-out" id="testimonials-track" data-astro-cid-dnksfipb> ${testimonials.map((testimonial, index) => renderTemplate`<div class="testimonial-slide flex-shrink-0 w-full md:w-1/2 lg:w-1/3 px-3" data-astro-cid-dnksfipb> ${renderComponent($$result2, "TestimonialCard", $$TestimonialCard, { "name": testimonial.name, "role": testimonial.role, "quote": testimonial.quote, "rating": testimonial.rating, "data-astro-cid-dnksfipb": true })} </div>`)} </div> </div> <!-- Navigation Arrows --> <div class="flex justify-center mt-4 pb-8 relative z-10" data-astro-cid-dnksfipb> <div class="nav-controls inline-flex bg-white rounded-xl overflow-hidden shadow-lg p-1" data-astro-cid-dnksfipb> <!-- Left Arrow Button --> <button id="prev-btn" class="nav-arrow-btn left-arrow w-12 h-12 flex items-center justify-center transition-all duration-300"${addAttribute(t.testimonials.prevButton, "aria-label")} disabled data-astro-cid-dnksfipb> <img src="/images/Landing/arrow.svg" alt="Previous" class="nav-arrow-img w-5 h-auto rotate-180" id="prev-arrow-img" data-astro-cid-dnksfipb> </button> <!-- Right Arrow Button --> <button id="next-btn" class="nav-arrow-btn right-arrow w-12 h-12 flex items-center justify-center rounded-lg transition-all duration-300 bg-accent-red"${addAttribute(t.testimonials.nextButton, "aria-label")} data-astro-cid-dnksfipb> <img src="/images/Landing/arrow.svg" alt="Next" class="nav-arrow-img w-5 h-auto" id="next-arrow-img" data-astro-cid-dnksfipb> </button> </div> </div> </div> </div> ` })} </section>  ${renderScript($$result, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/Testimonials.astro?astro&type=script&index=0&lang.ts")}`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/Testimonials.astro", void 0);

const $$Astro$2 = createAstro("https://bmg-granite.com");
const $$Button = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$Button;
  const {
    variant = "primary",
    size = "md",
    href,
    type = "button",
    class: className = ""
  } = Astro2.props;
  const baseClasses = "inline-flex items-center justify-center font-medium rounded-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2";
  const variantClasses = {
    primary: "bg-bmg-primary text-white hover:bg-bmg-secondary focus:ring-bmg-primary",
    secondary: "bg-bmg-gold text-white hover:bg-amber-600 focus:ring-bmg-gold",
    outline: "border-2 border-bmg-primary text-bmg-primary hover:bg-bmg-primary hover:text-white focus:ring-bmg-primary",
    process: "bg-brand-primary text-white hover:bg-brand-primary-hover focus:ring-brand-primary"
  };
  const sizeClasses = {
    sm: "px-4 py-2 text-sm",
    md: "px-6 py-3 text-base",
    lg: "px-8 py-4 text-lg"
  };
  const classes = `${baseClasses} ${variantClasses[variant]} ${sizeClasses[size]} ${className}`;
  return renderTemplate`${href ? renderTemplate`${maybeRenderHead()}<a${addAttribute(href, "href")}${addAttribute(classes, "class")}>${renderSlot($$result, $$slots["default"])}</a>` : renderTemplate`<button${addAttribute(type, "type")}${addAttribute(classes, "class")}>${renderSlot($$result, $$slots["default"])}</button>`}`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/ui/Button.astro", void 0);

const $$Astro$1 = createAstro("https://bmg-granite.com");
const $$FormField = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$FormField;
  const {
    type,
    label,
    name,
    placeholder = "",
    required = false,
    rows = 4,
    maxLength,
    pattern,
    validationType,
    options = [],
    selectPlaceholder = "Please Select...",
    class: className = ""
  } = Astro2.props;
  const getValidationType = () => {
    if (validationType) return validationType;
    if (type === "email") return "email";
    if (type === "tel" || type === "phone") return "phone";
    if (type === "url") return "url";
    if (type === "select") return "select";
    return "text";
  };
  const isPhoneWithCountry = type === "phone";
  const isSelect = type === "select";
  const isTextarea = type === "textarea";
  const countryCodes = [
    { code: "+66", country: "Thailand" },
    { code: "+1", country: "USA/Canada" },
    { code: "+44", country: "UK" },
    { code: "+86", country: "China" },
    { code: "+91", country: "India" },
    { code: "+81", country: "Japan" },
    { code: "+82", country: "South Korea" },
    { code: "+65", country: "Singapore" },
    { code: "+971", country: "UAE" },
    { code: "+966", country: "Saudi Arabia" },
    { code: "+61", country: "Australia" },
    { code: "+49", country: "Germany" },
    { code: "+33", country: "France" }
  ];
  const normalizedOptions = options.map(
    (opt) => typeof opt === "string" ? { value: opt, label: opt } : opt
  );
  const baseInputClasses = "w-full px-3 rounded-md border border-border bg-white focus:ring-2 focus:ring-bmg-primary focus:border-transparent outline-none transition-all duration-200 text-gray-900 placeholder-gray-500";
  const inputClasses = `${baseInputClasses} h-[50px] flex flex-col justify-center items-start gap-3`;
  const textareaClasses = `${baseInputClasses} py-3 flex flex-col justify-start items-start gap-3`;
  const selectClasses = `${inputClasses} appearance-none cursor-pointer bg-[url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e")] bg-[length:1.5em_1.5em] bg-[right_0.5rem_center] bg-no-repeat pr-10`;
  const phoneSelectClasses = `h-[50px] px-3 border-r border-border bg-white focus:ring-2 focus:ring-bmg-primary focus:outline-none transition-all duration-200 text-gray-900 appearance-none cursor-pointer bg-[url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e")] bg-[length:1em_1em] bg-[right_0.25rem_center] bg-no-repeat pr-6`;
  const phoneInputClasses = "flex-1 h-[50px] px-3 bg-white focus:ring-2 focus:ring-bmg-primary focus:outline-none transition-all duration-200 text-gray-900 placeholder-gray-500";
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(["form-field space-y-2", className], "class:list")} data-form-field${addAttribute(name, "data-field-name")}${addAttribute(getValidationType(), "data-validation-type")}${addAttribute(required.toString(), "data-required")} data-astro-cid-p46g2kvx> <label${addAttribute(name, "for")} class="block text-sm font-medium text-gray-900" data-astro-cid-p46g2kvx> ${label} ${required && renderTemplate`<span class="text-red-500" data-astro-cid-p46g2kvx>*</span>`} </label> ${isPhoneWithCountry ? renderTemplate`<!-- Phone input with country code selector -->
    <div class="flex rounded-md border border-border bg-white overflow-hidden" data-phone-wrapper data-astro-cid-p46g2kvx> <select${addAttribute(`${name}-country`, "id")}${addAttribute(`${name}-country`, "name")}${addAttribute(phoneSelectClasses, "class")} aria-label="Country code" data-country-select data-astro-cid-p46g2kvx> ${countryCodes.map(({ code, country }) => renderTemplate`<option${addAttribute(code, "value")}${addAttribute(country, "title")} data-astro-cid-p46g2kvx>${code}</option>`)} </select> <input type="tel"${addAttribute(name, "id")}${addAttribute(name, "name")}${addAttribute(placeholder || label, "placeholder")}${addAttribute(required, "required")}${addAttribute(phoneInputClasses, "class")} inputmode="tel" autocomplete="tel" data-input data-astro-cid-p46g2kvx> </div>` : isSelect ? renderTemplate`<!-- Select dropdown -->
    <select${addAttribute(name, "id")}${addAttribute(name, "name")}${addAttribute(required, "required")}${addAttribute(selectClasses, "class")} data-input data-astro-cid-p46g2kvx> <option value="" disabled selected data-astro-cid-p46g2kvx>${selectPlaceholder}</option> ${normalizedOptions.map((opt) => renderTemplate`<option${addAttribute(opt.value, "value")} data-astro-cid-p46g2kvx>${opt.label}</option>`)} </select>` : isTextarea ? renderTemplate`<!-- Textarea -->
    <textarea${addAttribute(name, "id")}${addAttribute(name, "name")}${addAttribute(rows, "rows")}${addAttribute(placeholder || label, "placeholder")}${addAttribute(required, "required")}${addAttribute(maxLength, "maxlength")}${addAttribute(textareaClasses, "class")} data-input data-astro-cid-p46g2kvx></textarea>` : renderTemplate`<!-- Standard input (text, email, tel, url) -->
    <input${addAttribute(type === "phone" ? "tel" : type, "type")}${addAttribute(name, "id")}${addAttribute(name, "name")}${addAttribute(placeholder || label, "placeholder")}${addAttribute(required, "required")}${addAttribute(maxLength, "maxlength")}${addAttribute(pattern, "pattern")}${addAttribute(inputClasses, "class")} data-input data-astro-cid-p46g2kvx>`} <p class="form-field__error text-xs text-red-500 mt-1 hidden" data-error-message aria-live="polite" data-astro-cid-p46g2kvx></p> </div> `;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/ui/FormField.astro", void 0);

function parseCommaSeparated(value, defaultValue = []) {
  return defaultValue;
}
function parseSocials(value, defaultSocials2) {
  return defaultSocials2;
}
const defaultAddress = [
  "9/11 Moo 10 Borommaratchachonnani rd",
  "Sala Thammasop Thawi Watthana",
  "Bangkok 10170"
];
const defaultPhones = ["+66 2 888 7788", "+66 87 879 6226", "+66 81 445 9999"];
const defaultEmail = "bmgthai@bmg.co.th";
const defaultSocials = [
  {
    name: "Facebook",
    handle: "BMG บางกอกโมเดิร์นแกรนิต",
    url: "https://www.facebook.com/bmgthailand",
    icon: "facebook"
  },
  {
    name: "Line",
    handle: "@bmgstone",
    url: "https://page.line.me/bmgstone?openQrModal=true",
    icon: "line"
  },
  {
    name: "Instagram",
    handle: "bangkokmoderngranite",
    url: "https://www.instagram.com/bangkokmoderngranite",
    icon: "instagram"
  },
  {
    name: "YouTube",
    handle: "bmgthai granite",
    url: "https://www.youtube.com/channel/UC9FCyP3XZHRkvK9vnnh8IMg",
    icon: "youtube"
  }
];
function getContactConfig() {
  return {
    address: parseCommaSeparated(
      undefined                               ,
      defaultAddress
    ),
    phone: parseCommaSeparated(
      undefined                              ,
      defaultPhones
    ),
    email: defaultEmail,
    socials: parseSocials(
      undefined                               ,
      defaultSocials
    )
  };
}
const contactConfig = getContactConfig();

const positions = ["salesManager","projectManager","designer","architect","developer","other"];
const projectTypes = ["residential","commercial","industrial","hospitality","publicSpace","other"];
const budgetRanges = ["under10k","10kTo50k","50kTo100k","100kTo500k","over500k"];
const considerations = ["quality","price","timeline","design","allOfTheAbove"];
const timelines = ["immediate","within1Month","1To3Months","3To6Months","6PlusMonths"];
const formOptionsConfig = {
  positions,
  projectTypes,
  budgetRanges,
  considerations,
  timelines,
};

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(raw || cooked.slice()) }));
var _a;
const $$Astro = createAstro("https://bmg-granite.com");
const $$Contact = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Contact;
  const { t } = useI18n(Astro2.url);
  const contactInfo = contactConfig;
  const positions = formOptionsConfig.positions.map(
    (key) => t.contact.positions[key]
  );
  const projectTypes = formOptionsConfig.projectTypes.map(
    (key) => t.contact.projectTypes[key]
  );
  const budgetRanges = formOptionsConfig.budgetRanges.map(
    (key) => t.contact.budgetRanges[key]
  );
  const considerations = formOptionsConfig.considerations.map(
    (key) => t.contact.considerations[key]
  );
  const timelines = formOptionsConfig.timelines.map(
    (key) => t.contact.timelines[key]
  );
  const validationTranslations = JSON.stringify({
    required: t.validation?.required || "This field is required",
    invalidEmail: t.validation?.invalidEmail || "Please enter a valid email address",
    invalidPhone: t.validation?.invalidPhone || "Please enter a valid phone number (7-15 digits)",
    invalidUrl: t.validation?.invalidUrl || "Please enter a valid URL (including http:// or https://)",
    invalidName: t.validation?.invalidName || "Please enter a valid name (letters only)",
    tooShort: t.validation?.tooShort || "This field is too short",
    tooLong: t.validation?.tooLong || "This field is too long",
    invalidFormat: t.validation?.invalidFormat || "Invalid format",
    formSuccess: t.validation?.formSuccess || "Thank you! Your message has been sent successfully.",
    formError: t.validation?.formError || "There was an error submitting your form. Please try again.",
    submitting: t.validation?.submitting || "Submitting..."
  });
  return renderTemplate(_a || (_a = __template(["", '<section id="contact" class="py-16 lg:py-24 bg-white"> ', " </section> <script>(function(){", `
  // Parse translations from server
  const translations = JSON.parse(validationTranslations);

  // ============================================
  // CSRF TOKEN GENERATION
  // ============================================

  const CSRF_TOKEN_KEY = 'bmg_csrf_token';
  const TOKEN_EXPIRY_MS = 30 * 60 * 1000; // 30 minutes

  function generateSecureToken(length = 32) {
    const array = new Uint8Array(length);
    crypto.getRandomValues(array);
    return Array.from(array, (byte) => byte.toString(16).padStart(2, '0')).join('');
  }

  function generateCSRFToken() {
    try {
      const stored = sessionStorage.getItem(CSRF_TOKEN_KEY);
      if (stored) {
        const tokenData = JSON.parse(stored);
        if (tokenData.expiresAt > Date.now()) {
          return tokenData.token;
        }
      }
    } catch (e) {
      // Ignore parsing errors
    }

    // Generate new token
    const token = generateSecureToken();
    const tokenData = {
      token,
      timestamp: Date.now(),
      expiresAt: Date.now() + TOKEN_EXPIRY_MS,
    };

    try {
      sessionStorage.setItem(CSRF_TOKEN_KEY, JSON.stringify(tokenData));
    } catch (e) {
      // Ignore storage errors
    }

    return token;
  }

  // ============================================
  // VALIDATION PATTERNS
  // ============================================

  const VALIDATION_PATTERNS = {
    email: /^[a-zA-Z0-9](?:[a-zA-Z0-9._%+-]*[a-zA-Z0-9])?@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\\.[a-zA-Z]{2,})+$/,
    phone: /^[\\d\\s\\-()]+$/,
    name: /^[\\p{L}\\p{M}][\\p{L}\\p{M}\\s\\-']*[\\p{L}\\p{M}]$|^[\\p{L}\\p{M}]$/u,
  };

  // ============================================
  // SANITIZATION FUNCTIONS
  // ============================================

  const HTML_ENTITIES = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#x27;',
    '/': '&#x2F;',
    '\`': '&#x60;',
    '=': '&#x3D;',
  };

  function sanitizeHTML(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/[&<>"'\`=/]/g, (char) => HTML_ENTITIES[char] || char);
  }

  function stripHTMLTags(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/<[^>]*>/g, '');
  }

  function sanitizeForDisplay(input) {
    if (typeof input !== 'string') return '';
    return sanitizeHTML(stripHTMLTags(input));
  }

  function sanitizePhone(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/[^\\d+\\-() ]/g, '').trim();
  }

  function sanitizeEmail(input) {
    if (typeof input !== 'string') return '';
    return input.toLowerCase().trim();
  }

  function sanitizeName(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/[^\\p{L}\\p{M}\\s\\-']/gu, '').trim();
  }

  // ============================================
  // VALIDATION FUNCTIONS
  // ============================================

  function validateRequired(value) {
    const trimmed = value?.trim() || '';
    return {
      isValid: trimmed.length > 0,
      error: trimmed.length > 0 ? undefined : translations.required,
    };
  }

  function validateEmail(value) {
    if (!value || value.trim() === '') return { isValid: true };
    const sanitized = sanitizeEmail(value);
    const isValid = VALIDATION_PATTERNS.email.test(sanitized);
    return {
      isValid,
      error: isValid ? undefined : translations.invalidEmail,
    };
  }

  function validatePhone(value) {
    if (!value || value.trim() === '') return { isValid: true };
    const sanitized = sanitizePhone(value);
    if (!VALIDATION_PATTERNS.phone.test(sanitized)) {
      return { isValid: false, error: translations.invalidPhone };
    }
    const digitsOnly = sanitized.replace(/\\D/g, '');
    const isValidLength = digitsOnly.length >= 7 && digitsOnly.length <= 15;
    return {
      isValid: isValidLength,
      error: isValidLength ? undefined : translations.invalidPhone,
    };
  }

  function validateName(value) {
    if (!value || value.trim() === '') return { isValid: true };
    const sanitized = sanitizeName(value);
    const isValid = VALIDATION_PATTERNS.name.test(sanitized) && sanitized.length >= 1;
    return {
      isValid,
      error: isValid ? undefined : translations.invalidName,
    };
  }

  function validateMaxLength(value, maxLength) {
    const length = value?.length || 0;
    const isValid = length <= maxLength;
    return {
      isValid,
      error: isValid ? undefined : translations.tooLong,
    };
  }

  // ============================================
  // FORM VALIDATION
  // ============================================

  function validateField(fieldElement) {
    const fieldName = fieldElement.dataset.fieldName || '';
    const validationType = fieldElement.dataset.validationType || 'text';
    const isRequired = fieldElement.dataset.required === 'true';
    const input = fieldElement.querySelector('[data-input]');
    const errorMessage = fieldElement.querySelector('[data-error-message]');

    if (!input) return { isValid: true };

    const value = input.value;
    let result = { isValid: true };

    // Check required first
    if (isRequired) {
      result = validateRequired(value);
      if (!result.isValid) {
        showError(fieldElement, errorMessage, result.error || '');
        return result;
      }
    }

    // If empty and not required, it's valid
    if (!value || value.trim() === '') {
      clearError(fieldElement, errorMessage);
      return { isValid: true };
    }

    // Type-specific validation
    switch (validationType) {
      case 'email':
        result = validateEmail(value);
        break;
      case 'phone':
        result = validatePhone(value);
        break;
      case 'name':
        result = validateName(value);
        break;
      case 'text':
        result = validateMaxLength(value, 2000);
        break;
      case 'select':
        result = { isValid: true };
        break;
    }

    if (result.isValid) {
      showValid(fieldElement, errorMessage);
    } else {
      showError(fieldElement, errorMessage, result.error || '');
    }

    return result;
  }

  function showError(fieldElement, errorMessage, message) {
    fieldElement.classList.remove('is-valid');
    fieldElement.classList.add('has-error');
    if (errorMessage) {
      errorMessage.textContent = message;
    }
  }

  function showValid(fieldElement, errorMessage) {
    fieldElement.classList.remove('has-error');
    fieldElement.classList.add('is-valid');
    if (errorMessage) {
      errorMessage.textContent = '';
    }
  }

  function clearError(fieldElement, errorMessage) {
    fieldElement.classList.remove('has-error', 'is-valid');
    if (errorMessage) {
      errorMessage.textContent = '';
    }
  }

  function validateAllFields(form) {
    const fields = form.querySelectorAll('[data-form-field]');
    let allValid = true;

    fields.forEach((field) => {
      const result = validateField(field);
      if (!result.isValid) {
        allValid = false;
      }
    });

    return allValid;
  }

  function getFormData(form) {
    const formData = new FormData(form);
    const data = {};

    formData.forEach((value, key) => {
      if (typeof value === 'string') {
        switch (key) {
          case 'email':
            data[key] = sanitizeEmail(value);
            break;
          case 'phone':
          case 'whatsapp':
          case 'phone-country':
            data[key] = sanitizePhone(value);
            break;
          case 'firstName':
          case 'surname':
            data[key] = sanitizeName(value);
            break;
          default:
            data[key] = sanitizeForDisplay(value);
        }
      }
    });

    return data;
  }

  function showFormMessage(form, message, type) {
    let messageEl = form.querySelector('[data-form-message]');

    if (!messageEl) {
      messageEl = document.createElement('div');
      messageEl.setAttribute('data-form-message', '');
      messageEl.setAttribute('role', 'alert');
      messageEl.className = 'mt-4 p-4 rounded-md text-sm';
      form.appendChild(messageEl);
    }

    messageEl.textContent = message;
    messageEl.classList.remove('bg-green-50', 'text-green-800', 'bg-red-50', 'text-red-800', 'hidden');

    if (type === 'success') {
      messageEl.classList.add('bg-green-50', 'text-green-800');
    } else {
      messageEl.classList.add('bg-red-50', 'text-red-800');
    }
  }

  // ============================================
  // FORM INITIALIZATION
  // ============================================

  document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('contact-form');
    if (!form) return;

    let isSubmitting = false;

    // Attach blur event listeners for real-time validation
    const fields = form.querySelectorAll('[data-form-field]');
    fields.forEach((field) => {
      const input = field.querySelector('[data-input]');
      if (input) {
        input.addEventListener('blur', () => validateField(field));
        input.addEventListener('input', () => {
          if (field.classList.contains('has-error')) {
            validateField(field);
          }
        });
      }
    });

    // Handle form submission
    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      if (isSubmitting) return;

      // Validate all fields
      const isValid = validateAllFields(form);

      if (!isValid) {
        const firstError = form.querySelector('.has-error [data-input]');
        if (firstError) {
          firstError.focus();
        }
        return;
      }

      // Get sanitized form data
      const data = getFormData(form);

      // Show loading state
      isSubmitting = true;
      const submitButton = form.querySelector('button[type="submit"]');
      const originalButtonText = submitButton?.textContent || '';

      if (submitButton) {
        submitButton.disabled = true;
        submitButton.textContent = translations.submitting;
      }

      try {
        // Generate CSRF token
        const csrfToken = generateCSRFToken();

        const response = await fetch('/api/contact', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': csrfToken,
          },
          body: JSON.stringify(data),
        });

        if (response.ok) {
          showFormMessage(form, translations.formSuccess, 'success');
          form.reset();
          // Clear all validation states
          fields.forEach((field) => {
            const errorMessage = field.querySelector('[data-error-message]');
            clearError(field, errorMessage);
          });
        } else {
          const errorData = await response.json().catch(() => ({}));
          showFormMessage(form, errorData.message || translations.formError, 'error');
        }
      } catch (error) {
        console.error('Network error:', error);
        showFormMessage(form, translations.formError, 'error');
      } finally {
        isSubmitting = false;
        if (submitButton) {
          submitButton.disabled = false;
          submitButton.textContent = originalButtonText;
        }
      }
    });
  });
})();<\/script>`], ["", '<section id="contact" class="py-16 lg:py-24 bg-white"> ', " </section> <script>(function(){", `
  // Parse translations from server
  const translations = JSON.parse(validationTranslations);

  // ============================================
  // CSRF TOKEN GENERATION
  // ============================================

  const CSRF_TOKEN_KEY = 'bmg_csrf_token';
  const TOKEN_EXPIRY_MS = 30 * 60 * 1000; // 30 minutes

  function generateSecureToken(length = 32) {
    const array = new Uint8Array(length);
    crypto.getRandomValues(array);
    return Array.from(array, (byte) => byte.toString(16).padStart(2, '0')).join('');
  }

  function generateCSRFToken() {
    try {
      const stored = sessionStorage.getItem(CSRF_TOKEN_KEY);
      if (stored) {
        const tokenData = JSON.parse(stored);
        if (tokenData.expiresAt > Date.now()) {
          return tokenData.token;
        }
      }
    } catch (e) {
      // Ignore parsing errors
    }

    // Generate new token
    const token = generateSecureToken();
    const tokenData = {
      token,
      timestamp: Date.now(),
      expiresAt: Date.now() + TOKEN_EXPIRY_MS,
    };

    try {
      sessionStorage.setItem(CSRF_TOKEN_KEY, JSON.stringify(tokenData));
    } catch (e) {
      // Ignore storage errors
    }

    return token;
  }

  // ============================================
  // VALIDATION PATTERNS
  // ============================================

  const VALIDATION_PATTERNS = {
    email: /^[a-zA-Z0-9](?:[a-zA-Z0-9._%+-]*[a-zA-Z0-9])?@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\\\\.[a-zA-Z]{2,})+$/,
    phone: /^[\\\\d\\\\s\\\\-()]+$/,
    name: /^[\\\\p{L}\\\\p{M}][\\\\p{L}\\\\p{M}\\\\s\\\\-']*[\\\\p{L}\\\\p{M}]$|^[\\\\p{L}\\\\p{M}]$/u,
  };

  // ============================================
  // SANITIZATION FUNCTIONS
  // ============================================

  const HTML_ENTITIES = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#x27;',
    '/': '&#x2F;',
    '\\\`': '&#x60;',
    '=': '&#x3D;',
  };

  function sanitizeHTML(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/[&<>"'\\\`=/]/g, (char) => HTML_ENTITIES[char] || char);
  }

  function stripHTMLTags(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/<[^>]*>/g, '');
  }

  function sanitizeForDisplay(input) {
    if (typeof input !== 'string') return '';
    return sanitizeHTML(stripHTMLTags(input));
  }

  function sanitizePhone(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/[^\\\\d+\\\\-() ]/g, '').trim();
  }

  function sanitizeEmail(input) {
    if (typeof input !== 'string') return '';
    return input.toLowerCase().trim();
  }

  function sanitizeName(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/[^\\\\p{L}\\\\p{M}\\\\s\\\\-']/gu, '').trim();
  }

  // ============================================
  // VALIDATION FUNCTIONS
  // ============================================

  function validateRequired(value) {
    const trimmed = value?.trim() || '';
    return {
      isValid: trimmed.length > 0,
      error: trimmed.length > 0 ? undefined : translations.required,
    };
  }

  function validateEmail(value) {
    if (!value || value.trim() === '') return { isValid: true };
    const sanitized = sanitizeEmail(value);
    const isValid = VALIDATION_PATTERNS.email.test(sanitized);
    return {
      isValid,
      error: isValid ? undefined : translations.invalidEmail,
    };
  }

  function validatePhone(value) {
    if (!value || value.trim() === '') return { isValid: true };
    const sanitized = sanitizePhone(value);
    if (!VALIDATION_PATTERNS.phone.test(sanitized)) {
      return { isValid: false, error: translations.invalidPhone };
    }
    const digitsOnly = sanitized.replace(/\\\\D/g, '');
    const isValidLength = digitsOnly.length >= 7 && digitsOnly.length <= 15;
    return {
      isValid: isValidLength,
      error: isValidLength ? undefined : translations.invalidPhone,
    };
  }

  function validateName(value) {
    if (!value || value.trim() === '') return { isValid: true };
    const sanitized = sanitizeName(value);
    const isValid = VALIDATION_PATTERNS.name.test(sanitized) && sanitized.length >= 1;
    return {
      isValid,
      error: isValid ? undefined : translations.invalidName,
    };
  }

  function validateMaxLength(value, maxLength) {
    const length = value?.length || 0;
    const isValid = length <= maxLength;
    return {
      isValid,
      error: isValid ? undefined : translations.tooLong,
    };
  }

  // ============================================
  // FORM VALIDATION
  // ============================================

  function validateField(fieldElement) {
    const fieldName = fieldElement.dataset.fieldName || '';
    const validationType = fieldElement.dataset.validationType || 'text';
    const isRequired = fieldElement.dataset.required === 'true';
    const input = fieldElement.querySelector('[data-input]');
    const errorMessage = fieldElement.querySelector('[data-error-message]');

    if (!input) return { isValid: true };

    const value = input.value;
    let result = { isValid: true };

    // Check required first
    if (isRequired) {
      result = validateRequired(value);
      if (!result.isValid) {
        showError(fieldElement, errorMessage, result.error || '');
        return result;
      }
    }

    // If empty and not required, it's valid
    if (!value || value.trim() === '') {
      clearError(fieldElement, errorMessage);
      return { isValid: true };
    }

    // Type-specific validation
    switch (validationType) {
      case 'email':
        result = validateEmail(value);
        break;
      case 'phone':
        result = validatePhone(value);
        break;
      case 'name':
        result = validateName(value);
        break;
      case 'text':
        result = validateMaxLength(value, 2000);
        break;
      case 'select':
        result = { isValid: true };
        break;
    }

    if (result.isValid) {
      showValid(fieldElement, errorMessage);
    } else {
      showError(fieldElement, errorMessage, result.error || '');
    }

    return result;
  }

  function showError(fieldElement, errorMessage, message) {
    fieldElement.classList.remove('is-valid');
    fieldElement.classList.add('has-error');
    if (errorMessage) {
      errorMessage.textContent = message;
    }
  }

  function showValid(fieldElement, errorMessage) {
    fieldElement.classList.remove('has-error');
    fieldElement.classList.add('is-valid');
    if (errorMessage) {
      errorMessage.textContent = '';
    }
  }

  function clearError(fieldElement, errorMessage) {
    fieldElement.classList.remove('has-error', 'is-valid');
    if (errorMessage) {
      errorMessage.textContent = '';
    }
  }

  function validateAllFields(form) {
    const fields = form.querySelectorAll('[data-form-field]');
    let allValid = true;

    fields.forEach((field) => {
      const result = validateField(field);
      if (!result.isValid) {
        allValid = false;
      }
    });

    return allValid;
  }

  function getFormData(form) {
    const formData = new FormData(form);
    const data = {};

    formData.forEach((value, key) => {
      if (typeof value === 'string') {
        switch (key) {
          case 'email':
            data[key] = sanitizeEmail(value);
            break;
          case 'phone':
          case 'whatsapp':
          case 'phone-country':
            data[key] = sanitizePhone(value);
            break;
          case 'firstName':
          case 'surname':
            data[key] = sanitizeName(value);
            break;
          default:
            data[key] = sanitizeForDisplay(value);
        }
      }
    });

    return data;
  }

  function showFormMessage(form, message, type) {
    let messageEl = form.querySelector('[data-form-message]');

    if (!messageEl) {
      messageEl = document.createElement('div');
      messageEl.setAttribute('data-form-message', '');
      messageEl.setAttribute('role', 'alert');
      messageEl.className = 'mt-4 p-4 rounded-md text-sm';
      form.appendChild(messageEl);
    }

    messageEl.textContent = message;
    messageEl.classList.remove('bg-green-50', 'text-green-800', 'bg-red-50', 'text-red-800', 'hidden');

    if (type === 'success') {
      messageEl.classList.add('bg-green-50', 'text-green-800');
    } else {
      messageEl.classList.add('bg-red-50', 'text-red-800');
    }
  }

  // ============================================
  // FORM INITIALIZATION
  // ============================================

  document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('contact-form');
    if (!form) return;

    let isSubmitting = false;

    // Attach blur event listeners for real-time validation
    const fields = form.querySelectorAll('[data-form-field]');
    fields.forEach((field) => {
      const input = field.querySelector('[data-input]');
      if (input) {
        input.addEventListener('blur', () => validateField(field));
        input.addEventListener('input', () => {
          if (field.classList.contains('has-error')) {
            validateField(field);
          }
        });
      }
    });

    // Handle form submission
    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      if (isSubmitting) return;

      // Validate all fields
      const isValid = validateAllFields(form);

      if (!isValid) {
        const firstError = form.querySelector('.has-error [data-input]');
        if (firstError) {
          firstError.focus();
        }
        return;
      }

      // Get sanitized form data
      const data = getFormData(form);

      // Show loading state
      isSubmitting = true;
      const submitButton = form.querySelector('button[type="submit"]');
      const originalButtonText = submitButton?.textContent || '';

      if (submitButton) {
        submitButton.disabled = true;
        submitButton.textContent = translations.submitting;
      }

      try {
        // Generate CSRF token
        const csrfToken = generateCSRFToken();

        const response = await fetch('/api/contact', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': csrfToken,
          },
          body: JSON.stringify(data),
        });

        if (response.ok) {
          showFormMessage(form, translations.formSuccess, 'success');
          form.reset();
          // Clear all validation states
          fields.forEach((field) => {
            const errorMessage = field.querySelector('[data-error-message]');
            clearError(field, errorMessage);
          });
        } else {
          const errorData = await response.json().catch(() => ({}));
          showFormMessage(form, errorData.message || translations.formError, 'error');
        }
      } catch (error) {
        console.error('Network error:', error);
        showFormMessage(form, translations.formError, 'error');
      } finally {
        isSubmitting = false;
        if (submitButton) {
          submitButton.disabled = false;
          submitButton.textContent = originalButtonText;
        }
      }
    });
  });
})();<\/script>`])), maybeRenderHead(), renderComponent($$result, "Container", $$Container, {}, { "default": async ($$result2) => renderTemplate` <div class="grid lg:grid-cols-2 gap-12 lg:gap-16 items-start"> <!-- Contact Form --> <div class="bg-white rounded-2xl p-6 lg:p-8 shadow-[0_4px_24px_rgba(0,0,0,0.08)]"> <form class="space-y-6" id="contact-form" novalidate> <div class="grid sm:grid-cols-2 gap-6"> ${renderComponent($$result2, "FormField", $$FormField, { "type": "text", "label": t.contact.form.firstName, "name": "firstName", "validationType": "name", "required": true })} ${renderComponent($$result2, "FormField", $$FormField, { "type": "text", "label": t.contact.form.surname, "name": "surname", "validationType": "name", "required": true })} </div> <div class="grid sm:grid-cols-2 gap-6"> ${renderComponent($$result2, "FormField", $$FormField, { "type": "phone", "label": t.contact.form.phone, "name": "phone", "required": true })} ${renderComponent($$result2, "FormField", $$FormField, { "type": "email", "label": t.contact.form.email, "name": "email", "required": true })} </div> <div class="grid sm:grid-cols-2 gap-6"> ${renderComponent($$result2, "FormField", $$FormField, { "type": "tel", "label": t.contact.form.whatsapp, "name": "whatsapp" })} ${renderComponent($$result2, "FormField", $$FormField, { "type": "select", "label": t.contact.form.position, "name": "position", "options": positions })} </div> <div class="grid sm:grid-cols-2 gap-6"> ${renderComponent($$result2, "FormField", $$FormField, { "type": "select", "label": t.contact.form.projectType, "name": "projectType", "options": projectTypes })} ${renderComponent($$result2, "FormField", $$FormField, { "type": "select", "label": t.contact.form.budget, "name": "budget", "options": budgetRanges })} </div> <div class="grid sm:grid-cols-2 gap-6"> ${renderComponent($$result2, "FormField", $$FormField, { "type": "select", "label": t.contact.form.consideration, "name": "consideration", "options": considerations })} ${renderComponent($$result2, "FormField", $$FormField, { "type": "select", "label": t.contact.form.timeline, "name": "timeline", "options": timelines })} </div> ${renderComponent($$result2, "FormField", $$FormField, { "type": "textarea", "label": t.contact.form.remark, "name": "remark", "rows": 4, "maxLength": 2e3 })} <!-- Checkbox --> <label class="flex items-start gap-3 cursor-pointer"> <input type="checkbox" name="consent" class="mt-1 w-4 h-4 rounded border-gray-300 text-bmg-primary focus:ring-bmg-primary"> <span class="text-sm text-gray-600"> ${t.contact.form.consent} </span> </label> ${renderComponent($$result2, "Button", $$Button, { "type": "submit", "variant": "process", "class": "w-full sm:w-auto" }, { "default": async ($$result3) => renderTemplate`${t.contact.form.submit}` })} </form> </div> <!-- Contact Information --> <div> <h2 class="text-3xl lg:text-4xl font-bold mb-4 text-brand-primary uppercase"> ${t.contact.title} </h2> <p class="text-gray-600 mb-8"> ${t.contact.description} </p> <div class="space-y-6"> <!-- Address --> <div class="flex gap-4"> <div class="flex-shrink-0 w-6 h-6"> <img src="/images/Landing/property-location.svg" alt="Location" class="w-full h-full"> </div> <div class="text-gray-600"> ${contactInfo.address.map((line) => renderTemplate`<p>${line}</p>`)} </div> </div> <!-- Phone --> <div class="flex gap-4"> <div class="flex-shrink-0 w-6 h-6"> <img src="/images/Landing/mobile-chat.svg" alt="Phone" class="w-full h-full"> </div> <div class="text-gray-600"> ${contactInfo.phone.map((phone) => renderTemplate`<p>${phone}</p>`)} </div> </div> <!-- Email --> <div class="flex gap-4"> <div class="flex-shrink-0 w-6 h-6"> <img src="/images/Landing/email.svg" alt="Email" class="w-full h-full"> </div> <a${addAttribute(`mailto:${contactInfo.email}`, "href")} class="text-gray-600 hover:text-bmg-primary transition-colors"> ${contactInfo.email} </a> </div> <!-- Social Links --> <div class="pt-4 space-y-4"> ${contactInfo.socials.map((social) => renderTemplate`<a${addAttribute(social.url, "href")} target="_blank" rel="noopener noreferrer" class="flex items-center gap-4 hover:opacity-70 transition-opacity group"> <div class="w-8 h-8 flex items-center justify-center"> <img${addAttribute(`/images/Landing/${social.icon}.svg`, "src")}${addAttribute(social.name, "alt")} class="w-full h-full"> </div> <span class="text-gray-600 group-hover:text-bmg-primary transition-colors">${social.handle}</span> </a>`)} </div> </div> </div> </div> ` }), defineScriptVars({ validationTranslations }));
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/Contact.astro", void 0);

export { $$Hero as $, $$Showcase as a, $$Process as b, $$PriceEstimation as c, $$TrustedCultures as d, $$Testimonials as e, $$Contact as f };
