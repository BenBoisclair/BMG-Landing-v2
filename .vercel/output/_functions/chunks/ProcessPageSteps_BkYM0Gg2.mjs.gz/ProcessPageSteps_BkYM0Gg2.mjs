import { c as createAstro, a as createComponent, m as maybeRenderHead, d as addAttribute, b as renderTemplate, r as renderComponent } from './astro/server_Dl93DeC-.mjs';
import 'piccolore';
import 'clsx';
import { u as useI18n } from './Footer_DNsX0YeG.mjs';

const $$Astro$2 = createAstro("https://bmg-granite.com");
const $$ProcessPageHero = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$ProcessPageHero;
  const { t } = useI18n(Astro2.url);
  return renderTemplate`${maybeRenderHead()}<section id="process-hero" class="relative h-[200px] pt-20 lg:pt-24"> <!-- Background Image --> <div class="absolute inset-0 z-0"> <img src="/images/Product/7b7fd75f2e187f580cfdc947187b80e2a1b9669f.png"${addAttribute(t.processPage.heroAlt, "alt")} class="w-full h-full object-cover" fetchpriority="high" loading="eager" decoding="async"> </div> </section> <!-- Page Title - Positioned below the hero --> <div class="bg-white py-8 lg:py-12"> <h1 class="text-4xl lg:text-5xl font-semibold text-brand-primary text-center tracking-tight"> ${t.processPage.title} </h1> </div>`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/ProcessPageHero.astro", void 0);

const $$Astro$1 = createAstro("https://bmg-granite.com");
const $$ProcessPageStep = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$ProcessPageStep;
  const { stepNumber, title, subtitle, description, bulletPoints, imageSrc, imageAlt, reverse = false } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(`flex flex-col ${reverse ? "lg:flex-row-reverse" : "lg:flex-row"} gap-8 lg:gap-12 items-start`, "class")}> <!-- Image Section --> <div class="w-full lg:w-1/2"> <div class="aspect-[4/3] rounded-2xl overflow-hidden shadow-xl"> <img${addAttribute(imageSrc, "src")}${addAttribute(imageAlt, "alt")} class="w-full h-full object-cover" loading="lazy" decoding="async"> </div> </div> <!-- Content Section --> <div class="w-full lg:w-1/2 space-y-4"> <!-- Step Badge --> <div class="inline-flex items-center gap-2"> <span class="px-3 py-1 bg-brand-primary text-white text-sm font-semibold rounded-full">
Step ${stepNumber} </span> </div> <!-- Title --> <h2 class="text-2xl lg:text-3xl font-bold text-brand-primary"> ${title} </h2> <!-- Subtitle --> <h3 class="text-xl lg:text-2xl font-semibold text-gray-700"> ${subtitle} </h3> <!-- Description --> <p class="text-gray-600 leading-relaxed"> ${description} </p> <!-- Bullet Points --> <ul class="space-y-3 pt-2"> ${bulletPoints.map((point) => renderTemplate`<li class="flex items-start gap-3"> <svg class="w-5 h-5 text-bmg-gold flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 10l7-7m0 0l7 7m-7-7v18"></path> </svg> <span class="text-gray-600">${point}</span> </li>`)} </ul> </div> </div>`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/ui/ProcessPageStep.astro", void 0);

const $$Astro = createAstro("https://bmg-granite.com");
const $$ProcessPageSteps = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$ProcessPageSteps;
  const { t } = useI18n(Astro2.url);
  const stepImages = [
    "/images/Landing/ProcessImage.jpg",
    "/images/Product/65c3f3941db7b44a78aa5261748a2352f7b0bda4.png",
    "/images/Product/14f34ea2cb60093c0f497dfe6d8813a559d4e77e.png",
    "/images/Product/c0ae66328f0cc5ad849ec800c03045573a8cdcf5.png",
    "/images/Product/5699ac09f2407f7415000dada3fa4ccf742d51a6.png",
    "/images/Product/85bb80af71d14ba9f96b4618f1d257cc7e95d757.png"
  ];
  const steps = [
    { ...t.processPage.steps["1"], image: stepImages[0] },
    { ...t.processPage.steps["2"], image: stepImages[1] },
    { ...t.processPage.steps["3"], image: stepImages[2] },
    { ...t.processPage.steps["4"], image: stepImages[3] },
    { ...t.processPage.steps["5"], image: stepImages[4] },
    { ...t.processPage.steps["6"], image: stepImages[5] }
  ];
  return renderTemplate`${maybeRenderHead()}<section id="process-steps" class="py-16 lg:py-24 bg-gray-50"> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"> <div class="space-y-16 lg:space-y-24"> ${steps.map((step, index) => renderTemplate`${renderComponent($$result, "ProcessPageStep", $$ProcessPageStep, { "stepNumber": step.number, "title": step.title, "subtitle": step.subtitle, "description": step.description, "bulletPoints": step.bulletPoints, "imageSrc": step.image, "imageAlt": step.imageAlt, "reverse": index % 2 === 1 })}`)} </div> </div> </section>`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/ProcessPageSteps.astro", void 0);

export { $$ProcessPageHero as $, $$ProcessPageSteps as a };
