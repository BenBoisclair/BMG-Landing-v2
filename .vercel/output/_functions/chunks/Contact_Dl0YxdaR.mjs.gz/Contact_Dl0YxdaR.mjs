import { e as createAstro, f as createComponent, m as maybeRenderHead, h as addAttribute, o as renderSlot, r as renderTemplate, l as defineScriptVars, k as renderComponent } from './astro/server_DN3y_WhJ.mjs';
import 'piccolore';
import 'clsx';
/* empty css                            */
import { u as useI18n } from './Footer_B0yHRcuM.mjs';
import { $ as $$Container } from './Container_THuMWHHu.mjs';

const $$Astro$2 = createAstro("https://bmg-granite.com");
const $$Button = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$Button;
  const {
    variant = "primary",
    size = "md",
    href,
    type = "button",
    class: className = ""
  } = Astro2.props;
  const baseClasses = "inline-flex items-center justify-center font-medium rounded-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2";
  const variantClasses = {
    primary: "bg-bmg-primary text-white hover:bg-bmg-secondary focus:ring-bmg-primary",
    secondary: "bg-bmg-gold text-white hover:bg-amber-600 focus:ring-bmg-gold",
    outline: "border-2 border-bmg-primary text-bmg-primary hover:bg-bmg-primary hover:text-white focus:ring-bmg-primary",
    process: "bg-brand-primary text-white hover:bg-brand-primary-hover focus:ring-brand-primary"
  };
  const sizeClasses = {
    sm: "px-4 py-2 text-sm",
    md: "px-6 py-3 text-base",
    lg: "px-8 py-4 text-lg"
  };
  const classes = `${baseClasses} ${variantClasses[variant]} ${sizeClasses[size]} ${className}`;
  return renderTemplate`${href ? renderTemplate`${maybeRenderHead()}<a${addAttribute(href, "href")}${addAttribute(classes, "class")}>${renderSlot($$result, $$slots["default"])}</a>` : renderTemplate`<button${addAttribute(type, "type")}${addAttribute(classes, "class")}>${renderSlot($$result, $$slots["default"])}</button>`}`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/ui/Button.astro", void 0);

const $$Astro$1 = createAstro("https://bmg-granite.com");
const $$FormField = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$FormField;
  const {
    type,
    label,
    name,
    placeholder = "",
    required = false,
    rows = 4,
    maxLength,
    pattern,
    validationType,
    options = [],
    selectPlaceholder = "Please Select...",
    class: className = ""
  } = Astro2.props;
  const getValidationType = () => {
    if (validationType) return validationType;
    if (type === "email") return "email";
    if (type === "tel" || type === "phone") return "phone";
    if (type === "url") return "url";
    if (type === "select") return "select";
    return "text";
  };
  const isPhoneWithCountry = type === "phone";
  const isSelect = type === "select";
  const isTextarea = type === "textarea";
  const countryCodes = [
    { code: "+66", country: "Thailand" },
    { code: "+1", country: "USA/Canada" },
    { code: "+44", country: "UK" },
    { code: "+86", country: "China" },
    { code: "+91", country: "India" },
    { code: "+81", country: "Japan" },
    { code: "+82", country: "South Korea" },
    { code: "+65", country: "Singapore" },
    { code: "+971", country: "UAE" },
    { code: "+966", country: "Saudi Arabia" },
    { code: "+61", country: "Australia" },
    { code: "+49", country: "Germany" },
    { code: "+33", country: "France" }
  ];
  const normalizedOptions = options.map(
    (opt) => typeof opt === "string" ? { value: opt, label: opt } : opt
  );
  const baseInputClasses = "w-full px-3 rounded-md border border-border bg-white focus:ring-2 focus:ring-bmg-primary focus:border-transparent outline-none transition-all duration-200 text-gray-900 placeholder-gray-500";
  const inputClasses = `${baseInputClasses} h-[50px] flex flex-col justify-center items-start gap-3`;
  const textareaClasses = `${baseInputClasses} py-3 flex flex-col justify-start items-start gap-3`;
  const selectClasses = `${inputClasses} appearance-none cursor-pointer bg-[url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e")] bg-[length:1.5em_1.5em] bg-[right_0.5rem_center] bg-no-repeat pr-10`;
  const phoneSelectClasses = `h-[50px] px-3 border-r border-border bg-white focus:ring-2 focus:ring-bmg-primary focus:outline-none transition-all duration-200 text-gray-900 appearance-none cursor-pointer bg-[url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e")] bg-[length:1em_1em] bg-[right_0.25rem_center] bg-no-repeat pr-6`;
  const phoneInputClasses = "flex-1 h-[50px] px-3 bg-white focus:ring-2 focus:ring-bmg-primary focus:outline-none transition-all duration-200 text-gray-900 placeholder-gray-500";
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(["form-field space-y-2", className], "class:list")} data-form-field${addAttribute(name, "data-field-name")}${addAttribute(getValidationType(), "data-validation-type")}${addAttribute(required.toString(), "data-required")} data-astro-cid-p46g2kvx> <label${addAttribute(name, "for")} class="block text-sm font-medium text-gray-900" data-astro-cid-p46g2kvx> ${label} ${required && renderTemplate`<span class="text-red-500" data-astro-cid-p46g2kvx>*</span>`} </label> ${isPhoneWithCountry ? renderTemplate`<!-- Phone input with country code selector -->
    <div class="flex rounded-md border border-border bg-white overflow-hidden" data-phone-wrapper data-astro-cid-p46g2kvx> <select${addAttribute(`${name}-country`, "id")}${addAttribute(`${name}-country`, "name")}${addAttribute(phoneSelectClasses, "class")} aria-label="Country code" data-country-select data-astro-cid-p46g2kvx> ${countryCodes.map(({ code, country }) => renderTemplate`<option${addAttribute(code, "value")}${addAttribute(country, "title")} data-astro-cid-p46g2kvx>${code}</option>`)} </select> <input type="tel"${addAttribute(name, "id")}${addAttribute(name, "name")}${addAttribute(placeholder || label, "placeholder")}${addAttribute(required, "required")}${addAttribute(phoneInputClasses, "class")} inputmode="tel" autocomplete="tel" data-input data-astro-cid-p46g2kvx> </div>` : isSelect ? renderTemplate`<!-- Select dropdown -->
    <select${addAttribute(name, "id")}${addAttribute(name, "name")}${addAttribute(required, "required")}${addAttribute(selectClasses, "class")} data-input data-astro-cid-p46g2kvx> <option value="" disabled selected data-astro-cid-p46g2kvx>${selectPlaceholder}</option> ${normalizedOptions.map((opt) => renderTemplate`<option${addAttribute(opt.value, "value")} data-astro-cid-p46g2kvx>${opt.label}</option>`)} </select>` : isTextarea ? renderTemplate`<!-- Textarea -->
    <textarea${addAttribute(name, "id")}${addAttribute(name, "name")}${addAttribute(rows, "rows")}${addAttribute(placeholder || label, "placeholder")}${addAttribute(required, "required")}${addAttribute(maxLength, "maxlength")}${addAttribute(textareaClasses, "class")} data-input data-astro-cid-p46g2kvx></textarea>` : renderTemplate`<!-- Standard input (text, email, tel, url) -->
    <input${addAttribute(type === "phone" ? "tel" : type, "type")}${addAttribute(name, "id")}${addAttribute(name, "name")}${addAttribute(placeholder || label, "placeholder")}${addAttribute(required, "required")}${addAttribute(maxLength, "maxlength")}${addAttribute(pattern, "pattern")}${addAttribute(inputClasses, "class")} data-input data-astro-cid-p46g2kvx>`} <p class="form-field__error text-xs text-red-500 mt-1 hidden" data-error-message aria-live="polite" data-astro-cid-p46g2kvx></p> </div> `;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/ui/FormField.astro", void 0);

function parseCommaSeparated(value, defaultValue = []) {
  return defaultValue;
}
function parseSocials(value, defaultSocials2) {
  return defaultSocials2;
}
const defaultAddress = [
  "9/11 Moo 10 Boromraj-Chonnee Road",
  "Sala Dhammasop, Taweewattana",
  "Bangkok 10170"
];
const defaultPhones = ["+66 2 888 7788", "+66 0877896226", "+66 81 445 9999"];
const defaultEmail = "bmgthai@bmg.co.th";
const defaultSocials = [
  {
    name: "Facebook",
    handle: "BMG บางกอกโมเดอร์นแกรนิต",
    url: "https://www.facebook.com/bmgthailand",
    icon: "facebook"
  },
  {
    name: "Line",
    handle: "@bmgstone",
    url: "https://page.line.me/bmgstone?openQrModal=true",
    icon: "line"
  },
  {
    name: "Instagram",
    handle: "bangkokmoderngranite",
    url: "https://www.instagram.com/bangkokmoderngranite",
    icon: "instagram"
  },
  {
    name: "YouTube",
    handle: "bmgthai granite",
    url: "https://www.youtube.com/channel/UC9FCyP3XZHRkvK9vnnh8IMg",
    icon: "youtube"
  }
];
function getContactConfig() {
  return {
    address: parseCommaSeparated(
      undefined                               ,
      defaultAddress
    ),
    phone: parseCommaSeparated(
      undefined                              ,
      defaultPhones
    ),
    email: defaultEmail,
    socials: parseSocials(
      undefined                               ,
      defaultSocials
    )
  };
}
const contactConfig = getContactConfig();

const positions = ["salesManager","projectManager","designer","architect","developer","other"];
const projectTypes = ["residential","commercial","industrial","hospitality","publicSpace","other"];
const budgetRanges = ["under10k","10kTo50k","50kTo100k","100kTo500k","over500k"];
const considerations = ["quality","price","timeline","design","allOfTheAbove"];
const timelines = ["immediate","within1Month","1To3Months","3To6Months","6PlusMonths"];
const formOptionsConfig = {
  positions,
  projectTypes,
  budgetRanges,
  considerations,
  timelines,
};

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(raw || cooked.slice()) }));
var _a;
const $$Astro = createAstro("https://bmg-granite.com");
const $$Contact = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Contact;
  const { t } = useI18n(Astro2.url);
  const contactInfo = contactConfig;
  const positions = formOptionsConfig.positions.map(
    (key) => t.contact.positions[key]
  );
  const projectTypes = formOptionsConfig.projectTypes.map(
    (key) => t.contact.projectTypes[key]
  );
  const budgetRanges = formOptionsConfig.budgetRanges.map(
    (key) => t.contact.budgetRanges[key]
  );
  const considerations = formOptionsConfig.considerations.map(
    (key) => t.contact.considerations[key]
  );
  const timelines = formOptionsConfig.timelines.map(
    (key) => t.contact.timelines[key]
  );
  const validationTranslations = JSON.stringify({
    required: t.validation?.required || "This field is required",
    invalidEmail: t.validation?.invalidEmail || "Please enter a valid email address",
    invalidPhone: t.validation?.invalidPhone || "Please enter a valid phone number (7-15 digits)",
    invalidUrl: t.validation?.invalidUrl || "Please enter a valid URL (including http:// or https://)",
    invalidName: t.validation?.invalidName || "Please enter a valid name (letters only)",
    tooShort: t.validation?.tooShort || "This field is too short",
    tooLong: t.validation?.tooLong || "This field is too long",
    invalidFormat: t.validation?.invalidFormat || "Invalid format",
    formSuccess: t.validation?.formSuccess || "Thank you! Your message has been sent successfully.",
    formError: t.validation?.formError || "There was an error submitting your form. Please try again.",
    submitting: t.validation?.submitting || "Submitting..."
  });
  return renderTemplate(_a || (_a = __template(["", '<section id="contact" class="py-16 lg:py-24 bg-white"> ', " </section> <script>(function(){", `
  // Parse translations from server
  const translations = JSON.parse(validationTranslations);

  // ============================================
  // CSRF TOKEN GENERATION
  // ============================================

  const CSRF_TOKEN_KEY = 'bmg_csrf_token';
  const TOKEN_EXPIRY_MS = 30 * 60 * 1000; // 30 minutes

  function generateSecureToken(length = 32) {
    const array = new Uint8Array(length);
    crypto.getRandomValues(array);
    return Array.from(array, (byte) => byte.toString(16).padStart(2, '0')).join('');
  }

  function generateCSRFToken() {
    try {
      const stored = sessionStorage.getItem(CSRF_TOKEN_KEY);
      if (stored) {
        const tokenData = JSON.parse(stored);
        if (tokenData.expiresAt > Date.now()) {
          return tokenData.token;
        }
      }
    } catch (e) {
      // Ignore parsing errors
    }

    // Generate new token
    const token = generateSecureToken();
    const tokenData = {
      token,
      timestamp: Date.now(),
      expiresAt: Date.now() + TOKEN_EXPIRY_MS,
    };

    try {
      sessionStorage.setItem(CSRF_TOKEN_KEY, JSON.stringify(tokenData));
    } catch (e) {
      // Ignore storage errors
    }

    return token;
  }

  // ============================================
  // VALIDATION PATTERNS
  // ============================================

  const VALIDATION_PATTERNS = {
    email: /^[a-zA-Z0-9](?:[a-zA-Z0-9._%+-]*[a-zA-Z0-9])?@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\\.[a-zA-Z]{2,})+$/,
    phone: /^[\\d\\s\\-()]+$/,
    name: /^[\\p{L}\\p{M}][\\p{L}\\p{M}\\s\\-']*[\\p{L}\\p{M}]$|^[\\p{L}\\p{M}]$/u,
  };

  // ============================================
  // SANITIZATION FUNCTIONS
  // ============================================

  const HTML_ENTITIES = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#x27;',
    '/': '&#x2F;',
    '\`': '&#x60;',
    '=': '&#x3D;',
  };

  function sanitizeHTML(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/[&<>"'\`=/]/g, (char) => HTML_ENTITIES[char] || char);
  }

  function stripHTMLTags(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/<[^>]*>/g, '');
  }

  function sanitizeForDisplay(input) {
    if (typeof input !== 'string') return '';
    return sanitizeHTML(stripHTMLTags(input));
  }

  function sanitizePhone(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/[^\\d+\\-() ]/g, '').trim();
  }

  function sanitizeEmail(input) {
    if (typeof input !== 'string') return '';
    return input.toLowerCase().trim();
  }

  function sanitizeName(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/[^\\p{L}\\p{M}\\s\\-']/gu, '').trim();
  }

  // ============================================
  // VALIDATION FUNCTIONS
  // ============================================

  function validateRequired(value) {
    const trimmed = value?.trim() || '';
    return {
      isValid: trimmed.length > 0,
      error: trimmed.length > 0 ? undefined : translations.required,
    };
  }

  function validateEmail(value) {
    if (!value || value.trim() === '') return { isValid: true };
    const sanitized = sanitizeEmail(value);
    const isValid = VALIDATION_PATTERNS.email.test(sanitized);
    return {
      isValid,
      error: isValid ? undefined : translations.invalidEmail,
    };
  }

  function validatePhone(value) {
    if (!value || value.trim() === '') return { isValid: true };
    const sanitized = sanitizePhone(value);
    if (!VALIDATION_PATTERNS.phone.test(sanitized)) {
      return { isValid: false, error: translations.invalidPhone };
    }
    const digitsOnly = sanitized.replace(/\\D/g, '');
    const isValidLength = digitsOnly.length >= 7 && digitsOnly.length <= 15;
    return {
      isValid: isValidLength,
      error: isValidLength ? undefined : translations.invalidPhone,
    };
  }

  function validateName(value) {
    if (!value || value.trim() === '') return { isValid: true };
    const sanitized = sanitizeName(value);
    const isValid = VALIDATION_PATTERNS.name.test(sanitized) && sanitized.length >= 1;
    return {
      isValid,
      error: isValid ? undefined : translations.invalidName,
    };
  }

  function validateMaxLength(value, maxLength) {
    const length = value?.length || 0;
    const isValid = length <= maxLength;
    return {
      isValid,
      error: isValid ? undefined : translations.tooLong,
    };
  }

  // ============================================
  // FORM VALIDATION
  // ============================================

  function validateField(fieldElement) {
    const fieldName = fieldElement.dataset.fieldName || '';
    const validationType = fieldElement.dataset.validationType || 'text';
    const isRequired = fieldElement.dataset.required === 'true';
    const input = fieldElement.querySelector('[data-input]');
    const errorMessage = fieldElement.querySelector('[data-error-message]');

    if (!input) return { isValid: true };

    const value = input.value;
    let result = { isValid: true };

    // Check required first
    if (isRequired) {
      result = validateRequired(value);
      if (!result.isValid) {
        showError(fieldElement, errorMessage, result.error || '');
        return result;
      }
    }

    // If empty and not required, it's valid
    if (!value || value.trim() === '') {
      clearError(fieldElement, errorMessage);
      return { isValid: true };
    }

    // Type-specific validation
    switch (validationType) {
      case 'email':
        result = validateEmail(value);
        break;
      case 'phone':
        result = validatePhone(value);
        break;
      case 'name':
        result = validateName(value);
        break;
      case 'text':
        result = validateMaxLength(value, 2000);
        break;
      case 'select':
        result = { isValid: true };
        break;
    }

    if (result.isValid) {
      showValid(fieldElement, errorMessage);
    } else {
      showError(fieldElement, errorMessage, result.error || '');
    }

    return result;
  }

  function showError(fieldElement, errorMessage, message) {
    fieldElement.classList.remove('is-valid');
    fieldElement.classList.add('has-error');
    if (errorMessage) {
      errorMessage.textContent = message;
    }
  }

  function showValid(fieldElement, errorMessage) {
    fieldElement.classList.remove('has-error');
    fieldElement.classList.add('is-valid');
    if (errorMessage) {
      errorMessage.textContent = '';
    }
  }

  function clearError(fieldElement, errorMessage) {
    fieldElement.classList.remove('has-error', 'is-valid');
    if (errorMessage) {
      errorMessage.textContent = '';
    }
  }

  function validateAllFields(form) {
    const fields = form.querySelectorAll('[data-form-field]');
    let allValid = true;

    fields.forEach((field) => {
      const result = validateField(field);
      if (!result.isValid) {
        allValid = false;
      }
    });

    return allValid;
  }

  function getFormData(form) {
    const formData = new FormData(form);
    const data = {};

    formData.forEach((value, key) => {
      if (typeof value === 'string') {
        switch (key) {
          case 'email':
            data[key] = sanitizeEmail(value);
            break;
          case 'phone':
          case 'whatsapp':
          case 'phone-country':
            data[key] = sanitizePhone(value);
            break;
          case 'firstName':
          case 'surname':
            data[key] = sanitizeName(value);
            break;
          default:
            data[key] = sanitizeForDisplay(value);
        }
      }
    });

    return data;
  }

  function showFormMessage(form, message, type) {
    let messageEl = form.querySelector('[data-form-message]');

    if (!messageEl) {
      messageEl = document.createElement('div');
      messageEl.setAttribute('data-form-message', '');
      messageEl.setAttribute('role', 'alert');
      messageEl.className = 'mt-4 p-4 rounded-md text-sm';
      form.appendChild(messageEl);
    }

    messageEl.textContent = message;
    messageEl.classList.remove('bg-green-50', 'text-green-800', 'bg-red-50', 'text-red-800', 'hidden');

    if (type === 'success') {
      messageEl.classList.add('bg-green-50', 'text-green-800');
    } else {
      messageEl.classList.add('bg-red-50', 'text-red-800');
    }
  }

  // ============================================
  // FORM INITIALIZATION
  // ============================================

  document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('contact-form');
    if (!form) return;

    let isSubmitting = false;

    // Attach blur event listeners for real-time validation
    const fields = form.querySelectorAll('[data-form-field]');
    fields.forEach((field) => {
      const input = field.querySelector('[data-input]');
      if (input) {
        input.addEventListener('blur', () => validateField(field));
        input.addEventListener('input', () => {
          if (field.classList.contains('has-error')) {
            validateField(field);
          }
        });
      }
    });

    // Handle form submission
    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      if (isSubmitting) return;

      // Validate all fields
      const isValid = validateAllFields(form);

      if (!isValid) {
        const firstError = form.querySelector('.has-error [data-input]');
        if (firstError) {
          firstError.focus();
        }
        return;
      }

      // Get sanitized form data
      const data = getFormData(form);

      // Show loading state
      isSubmitting = true;
      const submitButton = form.querySelector('button[type="submit"]');
      const originalButtonText = submitButton?.textContent || '';

      if (submitButton) {
        submitButton.disabled = true;
        submitButton.textContent = translations.submitting;
      }

      try {
        // Generate CSRF token
        const csrfToken = generateCSRFToken();

        const response = await fetch('/api/contact', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': csrfToken,
          },
          body: JSON.stringify(data),
        });

        if (response.ok) {
          showFormMessage(form, translations.formSuccess, 'success');
          form.reset();
          // Clear all validation states
          fields.forEach((field) => {
            const errorMessage = field.querySelector('[data-error-message]');
            clearError(field, errorMessage);
          });
        } else {
          const errorData = await response.json().catch(() => ({}));
          showFormMessage(form, errorData.message || translations.formError, 'error');
        }
      } catch (error) {
        console.error('Network error:', error);
        showFormMessage(form, translations.formError, 'error');
      } finally {
        isSubmitting = false;
        if (submitButton) {
          submitButton.disabled = false;
          submitButton.textContent = originalButtonText;
        }
      }
    });
  });
})();<\/script>`], ["", '<section id="contact" class="py-16 lg:py-24 bg-white"> ', " </section> <script>(function(){", `
  // Parse translations from server
  const translations = JSON.parse(validationTranslations);

  // ============================================
  // CSRF TOKEN GENERATION
  // ============================================

  const CSRF_TOKEN_KEY = 'bmg_csrf_token';
  const TOKEN_EXPIRY_MS = 30 * 60 * 1000; // 30 minutes

  function generateSecureToken(length = 32) {
    const array = new Uint8Array(length);
    crypto.getRandomValues(array);
    return Array.from(array, (byte) => byte.toString(16).padStart(2, '0')).join('');
  }

  function generateCSRFToken() {
    try {
      const stored = sessionStorage.getItem(CSRF_TOKEN_KEY);
      if (stored) {
        const tokenData = JSON.parse(stored);
        if (tokenData.expiresAt > Date.now()) {
          return tokenData.token;
        }
      }
    } catch (e) {
      // Ignore parsing errors
    }

    // Generate new token
    const token = generateSecureToken();
    const tokenData = {
      token,
      timestamp: Date.now(),
      expiresAt: Date.now() + TOKEN_EXPIRY_MS,
    };

    try {
      sessionStorage.setItem(CSRF_TOKEN_KEY, JSON.stringify(tokenData));
    } catch (e) {
      // Ignore storage errors
    }

    return token;
  }

  // ============================================
  // VALIDATION PATTERNS
  // ============================================

  const VALIDATION_PATTERNS = {
    email: /^[a-zA-Z0-9](?:[a-zA-Z0-9._%+-]*[a-zA-Z0-9])?@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\\\\.[a-zA-Z]{2,})+$/,
    phone: /^[\\\\d\\\\s\\\\-()]+$/,
    name: /^[\\\\p{L}\\\\p{M}][\\\\p{L}\\\\p{M}\\\\s\\\\-']*[\\\\p{L}\\\\p{M}]$|^[\\\\p{L}\\\\p{M}]$/u,
  };

  // ============================================
  // SANITIZATION FUNCTIONS
  // ============================================

  const HTML_ENTITIES = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#x27;',
    '/': '&#x2F;',
    '\\\`': '&#x60;',
    '=': '&#x3D;',
  };

  function sanitizeHTML(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/[&<>"'\\\`=/]/g, (char) => HTML_ENTITIES[char] || char);
  }

  function stripHTMLTags(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/<[^>]*>/g, '');
  }

  function sanitizeForDisplay(input) {
    if (typeof input !== 'string') return '';
    return sanitizeHTML(stripHTMLTags(input));
  }

  function sanitizePhone(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/[^\\\\d+\\\\-() ]/g, '').trim();
  }

  function sanitizeEmail(input) {
    if (typeof input !== 'string') return '';
    return input.toLowerCase().trim();
  }

  function sanitizeName(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/[^\\\\p{L}\\\\p{M}\\\\s\\\\-']/gu, '').trim();
  }

  // ============================================
  // VALIDATION FUNCTIONS
  // ============================================

  function validateRequired(value) {
    const trimmed = value?.trim() || '';
    return {
      isValid: trimmed.length > 0,
      error: trimmed.length > 0 ? undefined : translations.required,
    };
  }

  function validateEmail(value) {
    if (!value || value.trim() === '') return { isValid: true };
    const sanitized = sanitizeEmail(value);
    const isValid = VALIDATION_PATTERNS.email.test(sanitized);
    return {
      isValid,
      error: isValid ? undefined : translations.invalidEmail,
    };
  }

  function validatePhone(value) {
    if (!value || value.trim() === '') return { isValid: true };
    const sanitized = sanitizePhone(value);
    if (!VALIDATION_PATTERNS.phone.test(sanitized)) {
      return { isValid: false, error: translations.invalidPhone };
    }
    const digitsOnly = sanitized.replace(/\\\\D/g, '');
    const isValidLength = digitsOnly.length >= 7 && digitsOnly.length <= 15;
    return {
      isValid: isValidLength,
      error: isValidLength ? undefined : translations.invalidPhone,
    };
  }

  function validateName(value) {
    if (!value || value.trim() === '') return { isValid: true };
    const sanitized = sanitizeName(value);
    const isValid = VALIDATION_PATTERNS.name.test(sanitized) && sanitized.length >= 1;
    return {
      isValid,
      error: isValid ? undefined : translations.invalidName,
    };
  }

  function validateMaxLength(value, maxLength) {
    const length = value?.length || 0;
    const isValid = length <= maxLength;
    return {
      isValid,
      error: isValid ? undefined : translations.tooLong,
    };
  }

  // ============================================
  // FORM VALIDATION
  // ============================================

  function validateField(fieldElement) {
    const fieldName = fieldElement.dataset.fieldName || '';
    const validationType = fieldElement.dataset.validationType || 'text';
    const isRequired = fieldElement.dataset.required === 'true';
    const input = fieldElement.querySelector('[data-input]');
    const errorMessage = fieldElement.querySelector('[data-error-message]');

    if (!input) return { isValid: true };

    const value = input.value;
    let result = { isValid: true };

    // Check required first
    if (isRequired) {
      result = validateRequired(value);
      if (!result.isValid) {
        showError(fieldElement, errorMessage, result.error || '');
        return result;
      }
    }

    // If empty and not required, it's valid
    if (!value || value.trim() === '') {
      clearError(fieldElement, errorMessage);
      return { isValid: true };
    }

    // Type-specific validation
    switch (validationType) {
      case 'email':
        result = validateEmail(value);
        break;
      case 'phone':
        result = validatePhone(value);
        break;
      case 'name':
        result = validateName(value);
        break;
      case 'text':
        result = validateMaxLength(value, 2000);
        break;
      case 'select':
        result = { isValid: true };
        break;
    }

    if (result.isValid) {
      showValid(fieldElement, errorMessage);
    } else {
      showError(fieldElement, errorMessage, result.error || '');
    }

    return result;
  }

  function showError(fieldElement, errorMessage, message) {
    fieldElement.classList.remove('is-valid');
    fieldElement.classList.add('has-error');
    if (errorMessage) {
      errorMessage.textContent = message;
    }
  }

  function showValid(fieldElement, errorMessage) {
    fieldElement.classList.remove('has-error');
    fieldElement.classList.add('is-valid');
    if (errorMessage) {
      errorMessage.textContent = '';
    }
  }

  function clearError(fieldElement, errorMessage) {
    fieldElement.classList.remove('has-error', 'is-valid');
    if (errorMessage) {
      errorMessage.textContent = '';
    }
  }

  function validateAllFields(form) {
    const fields = form.querySelectorAll('[data-form-field]');
    let allValid = true;

    fields.forEach((field) => {
      const result = validateField(field);
      if (!result.isValid) {
        allValid = false;
      }
    });

    return allValid;
  }

  function getFormData(form) {
    const formData = new FormData(form);
    const data = {};

    formData.forEach((value, key) => {
      if (typeof value === 'string') {
        switch (key) {
          case 'email':
            data[key] = sanitizeEmail(value);
            break;
          case 'phone':
          case 'whatsapp':
          case 'phone-country':
            data[key] = sanitizePhone(value);
            break;
          case 'firstName':
          case 'surname':
            data[key] = sanitizeName(value);
            break;
          default:
            data[key] = sanitizeForDisplay(value);
        }
      }
    });

    return data;
  }

  function showFormMessage(form, message, type) {
    let messageEl = form.querySelector('[data-form-message]');

    if (!messageEl) {
      messageEl = document.createElement('div');
      messageEl.setAttribute('data-form-message', '');
      messageEl.setAttribute('role', 'alert');
      messageEl.className = 'mt-4 p-4 rounded-md text-sm';
      form.appendChild(messageEl);
    }

    messageEl.textContent = message;
    messageEl.classList.remove('bg-green-50', 'text-green-800', 'bg-red-50', 'text-red-800', 'hidden');

    if (type === 'success') {
      messageEl.classList.add('bg-green-50', 'text-green-800');
    } else {
      messageEl.classList.add('bg-red-50', 'text-red-800');
    }
  }

  // ============================================
  // FORM INITIALIZATION
  // ============================================

  document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('contact-form');
    if (!form) return;

    let isSubmitting = false;

    // Attach blur event listeners for real-time validation
    const fields = form.querySelectorAll('[data-form-field]');
    fields.forEach((field) => {
      const input = field.querySelector('[data-input]');
      if (input) {
        input.addEventListener('blur', () => validateField(field));
        input.addEventListener('input', () => {
          if (field.classList.contains('has-error')) {
            validateField(field);
          }
        });
      }
    });

    // Handle form submission
    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      if (isSubmitting) return;

      // Validate all fields
      const isValid = validateAllFields(form);

      if (!isValid) {
        const firstError = form.querySelector('.has-error [data-input]');
        if (firstError) {
          firstError.focus();
        }
        return;
      }

      // Get sanitized form data
      const data = getFormData(form);

      // Show loading state
      isSubmitting = true;
      const submitButton = form.querySelector('button[type="submit"]');
      const originalButtonText = submitButton?.textContent || '';

      if (submitButton) {
        submitButton.disabled = true;
        submitButton.textContent = translations.submitting;
      }

      try {
        // Generate CSRF token
        const csrfToken = generateCSRFToken();

        const response = await fetch('/api/contact', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': csrfToken,
          },
          body: JSON.stringify(data),
        });

        if (response.ok) {
          showFormMessage(form, translations.formSuccess, 'success');
          form.reset();
          // Clear all validation states
          fields.forEach((field) => {
            const errorMessage = field.querySelector('[data-error-message]');
            clearError(field, errorMessage);
          });
        } else {
          const errorData = await response.json().catch(() => ({}));
          showFormMessage(form, errorData.message || translations.formError, 'error');
        }
      } catch (error) {
        console.error('Network error:', error);
        showFormMessage(form, translations.formError, 'error');
      } finally {
        isSubmitting = false;
        if (submitButton) {
          submitButton.disabled = false;
          submitButton.textContent = originalButtonText;
        }
      }
    });
  });
})();<\/script>`])), maybeRenderHead(), renderComponent($$result, "Container", $$Container, {}, { "default": async ($$result2) => renderTemplate` <div class="grid lg:grid-cols-2 gap-12 lg:gap-16 items-start"> <!-- Contact Form --> <div class="bg-white rounded-2xl p-6 lg:p-8 shadow-[0_4px_24px_rgba(0,0,0,0.08)]"> <form class="space-y-6" id="contact-form" novalidate> <div class="grid sm:grid-cols-2 gap-6"> ${renderComponent($$result2, "FormField", $$FormField, { "type": "text", "label": t.contact.form.firstName, "name": "firstName", "validationType": "name", "required": true })} ${renderComponent($$result2, "FormField", $$FormField, { "type": "text", "label": t.contact.form.surname, "name": "surname", "validationType": "name", "required": true })} </div> <div class="grid sm:grid-cols-2 gap-6"> ${renderComponent($$result2, "FormField", $$FormField, { "type": "phone", "label": t.contact.form.phone, "name": "phone", "required": true })} ${renderComponent($$result2, "FormField", $$FormField, { "type": "email", "label": t.contact.form.email, "name": "email", "required": true })} </div> <div class="grid sm:grid-cols-2 gap-6"> ${renderComponent($$result2, "FormField", $$FormField, { "type": "tel", "label": t.contact.form.whatsapp, "name": "whatsapp" })} ${renderComponent($$result2, "FormField", $$FormField, { "type": "select", "label": t.contact.form.position, "name": "position", "options": positions })} </div> <div class="grid sm:grid-cols-2 gap-6"> ${renderComponent($$result2, "FormField", $$FormField, { "type": "select", "label": t.contact.form.projectType, "name": "projectType", "options": projectTypes })} ${renderComponent($$result2, "FormField", $$FormField, { "type": "select", "label": t.contact.form.budget, "name": "budget", "options": budgetRanges })} </div> <div class="grid sm:grid-cols-2 gap-6"> ${renderComponent($$result2, "FormField", $$FormField, { "type": "select", "label": t.contact.form.consideration, "name": "consideration", "options": considerations })} ${renderComponent($$result2, "FormField", $$FormField, { "type": "select", "label": t.contact.form.timeline, "name": "timeline", "options": timelines })} </div> ${renderComponent($$result2, "FormField", $$FormField, { "type": "textarea", "label": t.contact.form.remark, "name": "remark", "rows": 4, "maxLength": 2e3 })} <!-- Checkbox --> <label class="flex items-start gap-3 cursor-pointer"> <input type="checkbox" name="consent" class="mt-1 w-4 h-4 rounded border-gray-300 text-bmg-primary focus:ring-bmg-primary"> <span class="text-sm text-gray-600"> ${t.contact.form.consent} </span> </label> ${renderComponent($$result2, "Button", $$Button, { "type": "submit", "variant": "process", "class": "w-full sm:w-auto" }, { "default": async ($$result3) => renderTemplate`${t.contact.form.submit}` })} </form> </div> <!-- Contact Information --> <div> <h2 class="text-3xl lg:text-4xl font-bold mb-4 text-brand-primary uppercase"> ${t.contact.title} </h2> <p class="text-gray-600 mb-8"> ${t.contact.description} </p> <div class="space-y-6"> <!-- Address --> <div class="flex gap-4"> <div class="flex-shrink-0 w-6 h-6"> <img src="/images/Landing/property-location.svg" alt="Location" class="w-full h-full"> </div> <div class="text-gray-600"> ${contactInfo.address.map((line) => renderTemplate`<p>${line}</p>`)} </div> </div> <!-- Phone --> <div class="flex gap-4"> <div class="flex-shrink-0 w-6 h-6"> <img src="/images/Landing/mobile-chat.svg" alt="Phone" class="w-full h-full"> </div> <div class="text-gray-600"> ${contactInfo.phone.map((phone) => renderTemplate`<p>${phone}</p>`)} </div> </div> <!-- Email --> <div class="flex gap-4"> <div class="flex-shrink-0 w-6 h-6"> <img src="/images/Landing/email.svg" alt="Email" class="w-full h-full"> </div> <a${addAttribute(`mailto:${contactInfo.email}`, "href")} class="text-gray-600 hover:text-bmg-primary transition-colors"> ${contactInfo.email} </a> </div> <!-- Social Links --> <div class="pt-4 space-y-4"> ${contactInfo.socials.map((social) => renderTemplate`<a${addAttribute(social.url, "href")} target="_blank" rel="noopener noreferrer" class="flex items-center gap-4 hover:opacity-70 transition-opacity group"> <div class="w-8 h-8 flex items-center justify-center"> <img${addAttribute(`/images/Landing/${social.icon}.svg`, "src")}${addAttribute(social.name, "alt")} class="w-full h-full"> </div> <span class="text-gray-600 group-hover:text-bmg-primary transition-colors">${social.handle}</span> </a>`)} </div> </div> </div> </div> ` }), defineScriptVars({ validationTranslations }));
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/Contact.astro", void 0);

export { $$Contact as $ };
