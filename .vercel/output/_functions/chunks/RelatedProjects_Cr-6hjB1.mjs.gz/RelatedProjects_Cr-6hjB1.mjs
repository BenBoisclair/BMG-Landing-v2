import { c as createAstro, a as createComponent, m as maybeRenderHead, d as addAttribute, b as renderTemplate } from './astro/server_Dl93DeC-.mjs';
import 'piccolore';
import 'clsx';
import { u as useI18n, c as getLocalizedPath } from './Footer_BB2aWlch.mjs';
import { p as projectsData } from './projects__2OPjxaC.mjs';
/* empty css                          */

const $$Astro$3 = createAstro("https://bmg-granite.com");
const $$ProjectDetailHero = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$ProjectDetailHero;
  const { heroImage, projectName } = Astro2.props;
  const { t, lang } = useI18n(Astro2.url);
  const backPath = getLocalizedPath(lang, "/projects");
  return renderTemplate`${maybeRenderHead()}<section class="relative h-[200px] pt-20 lg:pt-24"> <!-- Background Image --> <div class="absolute inset-0 z-0"> <img src="/images/Product/7b7fd75f2e187f580cfdc947187b80e2a1b9669f.png"${addAttribute(projectName, "alt")} class="w-full h-full object-cover" fetchpriority="high" loading="eager" decoding="async"> </div> </section> <!-- Back Button and Project Title --> <div class="bg-white py-8 lg:py-12"> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"> <!-- Back Button --> <a${addAttribute(backPath, "href")} class="inline-flex items-center gap-2 px-6 py-3 bg-brand-primary text-white rounded-lg shadow-sm hover:bg-brand-primary/90 transition-colors mb-6"> <span class="rotate-180 text-lg">→</span> <span class="font-medium">${t.projectDetail.back}</span> </a> <!-- Project Name --> <h1 class="text-4xl lg:text-5xl font-semibold text-brand-primary text-center tracking-tight"> ${projectName} </h1> </div> </div> <!-- Hero Image --> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8"> <div class="w-full rounded-[29px] overflow-hidden"> <img${addAttribute(heroImage, "src")}${addAttribute(projectName, "alt")} class="w-full h-auto max-h-[780px] object-cover" loading="eager" decoding="async"> </div> </div>`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/ProjectDetailHero.astro", void 0);

const $$Astro$2 = createAstro("https://bmg-granite.com");
const $$ProjectDetailContent = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$ProjectDetailContent;
  const { artTitle, description, material, customer, location } = Astro2.props;
  const { t, isRTL } = useI18n(Astro2.url);
  const paragraphs = description.split("\n\n").filter((p) => p.trim());
  return renderTemplate`${maybeRenderHead()}<section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16"> <div${addAttribute(`grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 ${isRTL ? "lg:flex-row-reverse" : ""}`, "class")}> <!-- Left Column: Art Title and Description --> <div class="space-y-6"> <h2 class="text-4xl lg:text-6xl font-bold text-brand-primary tracking-tight leading-tight"> ${artTitle} </h2> <div class="space-y-4 text-lg text-gray-700 leading-relaxed"> ${paragraphs.map((paragraph) => renderTemplate`<p>${paragraph}</p>`)} </div> </div> <!-- Right Column: Project Metadata --> <div${addAttribute(`flex flex-col justify-center ${isRTL ? "lg:border-r lg:border-l-0" : "lg:border-l"} border-gray-300 lg:pl-12 rtl:lg:pr-12 rtl:lg:pl-0`, "class")}> <div class="space-y-8"> <!-- Material --> <div class="flex items-start gap-3"> <div class="flex-shrink-0 w-8 h-8 text-brand-primary"> <svg viewBox="0 0 24 24" fill="currentColor" class="w-full h-full"> <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"></path> </svg> </div> <div> <span class="text-xl font-semibold text-brand-primary">${t.projectDetail.material}:</span> <span class="text-xl text-gray-700 ml-2">${material}</span> </div> </div> <!-- Customer --> <div class="flex items-start gap-3"> <div class="flex-shrink-0 w-8 h-8 text-brand-primary"> <svg viewBox="0 0 24 24" fill="currentColor" class="w-full h-full"> <path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"></path> </svg> </div> <div> <span class="text-xl font-semibold text-brand-primary">${t.projectDetail.customer}:</span> <span class="text-xl text-gray-700 ml-2">${customer}</span> </div> </div> <!-- Location --> <div class="flex items-start gap-3"> <div class="flex-shrink-0 w-8 h-8 text-brand-primary"> <svg viewBox="0 0 24 24" fill="currentColor" class="w-full h-full"> <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"></path> </svg> </div> <div> <span class="text-xl font-semibold text-brand-primary">${t.projectDetail.location}:</span> <span class="text-xl text-gray-700 ml-2">${location}</span> </div> </div> </div> </div> </div> </section>`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/ProjectDetailContent.astro", void 0);

const $$Astro$1 = createAstro("https://bmg-granite.com");
const $$ProjectDetailGallery = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$ProjectDetailGallery;
  const { images, projectName } = Astro2.props;
  const { t } = useI18n(Astro2.url);
  const hasImages = images && images.length > 0;
  return renderTemplate`${maybeRenderHead()}<section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16"> <h2 class="text-4xl lg:text-5xl font-semibold text-brand-primary tracking-tight mb-8"> ${t.projectDetail.gallery} </h2> ${hasImages ? renderTemplate`<!-- Masonry Grid with actual images -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"> ${images.map((image, index) => renderTemplate`<div${addAttribute(`rounded-[30px] overflow-hidden ${index % 5 === 0 ? "md:col-span-2 aspect-[2/1]" : "aspect-square"}`, "class")}> <img${addAttribute(image, "src")}${addAttribute(`${projectName} gallery image ${index + 1}`, "alt")} class="w-full h-full object-cover hover:scale-105 transition-transform duration-300" loading="lazy" decoding="async"> </div>`)} </div>` : renderTemplate`<!-- Placeholder Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"> <!-- Row 1: 3 square images --> <div class="bg-gray-200 rounded-[30px] aspect-square"></div> <div class="bg-gray-200 rounded-[30px] aspect-square"></div> <div class="bg-gray-200 rounded-[30px] aspect-square"></div> <!-- Row 2: Wide image + square --> <div class="bg-gray-200 rounded-[30px] md:col-span-2 aspect-[2/1]"></div> <div class="bg-gray-200 rounded-[30px] aspect-square"></div> <!-- Row 3: Square + tall + square --> <div class="bg-gray-200 rounded-[30px] aspect-square"></div> <div class="bg-gray-200 rounded-[30px] md:row-span-2 aspect-square md:aspect-auto md:h-full"></div> <div class="bg-gray-200 rounded-[30px] aspect-square"></div> <!-- Row 4: 2 squares --> <div class="bg-gray-200 rounded-[30px] aspect-square"></div> <div class="bg-gray-200 rounded-[30px] aspect-square"></div> </div>`} </section>`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/ProjectDetailGallery.astro", void 0);

const $$Astro = createAstro("https://bmg-granite.com");
const $$RelatedProjects = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$RelatedProjects;
  const { currentProjectId, count = 3 } = Astro2.props;
  const { t, lang } = useI18n(Astro2.url);
  const allProjects = projectsData.projectTypes.flatMap((type) => type.projects);
  const otherProjects = allProjects.filter((p) => p.id !== currentProjectId);
  const shuffled = otherProjects.sort(() => Math.random() - 0.5);
  const relatedProjects = shuffled.slice(0, count);
  const getProjectName = (projectId) => {
    const projectTranslations = t.project.projects;
    return projectTranslations[projectId]?.name || projectId;
  };
  return renderTemplate`${maybeRenderHead()}<section class="py-12 lg:py-16" data-astro-cid-vyvpavng> <!-- Title (centered, outside blue) --> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-8 text-center" data-astro-cid-vyvpavng> <h2 class="text-3xl lg:text-4xl font-bold text-brand-primary uppercase tracking-tight" data-astro-cid-vyvpavng> ${t.projectDetail.relatedProjects} </h2> </div> <!-- Overlap Container --> <div class="relative" data-astro-cid-vyvpavng> <!-- Blue Background Block (absolute positioned) --> <div class="blue-background-block absolute left-4 right-4 lg:left-12 lg:right-12 bg-brand-primary" data-astro-cid-vyvpavng></div> <!-- Content Wrapper (relative with cards overlapping) --> <div class="relative projects-wrapper" data-astro-cid-vyvpavng> <!-- Cards Grid --> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" data-astro-cid-vyvpavng> <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 relative z-10" data-astro-cid-vyvpavng> ${relatedProjects.map((project) => renderTemplate`<a${addAttribute(getLocalizedPath(lang, `/projects/${project.id}`), "href")} class="project-card block" data-astro-cid-vyvpavng> <div class="aspect-[4/3] overflow-hidden" data-astro-cid-vyvpavng> <img${addAttribute(project.image, "src")}${addAttribute(getProjectName(project.id), "alt")} class="w-full h-full object-cover" loading="lazy" decoding="async" data-astro-cid-vyvpavng> </div> <div class="p-4 text-center" data-astro-cid-vyvpavng> <h3 class="project-title" data-astro-cid-vyvpavng> ${getProjectName(project.id)} </h3> </div> </a>`)} </div> </div> <!-- Back Button (inside blue area) --> <div class="flex justify-center mt-12 pb-12 relative z-10" data-astro-cid-vyvpavng> <a${addAttribute(getLocalizedPath(lang, "/projects"), "href")} class="back-button" data-astro-cid-vyvpavng> <span class="rotate-180 text-lg" data-astro-cid-vyvpavng>→</span> <span class="font-medium" data-astro-cid-vyvpavng>${t.projectDetail.back}</span> </a> </div> </div> </div> </section> `;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/RelatedProjects.astro", void 0);

export { $$ProjectDetailHero as $, $$ProjectDetailContent as a, $$ProjectDetailGallery as b, $$RelatedProjects as c };
