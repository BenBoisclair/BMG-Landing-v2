import { e as createAstro, f as createComponent, m as maybeRenderHead, h as addAttribute, r as renderTemplate } from './astro/server_DN3y_WhJ.mjs';
import 'piccolore';
import 'clsx';
import { u as useI18n, c as getLocalizedPath } from './Footer_B0yHRcuM.mjs';
import { m as materialsData } from './materials_BRasuCpm.mjs';
/* empty css                        */

const $$Astro$2 = createAstro("https://bmg-granite.com");
const $$MaterialDetailHero = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$MaterialDetailHero;
  const { heroImage, materialName } = Astro2.props;
  const { t, lang } = useI18n(Astro2.url);
  const backPath = getLocalizedPath(lang, "/materials");
  return renderTemplate`${maybeRenderHead()}<section class="relative h-[200px] pt-20 lg:pt-24"> <!-- Background Image --> <div class="absolute inset-0 z-0"> <img src="/images/Product/7b7fd75f2e187f580cfdc947187b80e2a1b9669f.png"${addAttribute(materialName, "alt")} class="w-full h-full object-cover" fetchpriority="high" loading="eager" decoding="async"> </div> </section> <!-- Back Button and Material Title --> <div class="bg-white py-8 lg:py-12"> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"> <!-- Back Button --> <a${addAttribute(backPath, "href")} class="inline-flex items-center gap-2 px-6 py-3 bg-brand-primary text-white rounded-lg shadow-sm hover:bg-brand-primary/90 transition-colors mb-6"> <span class="rotate-180 text-lg">→</span> <span class="font-medium">${t.materials.detail.back}</span> </a> <!-- Material Name --> <h1 class="text-4xl lg:text-5xl font-semibold text-brand-primary text-center tracking-tight"> ${materialName} </h1> </div> </div> <!-- Hero Image --> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8"> <div class="w-full rounded-[29px] overflow-hidden"> <img${addAttribute(heroImage, "src")}${addAttribute(materialName, "alt")} class="w-full h-auto max-h-[780px] object-cover" loading="eager" decoding="async"> </div> </div>`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/MaterialDetailHero.astro", void 0);

const $$Astro$1 = createAstro("https://bmg-granite.com");
const $$MaterialDetailContent = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$MaterialDetailContent;
  const { artTitle, description } = Astro2.props;
  const { isRTL } = useI18n(Astro2.url);
  const paragraphs = description.split("\n\n").filter((p) => p.trim());
  return renderTemplate`${maybeRenderHead()}<section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16"> <div${addAttribute(`max-w-3xl ${isRTL ? "mr-0" : "ml-0"}`, "class")}> <!-- Art Title --> <h2 class="text-3xl lg:text-4xl font-semibold text-brand-primary tracking-tight mb-6"> ${artTitle} </h2> <!-- Description --> <div class="space-y-4 text-gray-600 leading-relaxed"> ${paragraphs.length > 0 ? paragraphs.map((paragraph) => renderTemplate`<p>${paragraph}</p>`) : renderTemplate`<p>${description}</p>`} </div> </div> </section>`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/MaterialDetailContent.astro", void 0);

const $$Astro = createAstro("https://bmg-granite.com");
const $$RelatedMaterials = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$RelatedMaterials;
  const { currentMaterialId, currentCategory, count = 3 } = Astro2.props;
  const { t, lang } = useI18n(Astro2.url);
  const category = materialsData.categories.find((c) => c.id === currentCategory);
  const sameCategoryMaterials = category?.materials.filter((m) => m.id !== currentMaterialId) || [];
  let relatedMaterials = [...sameCategoryMaterials];
  if (relatedMaterials.length < count) {
    const otherMaterials = materialsData.categories.filter((c) => c.id !== currentCategory).flatMap((c) => c.materials);
    const shuffledOthers = otherMaterials.sort(() => Math.random() - 0.5);
    relatedMaterials = [...relatedMaterials, ...shuffledOthers].slice(0, count);
  } else {
    relatedMaterials = relatedMaterials.sort(() => Math.random() - 0.5).slice(0, count);
  }
  const getMaterialName = (materialId) => {
    const materialTranslations = t.materials.items;
    return materialTranslations[materialId]?.name || materialId;
  };
  return renderTemplate`${maybeRenderHead()}<section class="py-12 lg:py-16" data-astro-cid-coy7kswx> <!-- Title (centered, outside blue) --> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-8 text-center" data-astro-cid-coy7kswx> <h2 class="text-3xl lg:text-4xl font-bold text-brand-primary uppercase tracking-tight" data-astro-cid-coy7kswx> ${t.materials.detail.similarMaterials} </h2> </div> <!-- Overlap Container --> <div class="relative" data-astro-cid-coy7kswx> <!-- Blue Background Block (absolute positioned) --> <div class="blue-background-block absolute left-4 right-4 lg:left-12 lg:right-12 bg-brand-primary" data-astro-cid-coy7kswx></div> <!-- Content Wrapper (relative with cards overlapping) --> <div class="relative materials-wrapper" data-astro-cid-coy7kswx> <!-- Cards Grid --> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" data-astro-cid-coy7kswx> <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 relative z-10" data-astro-cid-coy7kswx> ${relatedMaterials.map((material) => renderTemplate`<a${addAttribute(getLocalizedPath(lang, `/materials/${material.id}`), "href")} class="material-card block" data-astro-cid-coy7kswx> <div class="aspect-[4/3] overflow-hidden" data-astro-cid-coy7kswx> <img${addAttribute(material.image, "src")}${addAttribute(getMaterialName(material.id), "alt")} class="w-full h-full object-cover" loading="lazy" decoding="async" data-astro-cid-coy7kswx> </div> <div class="p-4 text-center" data-astro-cid-coy7kswx> <h3 class="material-title" data-astro-cid-coy7kswx> ${getMaterialName(material.id)} </h3> </div> </a>`)} </div> </div> <!-- Back Button (inside blue area) --> <div class="flex justify-center mt-12 pb-12 relative z-10" data-astro-cid-coy7kswx> <a${addAttribute(getLocalizedPath(lang, "/materials"), "href")} class="back-button" data-astro-cid-coy7kswx> <span class="rotate-180 text-lg" data-astro-cid-coy7kswx>→</span> <span class="font-medium" data-astro-cid-coy7kswx>${t.materials.detail.back}</span> </a> </div> </div> </div> </section> `;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/RelatedMaterials.astro", void 0);

export { $$MaterialDetailHero as $, $$MaterialDetailContent as a, $$RelatedMaterials as b };
