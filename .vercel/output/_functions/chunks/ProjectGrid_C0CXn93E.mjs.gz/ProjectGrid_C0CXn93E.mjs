import { c as createAstro, a as createComponent, m as maybeRenderHead, d as addAttribute, b as renderTemplate, r as renderComponent, e as renderScript } from './astro/server_Dl93DeC-.mjs';
import 'piccolore';
import 'clsx';
import { u as useI18n, c as getLocalizedPath } from './Footer_BB2aWlch.mjs';
import { p as projectsData } from './projects__2OPjxaC.mjs';
/* empty css                         */

const $$Astro$2 = createAstro("https://bmg-granite.com");
const $$ProjectHero = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$ProjectHero;
  const { t } = useI18n(Astro2.url);
  return renderTemplate`${maybeRenderHead()}<section id="project-hero" class="relative h-[200px] pt-20 lg:pt-24"> <!-- Background Image - Different from landing page --> <div class="absolute inset-0 z-0"> <img src="/images/Product/7b7fd75f2e187f580cfdc947187b80e2a1b9669f.png"${addAttribute(t.project.heroAlt, "alt")} class="w-full h-full object-cover" fetchpriority="high" loading="eager" decoding="async"> </div> </section> <!-- Page Title - Positioned below the hero --> <div class="bg-white py-8 lg:py-12"> <h1 class="text-4xl lg:text-5xl font-semibold text-brand-primary text-center tracking-tight"> ${t.project.title} </h1> </div>`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/ProjectHero.astro", void 0);

const $$Astro$1 = createAstro("https://bmg-granite.com");
const $$ProjectCard = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$ProjectCard;
  const { image, name, categories, categoryLabels, href } = Astro2.props;
  const Tag = href ? "a" : "div";
  return renderTemplate`${renderComponent($$result, "Tag", Tag, { "href": href, "class": "relative block w-full aspect-square rounded-lg overflow-hidden group cursor-pointer" }, { "default": ($$result2) => renderTemplate`  ${maybeRenderHead()}<img${addAttribute(image, "src")}${addAttribute(name, "alt")} class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" loading="lazy" decoding="async">  <div class="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent"></div>  <div class="absolute bottom-0 left-0 right-0 p-6"> <h3 class="text-lg font-medium text-white mb-4 leading-6">${name}</h3> <div class="flex flex-wrap gap-2"> ${categories.map((cat) => renderTemplate`<span class="px-2 py-0.5 border border-white/25 rounded-full text-xs text-white"> ${categoryLabels[cat]} </span>`)} </div> </div> ` })}`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/ui/ProjectCard.astro", void 0);

const $$Astro = createAstro("https://bmg-granite.com");
const $$ProjectGrid = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$ProjectGrid;
  const { t, lang } = useI18n(Astro2.url);
  const categoryLabels = {};
  for (const cat of projectsData.categories) {
    categoryLabels[cat] = t.project.types[cat];
  }
  const getProjectPath = (projectId) => getLocalizedPath(lang, `/projects/${projectId}`);
  return renderTemplate`${maybeRenderHead()}<section class="py-12 lg:py-16 bg-white"> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"> ${projectsData.projectTypes.map((projectType, index) => renderTemplate`<div class="mb-12 last:mb-0"> <!-- Section Title --> <h2 class="text-3xl lg:text-4xl font-semibold text-brand-primary mb-8 tracking-tight"> ${t.project.sections[projectType.id].title} </h2> <!-- Swiper Carousel --> <div class="project-swiper-container"> <div class="swiper project-swiper"${addAttribute(`swiper-${index}`, "data-swiper-id")}> <div class="swiper-wrapper"> ${projectType.projects.map((project) => renderTemplate`<div class="swiper-slide"> ${renderComponent($$result, "ProjectCard", $$ProjectCard, { "image": project.image, "name": t.project.projects[project.id]?.name || project.id, "categories": project.categories, "categoryLabels": categoryLabels, "href": getProjectPath(project.id) })} </div>`)} </div> </div> <!-- Navigation Arrows --> <div class="flex gap-4 mt-6"> <button class="swiper-btn-prev p-3 rounded-full bg-brand-primary text-white hover:bg-brand-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"${addAttribute(t.project.pagination.prev, "aria-label")}${addAttribute(`swiper-${index}`, "data-swiper-target")}> <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path> </svg> </button> <button class="swiper-btn-next p-3 rounded-full bg-brand-primary text-white hover:bg-brand-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"${addAttribute(t.project.pagination.next, "aria-label")}${addAttribute(`swiper-${index}`, "data-swiper-target")}> <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path> </svg> </button> </div> </div> </div>`)} </div> </section> ${renderScript($$result, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/ProjectGrid.astro?astro&type=script&index=0&lang.ts")} `;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/ProjectGrid.astro", void 0);

export { $$ProjectHero as $, $$ProjectGrid as a };
