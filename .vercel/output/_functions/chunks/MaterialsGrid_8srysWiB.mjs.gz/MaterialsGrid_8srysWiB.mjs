import { e as createAstro, f as createComponent, m as maybeRenderHead, h as addAttribute, n as renderScript, r as renderTemplate } from './astro/server_DN3y_WhJ.mjs';
import 'piccolore';
import 'clsx';
import { u as useI18n, c as getLocalizedPath } from './Footer_B0yHRcuM.mjs';
/* empty css                             */

const $$Astro$2 = createAstro("https://bmg-granite.com");
const $$MaterialsTabs = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$MaterialsTabs;
  const { categories } = Astro2.props;
  const { t, dir } = useI18n(Astro2.url);
  const gradeLabels = {
    "A++": t.materials.grades?.app || "A++ Grade",
    "A+": t.materials.grades?.ap || "A+ Grade",
    "A": t.materials.grades?.a || "A Grade"
  };
  return renderTemplate`${maybeRenderHead()}<div class="materials-tabs-container"${addAttribute(dir === "rtl" ? "true" : "false", "data-rtl")} data-astro-cid-t2lobyjl> <nav class="tabs-nav bg-white rounded-full shadow-lg p-2 inline-flex gap-2" role="tablist" aria-label="Material grades" data-astro-cid-t2lobyjl> ${categories.map((category, index) => renderTemplate`<button role="tab"${addAttribute(index === 0 ? "true" : "false", "aria-selected")}${addAttribute(`panel-${category.id}`, "aria-controls")}${addAttribute(category.id, "data-tab")}${addAttribute(category.tier, "data-tier")}${addAttribute(category.label, "data-label")} class="tab-btn px-6 py-3 rounded-full font-medium text-base transition-all duration-200" data-astro-cid-t2lobyjl> ${gradeLabels[category.tier] || `${category.tier} Grade`} </button>`)} </nav> </div> ${renderScript($$result, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/ui/MaterialsTabs.astro?astro&type=script&index=0&lang.ts")} `;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/ui/MaterialsTabs.astro", void 0);

const $$Astro$1 = createAstro("https://bmg-granite.com");
const $$MaterialsFilter = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$MaterialsFilter;
  const { t } = useI18n(Astro2.url);
  const filterOptions = [
    { id: "all", label: t.materials.filterOptions?.allTypes || "All Types" },
    { id: "marble", label: t.materials.filterOptions?.marble || "Marble" },
    { id: "granite", label: t.materials.filterOptions?.granite || "Granite" },
    { id: "onyx", label: t.materials.filterOptions?.onyx || "Onyx" },
    { id: "semi-precious", label: t.materials.filterOptions?.semiPrecious || "Semi-Precious" }
  ];
  return renderTemplate`${maybeRenderHead()}<div class="materials-filter-container" data-astro-cid-bylr6iol> <button class="filter-btn bg-white rounded-full shadow-lg px-6 py-3 flex items-center gap-2 hover:shadow-xl transition-shadow duration-200" aria-haspopup="listbox" aria-expanded="false" data-astro-cid-bylr6iol> <!-- Filter Icon --> <svg class="w-5 h-5 text-[#364153]" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" data-astro-cid-bylr6iol> <path d="M5 10H15M2.5 5H17.5M7.5 15H12.5" stroke="currentColor" stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round" data-astro-cid-bylr6iol></path> </svg> <span class="filter-label font-medium text-[#364153]" data-astro-cid-bylr6iol>${t.materials.filter || "Filter"}</span> </button> <!-- Dropdown Menu --> <div class="filter-dropdown hidden absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl py-2 z-50" data-astro-cid-bylr6iol> ${filterOptions.map((option, index) => renderTemplate`<button${addAttribute([
    "filter-option w-full px-4 py-2 text-left text-sm hover:bg-gray-50 transition-colors",
    index === 0 ? "text-[#155dfc] font-medium" : "text-[#364153]"
  ], "class:list")}${addAttribute(option.id, "data-filter")}${addAttribute(index === 0 ? "true" : "false", "data-selected")} data-astro-cid-bylr6iol> ${option.label} </button>`)} </div> </div> ${renderScript($$result, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/ui/MaterialsFilter.astro?astro&type=script&index=0&lang.ts")} `;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/ui/MaterialsFilter.astro", void 0);

const $$Astro = createAstro("https://bmg-granite.com");
const $$MaterialsGrid = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$MaterialsGrid;
  const { materials, categoryId } = Astro2.props;
  const { t, lang } = useI18n(Astro2.url);
  return renderTemplate`${maybeRenderHead()}<div class="materials-grid-container"${addAttribute(categoryId, "data-category")} data-astro-cid-7otulvkn> <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" data-astro-cid-7otulvkn> ${materials.map((material) => {
    const materialName = t.materials.items[material.id]?.name || material.id;
    return renderTemplate`<a${addAttribute(getLocalizedPath(lang, `/materials/${material.id}`), "href")} class="material-card-wrapper group"${addAttribute(material.id, "data-material-id")} data-astro-cid-7otulvkn> <div class="material-card bg-white rounded-[10px] overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300" data-astro-cid-7otulvkn> <div class="aspect-[4/3] overflow-hidden" data-astro-cid-7otulvkn> <img${addAttribute(material.image, "src")}${addAttribute(materialName, "alt")} class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" loading="lazy" data-astro-cid-7otulvkn> </div> </div> <h3 class="material-name text-center mt-3 text-lg font-semibold text-[#101828]" data-astro-cid-7otulvkn> ${materialName} </h3> </a>`;
  })} </div> </div> `;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/MaterialsGrid.astro", void 0);

export { $$MaterialsTabs as $, $$MaterialsFilter as a, $$MaterialsGrid as b };
