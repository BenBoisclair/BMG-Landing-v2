import { e as createAstro, f as createComponent, m as maybeRenderHead, h as addAttribute, r as renderTemplate } from './astro/server_DN3y_WhJ.mjs';
import 'piccolore';
import 'clsx';
import { u as useI18n } from './Footer_B0yHRcuM.mjs';

const $$Astro = createAstro("https://bmg-granite.com");
const $$ContactPageHero = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$ContactPageHero;
  const { t } = useI18n(Astro2.url);
  return renderTemplate`${maybeRenderHead()}<section id="contact-hero" class="relative h-[200px] pt-20 lg:pt-24"> <!-- Background Image --> <div class="absolute inset-0 z-0"> <img src="/images/Product/7b7fd75f2e187f580cfdc947187b80e2a1b9669f.png"${addAttribute(t.contactPage.heroAlt, "alt")} class="w-full h-full object-cover" fetchpriority="high" loading="eager" decoding="async"> </div> </section> <!-- Page Title - Positioned below the hero --> <div class="bg-white py-8 lg:py-12"> <h1 class="text-4xl lg:text-5xl font-semibold text-brand-primary text-center tracking-tight"> ${t.contactPage.title} </h1> </div>`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/ContactPageHero.astro", void 0);

export { $$ContactPageHero as $ };
