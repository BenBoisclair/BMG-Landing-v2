import { e as createAstro, f as createComponent, m as maybeRenderHead, h as addAttribute, l as renderScript, r as renderTemplate } from './astro/server_C-hQQPI9.mjs';
import 'piccolore';
import 'clsx';
import { u as useI18n, c as getLocalizedPath } from './Footer_BplOwl4A.mjs';
/* empty css                             */

const $$Astro = createAstro("https://bmg-granite.com");
const $$MaterialCarousel = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$MaterialCarousel;
  const { categoryId, materials, index } = Astro2.props;
  const { t, dir, lang } = useI18n(Astro2.url);
  const category = t.materials.categories[categoryId];
  const categoryTitle = `${category.title} (${category.tier})`;
  const materialsData = materials.map((m) => ({
    id: m.id,
    image: m.image,
    name: t.materials.items[m.id]?.name || m.id,
    description: t.materials.items[m.id]?.description || ""
  }));
  return renderTemplate`${maybeRenderHead()}<section class="py-8 sm:py-10 md:py-12 lg:py-16"> <div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 lg:px-8"> <!-- Section Title --> <h2 class="text-2xl sm:text-3xl md:text-3xl lg:text-4xl font-semibold text-brand-primary mb-6 sm:mb-8 text-center tracking-tight"> ${categoryTitle} </h2> <!-- Overflow Wrapper - clips horizontal overflow while preserving coverflow effect --> <div class="overflow-x-clip"> <!-- Swiper Carousel Container --> <div class="material-carousel-container"${addAttribute(index, "data-carousel-index")}${addAttribute(JSON.stringify(materialsData), "data-materials")}${addAttribute(dir === "rtl" ? "true" : "false", "data-rtl")}> <div class="swiper material-swiper"${addAttribute(`material-swiper-${index}`, "data-swiper-id")}> <div class="swiper-wrapper"> ${materials.map((material) => renderTemplate`<div class="swiper-slide material-slide"> <a${addAttribute(getLocalizedPath(lang, `/materials/${material.id}`), "href")} class="material-card block"> <img${addAttribute(material.image, "src")}${addAttribute(t.materials.items[material.id]?.name || material.id, "alt")} class="material-image" loading="lazy"> </a> </div>`)} </div> </div> <!-- Material Info Display --> <div class="material-info text-center mt-4 sm:mt-6"> <h3 class="material-name text-xl sm:text-2xl md:text-2xl lg:text-3xl font-bold text-gray-700 mb-2"> ${materialsData[0]?.name} </h3> <p class="material-description text-gray-500 text-xs sm:text-sm lg:text-base max-w-md mx-auto px-4"> ${materialsData[0]?.description} </p> </div> <!-- Navigation Controls --> <div class="flex justify-center items-center gap-8 mt-6"> <!-- Prev Arrow --> <button class="swiper-btn-prev p-2 text-gray-400 hover:text-gray-600 transition-colors disabled:opacity-30"${addAttribute(t.materials.pagination.prev, "aria-label")}${addAttribute(`material-swiper-${index}`, "data-swiper-target")}> <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path> </svg> </button> <!-- Pagination Dots --> <div class="swiper-pagination-custom flex items-center gap-2"${addAttribute(`material-swiper-${index}`, "data-pagination-target")}> ${materials.map((_, i) => renderTemplate`<button${addAttribute([
    "pagination-dot transition-all duration-300",
    i === 0 ? "active w-3 h-2 bg-gray-800 rounded-full" : "w-2 h-2 bg-gray-300 rounded-full hover:bg-gray-400"
  ], "class:list")}${addAttribute(i, "data-slide-index")}${addAttribute(`Go to slide ${i + 1}`, "aria-label")}></button>`)} </div> <!-- Next Arrow --> <button class="swiper-btn-next p-2 text-gray-400 hover:text-gray-600 transition-colors disabled:opacity-30"${addAttribute(t.materials.pagination.next, "aria-label")}${addAttribute(`material-swiper-${index}`, "data-swiper-target")}> <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path> </svg> </button> </div> </div> </div><!-- Close overflow-x-clip wrapper --> </div> </section> ${renderScript($$result, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/MaterialCarousel.astro?astro&type=script&index=0&lang.ts")} `;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/MaterialCarousel.astro", void 0);

export { $$MaterialCarousel as $ };
