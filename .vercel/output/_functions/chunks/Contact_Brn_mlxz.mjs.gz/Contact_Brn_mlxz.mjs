import { c as createAstro, a as createComponent, m as maybeRenderHead, d as addAttribute, b as renderTemplate, s as spreadAttributes, u as unescapeHTML, f as renderSlot, r as renderComponent, e as renderScript, g as defineScriptVars } from './astro/server_Dl93DeC-.mjs';
import 'piccolore';
import 'clsx';
import { u as useI18n } from './Footer_NnoDF9yt.mjs';
import { $ as $$Image } from './_astro_assets_DE6nL9g2.mjs';
/* empty css                         */

const $$Astro$b = createAstro("https://bmg-granite.com");
const $$Hero = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$b, $$props, $$slots);
  Astro2.self = $$Hero;
  const { t } = useI18n(Astro2.url);
  return renderTemplate`${maybeRenderHead()}<section id="home" class="relative h-screen min-h-[600px] max-h-[800px] pt-20 lg:pt-24"> <!-- Background Image --> <div class="absolute inset-0 z-0"> <img src="/images/Landing/HeroSection/background_1.png"${addAttribute(t.hero.backgroundAlt, "alt")} class="w-full h-full object-cover" fetchpriority="high" loading="eager" decoding="async"> <!-- Purple overlay --> <div class="absolute inset-0 bg-map-blue/20"></div> </div> <!-- Content --> <div class="relative z-10 h-full flex flex-col items-center justify-end pb-16 lg:pb-24 px-4"> <a href="#product" class="px-6 py-3 text-2xl font-medium font-inter text-white bg-brand-primary/87 rounded-lg shadow-sm hover:bg-brand-primary transition-colors duration-200"> ${t.hero.viewMore} </a> </div> </section>`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/Hero.astro", void 0);

function createSvgComponent({ meta, attributes, children }) {
  const Component = createComponent((_, props) => {
    const normalizedProps = normalizeProps(attributes, props);
    return renderTemplate`<svg${spreadAttributes(normalizedProps)}>${unescapeHTML(children)}</svg>`;
  });
  Object.defineProperty(Component, "toJSON", {
    value: () => meta,
    enumerable: false
  });
  return Object.assign(Component, meta);
}
const ATTRS_TO_DROP = ["xmlns", "xmlns:xlink", "version"];
const DEFAULT_ATTRS = {};
function dropAttributes(attributes) {
  for (const attr of ATTRS_TO_DROP) {
    delete attributes[attr];
  }
  return attributes;
}
function normalizeProps(attributes, props) {
  return dropAttributes({ ...DEFAULT_ATTRS, ...attributes, ...props });
}

const thumbnail1 = createSvgComponent({"meta":{"src":"/_astro/thumbnail-1.B5g8HyMK.svg","width":200,"height":200,"format":"svg"},"attributes":{"viewBox":"0 0 200 200","fill":"none"},"children":"\n  <defs>\n    <pattern id=\"granite1\" patternUnits=\"userSpaceOnUse\" width=\"20\" height=\"20\">\n      <rect width=\"20\" height=\"20\" fill=\"#374151\" />\n      <circle cx=\"5\" cy=\"5\" r=\"2\" fill=\"#4b5563\" opacity=\"0.6\" />\n      <circle cx=\"15\" cy=\"12\" r=\"1.5\" fill=\"#6b7280\" opacity=\"0.4\" />\n      <circle cx=\"8\" cy=\"16\" r=\"1\" fill=\"#9ca3af\" opacity=\"0.3\" />\n    </pattern>\n  </defs>\n  <rect width=\"200\" height=\"200\" fill=\"url(#granite1)\" />\n  <rect width=\"200\" height=\"200\" fill=\"#1f2937\" opacity=\"0.3\" />\n"});

const thumbnail2 = createSvgComponent({"meta":{"src":"/_astro/thumbnail-2.67qRhDCT.svg","width":200,"height":200,"format":"svg"},"attributes":{"viewBox":"0 0 200 200","fill":"none"},"children":"\n  <defs>\n    <pattern id=\"marble1\" patternUnits=\"userSpaceOnUse\" width=\"40\" height=\"40\">\n      <rect width=\"40\" height=\"40\" fill=\"#f3f4f6\" />\n      <path d=\"M0 20 Q10 15 20 20 T40 20\" stroke=\"#d1d5db\" stroke-width=\"1\" fill=\"none\" opacity=\"0.5\" />\n      <path d=\"M0 30 Q15 25 30 30 T60 30\" stroke=\"#e5e7eb\" stroke-width=\"0.5\" fill=\"none\" opacity=\"0.4\" />\n    </pattern>\n  </defs>\n  <rect width=\"200\" height=\"200\" fill=\"url(#marble1)\" />\n  <rect width=\"200\" height=\"200\" fill=\"#e5e7eb\" opacity=\"0.2\" />\n"});

const thumbnail3 = createSvgComponent({"meta":{"src":"/_astro/thumbnail-3.D8qmQlur.svg","width":200,"height":200,"format":"svg"},"attributes":{"viewBox":"0 0 200 200","fill":"none"},"children":"\n  <defs>\n    <pattern id=\"granite2\" patternUnits=\"userSpaceOnUse\" width=\"25\" height=\"25\">\n      <rect width=\"25\" height=\"25\" fill=\"#78716c\" />\n      <circle cx=\"6\" cy=\"6\" r=\"2.5\" fill=\"#a8a29e\" opacity=\"0.5\" />\n      <circle cx=\"18\" cy=\"10\" r=\"2\" fill=\"#57534e\" opacity=\"0.6\" />\n      <circle cx=\"10\" cy=\"20\" r=\"1.5\" fill=\"#d6d3d1\" opacity=\"0.4\" />\n      <circle cx=\"22\" cy=\"22\" r=\"1\" fill=\"#44403c\" opacity=\"0.5\" />\n    </pattern>\n  </defs>\n  <rect width=\"200\" height=\"200\" fill=\"url(#granite2)\" />\n  <rect width=\"200\" height=\"200\" fill=\"#44403c\" opacity=\"0.2\" />\n"});

const $$Astro$a = createAstro("https://bmg-granite.com");
const $$Showcase = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$a, $$props, $$slots);
  Astro2.self = $$Showcase;
  const { t } = useI18n(Astro2.url);
  const images = [
    thumbnail1,
    thumbnail2,
    thumbnail3,
    thumbnail1,
    thumbnail2,
    thumbnail3
  ];
  return renderTemplate`${maybeRenderHead()}<section id="product" class="py-16 lg:py-24 bg-white"> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"> <div class="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center"> <!-- Text Content --> <div> <h2 class="text-4xl lg:text-5xl font-bold text-purple-800 mb-6 lowercase"> ${t.mission.title} </h2> <p class="text-gray-600 text-lg leading-relaxed"> ${t.mission.description} </p> </div> <!-- Image Grid (2x3) --> <div class="grid grid-cols-3 gap-4"> ${images.map((img, index) => renderTemplate`<img${addAttribute(img.src, "src")}${addAttribute(`Mission image ${index + 1}`, "alt")} width="200" height="200" loading="lazy" decoding="async" class="w-[200px] h-[200px] rounded-[22px] object-cover">`)} </div> </div> </div> </section>`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/Showcase.astro", void 0);

const $$Astro$9 = createAstro("https://bmg-granite.com");
const $$Button = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$9, $$props, $$slots);
  Astro2.self = $$Button;
  const {
    variant = "primary",
    size = "md",
    href,
    type = "button",
    class: className = ""
  } = Astro2.props;
  const baseClasses = "inline-flex items-center justify-center font-medium rounded-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2";
  const variantClasses = {
    primary: "bg-bmg-primary text-white hover:bg-bmg-secondary focus:ring-bmg-primary",
    secondary: "bg-bmg-gold text-white hover:bg-amber-600 focus:ring-bmg-gold",
    outline: "border-2 border-bmg-primary text-bmg-primary hover:bg-bmg-primary hover:text-white focus:ring-bmg-primary",
    process: "bg-brand-primary text-white hover:bg-brand-primary-hover focus:ring-brand-primary"
  };
  const sizeClasses = {
    sm: "px-4 py-2 text-sm",
    md: "px-6 py-3 text-base",
    lg: "px-8 py-4 text-lg"
  };
  const classes = `${baseClasses} ${variantClasses[variant]} ${sizeClasses[size]} ${className}`;
  return renderTemplate`${href ? renderTemplate`${maybeRenderHead()}<a${addAttribute(href, "href")}${addAttribute(classes, "class")}>${renderSlot($$result, $$slots["default"])}</a>` : renderTemplate`<button${addAttribute(type, "type")}${addAttribute(classes, "class")}>${renderSlot($$result, $$slots["default"])}</button>`}`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/ui/Button.astro", void 0);

const $$Astro$8 = createAstro("https://bmg-granite.com");
const $$ProcessStep = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$8, $$props, $$slots);
  Astro2.self = $$ProcessStep;
  const { number, title, description, icon } = Astro2.props;
  const iconSrc = typeof icon === "string" ? icon : icon?.src;
  return renderTemplate`${maybeRenderHead()}<div class="flex gap-4 lg:gap-6 items-start"> <div class="flex-shrink-0"> <span class="text-2xl lg:text-3xl font-bold text-bmg-gold">${number}</span> </div> <div class="flex-1"> <h3 class="text-lg lg:text-xl font-semibold text-gray-900 mb-2">${title}</h3> <p class="text-gray-600 text-sm lg:text-base leading-relaxed">${description}</p> </div> ${iconSrc && renderTemplate`<div class="hidden lg:block flex-shrink-0"> <div class="w-20 h-20 rounded-xl overflow-hidden bg-gray-200"> <img${addAttribute(iconSrc, "src")}${addAttribute(`Step ${number} icon`, "alt")} class="w-full h-full object-cover" width="80" height="80" loading="lazy" decoding="async"> </div> </div>`} </div>`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/ui/ProcessStep.astro", void 0);

const step01Icon = createSvgComponent({"meta":{"src":"/_astro/step-01.BvTYfNSK.svg","width":120,"height":120,"format":"svg"},"attributes":{"viewBox":"0 0 120 120","fill":"none"},"children":"\n  <rect width=\"120\" height=\"120\" rx=\"12\" fill=\"#e2e8f0\" />\n  <text x=\"60\" y=\"70\" text-anchor=\"middle\" font-family=\"system-ui, -apple-system, sans-serif\" font-size=\"36\" font-weight=\"600\" fill=\"#64748b\">01</text>\n"});

const step02Icon = createSvgComponent({"meta":{"src":"/_astro/step-02.DOS9Gcv7.svg","width":120,"height":120,"format":"svg"},"attributes":{"viewBox":"0 0 120 120","fill":"none"},"children":"\n  <rect width=\"120\" height=\"120\" rx=\"12\" fill=\"#e2e8f0\" />\n  <text x=\"60\" y=\"70\" text-anchor=\"middle\" font-family=\"system-ui, -apple-system, sans-serif\" font-size=\"36\" font-weight=\"600\" fill=\"#64748b\">02</text>\n"});

const step03Icon = createSvgComponent({"meta":{"src":"/_astro/step-03.CvigYaSr.svg","width":120,"height":120,"format":"svg"},"attributes":{"viewBox":"0 0 120 120","fill":"none"},"children":"\n  <rect width=\"120\" height=\"120\" rx=\"12\" fill=\"#e2e8f0\" />\n  <text x=\"60\" y=\"70\" text-anchor=\"middle\" font-family=\"system-ui, -apple-system, sans-serif\" font-size=\"36\" font-weight=\"600\" fill=\"#64748b\">03</text>\n"});

const step04Icon = createSvgComponent({"meta":{"src":"/_astro/step-04.DlvJ8cm1.svg","width":120,"height":120,"format":"svg"},"attributes":{"viewBox":"0 0 120 120","fill":"none"},"children":"\n  <rect width=\"120\" height=\"120\" rx=\"12\" fill=\"#e2e8f0\" />\n  <text x=\"60\" y=\"70\" text-anchor=\"middle\" font-family=\"system-ui, -apple-system, sans-serif\" font-size=\"36\" font-weight=\"600\" fill=\"#64748b\">04</text>\n"});

const step05Icon = createSvgComponent({"meta":{"src":"/_astro/step-05.BcnrrxKn.svg","width":120,"height":120,"format":"svg"},"attributes":{"viewBox":"0 0 120 120","fill":"none"},"children":"\n  <rect width=\"120\" height=\"120\" rx=\"12\" fill=\"#e2e8f0\" />\n  <text x=\"60\" y=\"70\" text-anchor=\"middle\" font-family=\"system-ui, -apple-system, sans-serif\" font-size=\"36\" font-weight=\"600\" fill=\"#64748b\">05</text>\n"});

const step06Icon = createSvgComponent({"meta":{"src":"/_astro/step-06.DwCY93Pd.svg","width":120,"height":120,"format":"svg"},"attributes":{"viewBox":"0 0 120 120","fill":"none"},"children":"\n  <rect width=\"120\" height=\"120\" rx=\"12\" fill=\"#e2e8f0\" />\n  <text x=\"60\" y=\"70\" text-anchor=\"middle\" font-family=\"system-ui, -apple-system, sans-serif\" font-size=\"36\" font-weight=\"600\" fill=\"#64748b\">06</text>\n"});

const processImage = new Proxy({"src":"/_astro/ProcessImage.Bc0KG5em.jpg","width":2304,"height":4096,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/Users/benedictboisclair/Projects/BMG-Landing-v2/public/images/Landing/ProcessImage.jpg";
							}
							
							return target[name];
						}
					});

const $$Astro$7 = createAstro("https://bmg-granite.com");
const $$Process = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$7, $$props, $$slots);
  Astro2.self = $$Process;
  const { t } = useI18n(Astro2.url);
  const steps = [
    {
      number: t.process.steps["1"].number,
      title: t.process.steps["1"].title,
      description: t.process.steps["1"].description,
      icon: step01Icon
    },
    {
      number: t.process.steps["2"].number,
      title: t.process.steps["2"].title,
      description: t.process.steps["2"].description,
      icon: step02Icon
    },
    {
      number: t.process.steps["3"].number,
      title: t.process.steps["3"].title,
      description: t.process.steps["3"].description,
      icon: step03Icon
    },
    {
      number: t.process.steps["4"].number,
      title: t.process.steps["4"].title,
      description: t.process.steps["4"].description,
      icon: step04Icon
    },
    {
      number: t.process.steps["5"].number,
      title: t.process.steps["5"].title,
      description: t.process.steps["5"].description,
      icon: step05Icon
    },
    {
      number: t.process.steps["6"].number,
      title: t.process.steps["6"].title,
      description: t.process.steps["6"].description,
      icon: step06Icon
    }
  ];
  return renderTemplate`${maybeRenderHead()}<section id="process" class="py-16 lg:py-24 bg-gray-50"> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"> <!-- Section Header --> <h2 class="text-3xl lg:text-4xl font-bold text-center mb-12 lg:mb-16 text-brand-primary"> ${t.process.title} </h2> <div class="grid lg:grid-cols-2 gap-8 lg:gap-12"> <!-- Left Column: Main Image + Description --> <div> <div class="aspect-[3/4] rounded-2xl overflow-hidden shadow-xl mb-6"> ${renderComponent($$result, "Image", $$Image, { "src": processImage, "alt": t.process.craftingAlt, "class": "w-full h-full object-cover", "widths": [400, 600, 800], "sizes": "(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 600px", "format": "webp", "quality": 80, "loading": "lazy", "decoding": "async" })} </div> <p class="text-gray-600 leading-relaxed"> ${t.process.description} </p> </div> <!-- Right Column: Process Steps with Icons --> <div class="space-y-6 lg:space-y-8"> ${steps.map((step) => renderTemplate`${renderComponent($$result, "ProcessStep", $$ProcessStep, { "number": step.number, "title": step.title, "description": step.description, "icon": step.icon })}`)} </div> </div> <!-- CTA Button --> <div class="text-center mt-12 lg:mt-16"> ${renderComponent($$result, "Button", $$Button, { "href": "#contact", "variant": "process" }, { "default": ($$result2) => renderTemplate`${t.process.learnMore}` })} </div> </div> </section>`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/Process.astro", void 0);

const $$Astro$6 = createAstro("https://bmg-granite.com");
const $$PriceEstimation = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$6, $$props, $$slots);
  Astro2.self = $$PriceEstimation;
  const { t } = useI18n(Astro2.url);
  return renderTemplate`${maybeRenderHead()}<section class="py-16 lg:py-24 bg-white" id="price-estimation"> <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8"> <!-- Section Header --> <h2 class="text-3xl lg:text-4xl font-bold text-center mb-8 text-brand-primary"> ${t.priceEstimation.title} </h2> <!-- Tab Container --> <div class="w-full"> <!-- Tab Buttons --> <div class="flex rounded-lg overflow-hidden border-2 border-brand-dark" role="tablist" aria-label="Price estimation calculator type"> <button id="bust-tab" role="tab" aria-selected="false" aria-controls="bust-panel" class="flex-1 py-4 px-6 text-xl lg:text-2xl font-semibold text-white bg-brand-medium hover:bg-brand-medium-hover transition-all duration-300 ease-out focus:outline-none focus:ring-2 focus:ring-brand-dark focus:ring-offset-2" data-tab="bust"> ${t.priceEstimation.bust.tab} </button> <button id="relief-tab" role="tab" aria-selected="false" aria-controls="relief-panel" class="flex-1 py-4 px-6 text-xl lg:text-2xl font-semibold text-white bg-brand-medium hover:bg-brand-medium-hover transition-all duration-300 ease-out focus:outline-none focus:ring-2 focus:ring-brand-dark focus:ring-offset-2" data-tab="relief"> ${t.priceEstimation.relief.tab} </button> </div> <!-- Tab Panels --> <!-- Bust Calculator Panel --> <div id="bust-panel" role="tabpanel" aria-labelledby="bust-tab" class="mt-6 p-6 bg-gray-50 rounded-lg border border-gray-200 hidden"> <h3 class="text-xl font-semibold text-brand-dark mb-4">${t.priceEstimation.bust.title}</h3> <!-- Stone Grade Selection --> <div class="mb-6"> <label class="block text-sm font-medium text-gray-700 mb-2">${t.priceEstimation.stoneGrade}</label> <div class="grid grid-cols-3 gap-3" role="radiogroup"${addAttribute(t.priceEstimation.stoneGrade, "aria-label")}> <button class="bust-grade-btn px-4 py-3 border-2 border-brand-dark rounded-lg text-brand-dark hover:bg-brand-dark hover:text-white transition-colors" data-grade="A" data-price="0.10" role="radio" aria-checked="false"> <span class="block font-semibold">${t.priceEstimation.grades.a.label}</span> <span class="block text-sm opacity-75">${t.priceEstimation.grades.a.description}</span> </button> <button class="bust-grade-btn px-4 py-3 border-2 border-brand-dark rounded-lg text-brand-dark hover:bg-brand-dark hover:text-white transition-colors" data-grade="AA" data-price="0.15" role="radio" aria-checked="false"> <span class="block font-semibold">${t.priceEstimation.grades.aa.label}</span> <span class="block text-sm opacity-75">${t.priceEstimation.grades.aa.description}</span> </button> <button class="bust-grade-btn px-4 py-3 border-2 border-brand-dark rounded-lg text-brand-dark hover:bg-brand-dark hover:text-white transition-colors" data-grade="AA+" data-price="0.25" role="radio" aria-checked="false"> <span class="block font-semibold">${t.priceEstimation.grades.aaPlus.label}</span> <span class="block text-sm opacity-75">${t.priceEstimation.grades.aaPlus.description}</span> </button> </div> </div> <!-- Dimension Inputs --> <div class="mb-6"> <label class="block text-sm font-medium text-gray-700 mb-2">${t.priceEstimation.dimensions}</label> <div class="grid grid-cols-3 gap-4"> <!-- Length Input --> <div class="dimension-input-group"> <label for="bust-length" class="block text-xs text-gray-500 mb-1">${t.priceEstimation.length}</label> <div class="relative"> <input type="number" id="bust-length" name="bust-length" min="1" max="50" step="0.1" class="dimension-input w-full h-12 px-3 pr-10 border-2 border-gray-300 rounded-lg text-lg font-semibold text-center focus:outline-none focus:border-brand-dark focus:ring-2 focus:ring-brand-dark/20 transition-colors" placeholder="0" aria-describedby="bust-length-unit"> <span id="bust-length-unit" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm pointer-events-none">cm</span> </div> </div> <!-- Width Input --> <div class="dimension-input-group"> <label for="bust-width" class="block text-xs text-gray-500 mb-1">${t.priceEstimation.width}</label> <div class="relative"> <input type="number" id="bust-width" name="bust-width" min="1" max="50" step="0.1" class="dimension-input w-full h-12 px-3 pr-10 border-2 border-gray-300 rounded-lg text-lg font-semibold text-center focus:outline-none focus:border-brand-dark focus:ring-2 focus:ring-brand-dark/20 transition-colors" placeholder="0" aria-describedby="bust-width-unit"> <span id="bust-width-unit" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm pointer-events-none">cm</span> </div> </div> <!-- Height Input --> <div class="dimension-input-group"> <label for="bust-height" class="block text-xs text-gray-500 mb-1">${t.priceEstimation.height}</label> <div class="relative"> <input type="number" id="bust-height" name="bust-height" min="1" max="50" step="0.1" class="dimension-input w-full h-12 px-3 pr-10 border-2 border-gray-300 rounded-lg text-lg font-semibold text-center focus:outline-none focus:border-brand-dark focus:ring-2 focus:ring-brand-dark/20 transition-colors" placeholder="0" aria-describedby="bust-height-unit"> <span id="bust-height-unit" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm pointer-events-none">cm</span> </div> </div> </div> <p class="text-xs text-gray-500 mt-2">${t.priceEstimation.bust.maxDimensions}</p> </div> <!-- Volume Display --> <div class="mb-4 p-3 bg-gray-100 rounded-lg"> <div class="flex justify-between items-center"> <span class="text-sm text-gray-600">${t.priceEstimation.volume}</span> <span id="bust-volume" class="font-medium text-brand-dark">0 cm³</span> </div> </div> <!-- Estimated Price Display --> <div class="mt-8 p-4 bg-brand-dark rounded-lg text-center"> <p class="text-white text-sm mb-1">${t.priceEstimation.estimatedPrice}</p> <p id="bust-price" class="text-3xl font-bold text-white"${addAttribute(t.priceEstimation.selectGrade, "data-select-grade")}${addAttribute(t.priceEstimation.enterDimensions, "data-enter-dimensions")}>${t.priceEstimation.selectGrade}</p> <p class="text-white/70 text-xs mt-2">${t.priceEstimation.priceDisclaimer}</p> </div> <!-- Contact CTA --> <div class="mt-4 text-center"> <a href="#contact" class="inline-block px-8 py-3 bg-bmg-gold text-white font-semibold rounded-lg hover:bg-bmg-gold/90 transition-colors"> ${t.priceEstimation.getCustomQuote} </a> </div> </div> <!-- Relief Calculator Panel --> <div id="relief-panel" role="tabpanel" aria-labelledby="relief-tab" class="mt-6 p-6 bg-gray-50 rounded-lg border border-gray-200 hidden"> <h3 class="text-xl font-semibold text-brand-dark mb-4">${t.priceEstimation.relief.title}</h3> <!-- Stone Grade Selection --> <div class="mb-6"> <label class="block text-sm font-medium text-gray-700 mb-2">${t.priceEstimation.stoneGrade}</label> <div class="grid grid-cols-3 gap-3" role="radiogroup"${addAttribute(t.priceEstimation.stoneGrade, "aria-label")}> <button class="relief-grade-btn px-4 py-3 border-2 border-brand-dark rounded-lg text-brand-dark hover:bg-brand-dark hover:text-white transition-colors" data-grade="A" data-price="0.10" role="radio" aria-checked="false"> <span class="block font-semibold">${t.priceEstimation.grades.a.label}</span> <span class="block text-sm opacity-75">${t.priceEstimation.grades.a.description}</span> </button> <button class="relief-grade-btn px-4 py-3 border-2 border-brand-dark rounded-lg text-brand-dark hover:bg-brand-dark hover:text-white transition-colors" data-grade="AA" data-price="0.15" role="radio" aria-checked="false"> <span class="block font-semibold">${t.priceEstimation.grades.aa.label}</span> <span class="block text-sm opacity-75">${t.priceEstimation.grades.aa.description}</span> </button> <button class="relief-grade-btn px-4 py-3 border-2 border-brand-dark rounded-lg text-brand-dark hover:bg-brand-dark hover:text-white transition-colors" data-grade="AA+" data-price="0.25" role="radio" aria-checked="false"> <span class="block font-semibold">${t.priceEstimation.grades.aaPlus.label}</span> <span class="block text-sm opacity-75">${t.priceEstimation.grades.aaPlus.description}</span> </button> </div> </div> <!-- Dimension Inputs --> <div class="mb-6"> <label class="block text-sm font-medium text-gray-700 mb-2">${t.priceEstimation.dimensions}</label> <div class="grid grid-cols-3 gap-4"> <!-- Length Input --> <div class="dimension-input-group"> <label for="relief-length" class="block text-xs text-gray-500 mb-1">${t.priceEstimation.length}</label> <div class="relative"> <input type="number" id="relief-length" name="relief-length" min="1" max="50" step="0.1" class="dimension-input w-full h-12 px-3 pr-10 border-2 border-gray-300 rounded-lg text-lg font-semibold text-center focus:outline-none focus:border-brand-dark focus:ring-2 focus:ring-brand-dark/20 transition-colors" placeholder="0" aria-describedby="relief-length-unit"> <span id="relief-length-unit" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm pointer-events-none">cm</span> </div> </div> <!-- Width Input --> <div class="dimension-input-group"> <label for="relief-width" class="block text-xs text-gray-500 mb-1">${t.priceEstimation.width}</label> <div class="relative"> <input type="number" id="relief-width" name="relief-width" min="1" max="50" step="0.1" class="dimension-input w-full h-12 px-3 pr-10 border-2 border-gray-300 rounded-lg text-lg font-semibold text-center focus:outline-none focus:border-brand-dark focus:ring-2 focus:ring-brand-dark/20 transition-colors" placeholder="0" aria-describedby="relief-width-unit"> <span id="relief-width-unit" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm pointer-events-none">cm</span> </div> </div> <!-- Height Input --> <div class="dimension-input-group"> <label for="relief-height" class="block text-xs text-gray-500 mb-1">${t.priceEstimation.height}</label> <div class="relative"> <input type="number" id="relief-height" name="relief-height" min="1" max="30" step="0.1" class="dimension-input w-full h-12 px-3 pr-10 border-2 border-gray-300 rounded-lg text-lg font-semibold text-center focus:outline-none focus:border-brand-dark focus:ring-2 focus:ring-brand-dark/20 transition-colors" placeholder="0" aria-describedby="relief-height-unit"> <span id="relief-height-unit" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm pointer-events-none">cm</span> </div> </div> </div> <p class="text-xs text-gray-500 mt-2">${t.priceEstimation.relief.maxDimensions}</p> </div> <!-- Volume Display --> <div class="mb-4 p-3 bg-gray-100 rounded-lg"> <div class="flex justify-between items-center"> <span class="text-sm text-gray-600">${t.priceEstimation.volume}</span> <span id="relief-volume" class="font-medium text-brand-dark">0 cm³</span> </div> </div> <!-- Estimated Price Display --> <div class="mt-8 p-4 bg-brand-dark rounded-lg text-center"> <p class="text-white text-sm mb-1">${t.priceEstimation.estimatedPrice}</p> <p id="relief-price" class="text-3xl font-bold text-white"${addAttribute(t.priceEstimation.selectGrade, "data-select-grade")}${addAttribute(t.priceEstimation.enterDimensions, "data-enter-dimensions")}>${t.priceEstimation.selectGrade}</p> <p class="text-white/70 text-xs mt-2">${t.priceEstimation.priceDisclaimer}</p> </div> <!-- Contact CTA --> <div class="mt-4 text-center"> <a href="#contact" class="inline-block px-8 py-3 bg-bmg-gold text-white font-semibold rounded-lg hover:bg-bmg-gold/90 transition-colors"> ${t.priceEstimation.getCustomQuote} </a> </div> </div> </div> </div> </section> ${renderScript($$result, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/PriceEstimation.astro?astro&type=script&index=0&lang.ts")}`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/PriceEstimation.astro", void 0);

const $$Astro$5 = createAstro("https://bmg-granite.com");
const $$StatItem = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$StatItem;
  const { value, label } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div class="text-center"> <div class="text-2xl font-medium text-black leading-[150%] mb-2">${value}</div> <div class="text-2xl font-normal text-center leading-[150%] text-text-muted">${label}</div> </div>`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/ui/StatItem.astro", void 0);

const regions = [{"id":"north-america","name":"North America","cx":250,"cy":200,"r":70,"project":{"name":"Empire State Plaza","description":"Premium marble and granite installation for iconic landmark renovation in New York.","image":"https://picsum.photos/128/128?random=1"}},{"id":"mexico","name":"Mexico","cx":195,"cy":310,"r":35,"project":{"name":"Cancun Resort Collection","description":"Natural stone facades for beachfront luxury hospitality venues.","image":"https://picsum.photos/128/128?random=2"}},{"id":"south-america","name":"South America","cx":335,"cy":450,"r":60,"project":{"name":"Sao Paulo Tower","description":"Contemporary granite application for South America's tallest residential building.","image":"https://picsum.photos/128/128?random=3"}},{"id":"uk-ireland","name":"United Kingdom","cx":575,"cy":170,"r":30,"project":{"name":"London Heritage Collection","description":"Restoration-grade limestone for historic preservation projects.","image":"https://picsum.photos/128/128?random=4"}},{"id":"western-europe","name":"Western Europe","cx":600,"cy":230,"r":40,"project":{"name":"Paris Luxury Residences","description":"Elegant marble finishes for high-end European apartments.","image":"https://picsum.photos/128/128?random=5"}},{"id":"central-europe","name":"Central Europe","cx":670,"cy":175,"r":40,"project":{"name":"Berlin Modern Complex","description":"Precision-cut stone for contemporary European architecture.","image":"https://picsum.photos/128/128?random=6"}},{"id":"middle-east","name":"Middle East","cx":765,"cy":320,"r":50,"project":{"name":"Dubai Luxury Towers","description":"Opulent marble and onyx installations for ultra-premium developments.","image":"https://picsum.photos/128/128?random=7"}},{"id":"africa","name":"Africa","cx":660,"cy":420,"r":70,"project":{"name":"Cape Town Luxury Villas","description":"Natural stone installations for exclusive coastal residences.","image":"https://picsum.photos/128/128?random=8"}},{"id":"india","name":"India","cx":870,"cy":330,"r":50,"project":{"name":"Mumbai Sky Gardens","description":"Innovative stone landscaping for vertical garden developments.","image":"https://picsum.photos/128/128?random=9"}},{"id":"east-asia","name":"East Asia","cx":1020,"cy":250,"r":70,"project":{"name":"Tokyo Zen Collection","description":"Minimalist stone designs blending tradition with modernity.","image":"https://picsum.photos/128/128?random=10"}},{"id":"southeast-asia","name":"Southeast Asia","cx":970,"cy":400,"r":40,"project":{"name":"Marina Bay Collection","description":"Sophisticated stone finishes for Singapore's iconic skyline.","image":"https://picsum.photos/128/128?random=11"}},{"id":"oceania","name":"Oceania","cx":1100,"cy":500,"r":70,"project":{"name":"Sydney Harbor Residences","description":"Coastal-inspired stone designs for waterfront living.","image":"https://picsum.photos/128/128?random=12"}}];
const regionsData = {
  regions,
};

const $$InteractiveMap = createComponent(($$result, $$props, $$slots) => {
  const regions = regionsData.regions;
  return renderTemplate`${maybeRenderHead()}<div class="interactive-map-wrapper" data-astro-cid-oreptmz5> <div class="interactive-map-container relative" data-astro-cid-oreptmz5> <!-- Map SVG Container --> <div id="map-svg-container" class="rounded-2xl overflow-hidden relative" data-astro-cid-oreptmz5> <!-- Static map image --> <img id="map-image" src="/images/Landing/Map.svg" alt="World map showing global reach" class="w-full h-auto block" data-astro-cid-oreptmz5> </div> <!-- Project Tooltip --> <div id="map-tooltip" class="absolute pointer-events-none bg-white p-3 rounded-xl shadow-xl opacity-0 transition-all duration-200 z-50 border border-gray-100 max-w-[300px]" style="transform: translate(-50%, -100%); margin-top: -16px;" data-astro-cid-oreptmz5> <div class="flex items-start gap-3" data-astro-cid-oreptmz5> <img id="tooltip-image" class="w-16 h-16 rounded-lg object-cover flex-shrink-0 bg-gray-100" alt="" data-astro-cid-oreptmz5> <div class="min-w-0 flex-1" data-astro-cid-oreptmz5> <div class="flex items-center gap-2 mb-1" data-astro-cid-oreptmz5> <span id="tooltip-region" class="text-xs text-gray-400 truncate" data-astro-cid-oreptmz5></span> </div> <h4 id="tooltip-project-name" class="font-semibold text-sm text-brand-primary leading-tight mb-1" data-astro-cid-oreptmz5></h4> <p id="tooltip-description" class="text-xs text-gray-500 line-clamp-2" data-astro-cid-oreptmz5></p> </div> </div> </div> <!-- Region overlay - circle zones for hover detection with visible indicators --> <svg id="region-overlay" class="absolute top-0 left-0 w-full h-full pointer-events-none" viewBox="0 0 1311 672" preserveAspectRatio="xMidYMid meet" data-astro-cid-oreptmz5> ${regions.map((region) => renderTemplate`<g class="region-group" data-astro-cid-oreptmz5> <!-- Visible indicator dot --> <circle class="region-dot"${addAttribute(region.cx, "cx")}${addAttribute(region.cy, "cy")} r="8" fill="#392DCA" data-astro-cid-oreptmz5></circle> <!-- Invisible hover zone --> <circle class="region-zone pointer-events-auto cursor-pointer"${addAttribute(region.id, "data-region-id")}${addAttribute(region.name, "data-region-name")}${addAttribute(region.project.name, "data-project-name")}${addAttribute(region.project.description, "data-project-description")}${addAttribute(region.project.image, "data-project-image")}${addAttribute(region.cx, "cx")}${addAttribute(region.cy, "cy")}${addAttribute(region.r, "r")} fill="transparent" data-astro-cid-oreptmz5></circle> </g>`)} </svg> </div> </div>  ${renderScript($$result, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/ui/InteractiveMap.astro?astro&type=script&index=0&lang.ts")}`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/ui/InteractiveMap.astro", void 0);

const $$Astro$4 = createAstro("https://bmg-granite.com");
const $$TrustedCultures = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$TrustedCultures;
  const { t } = useI18n(Astro2.url);
  const stats = [
    { value: "24", label: t.trustedCultures.stats.countriesDelivered },
    { value: "24", label: t.trustedCultures.stats.projectsCompleted },
    { value: "30+", label: t.trustedCultures.stats.yearsExperience }
  ];
  return renderTemplate`${maybeRenderHead()}<section id="delivery" class="py-16 lg:py-24 bg-bmg-light"> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"> <!-- Section Header --> <h2 class="text-3xl lg:text-4xl font-bold text-center mb-12 lg:mb-16 text-brand-primary"> ${t.trustedCultures.title} </h2> <!-- Interactive World Map --> <div class="relative max-w-5xl mx-auto mb-12 lg:mb-16"> ${renderComponent($$result, "InteractiveMap", $$InteractiveMap, {})} </div> <!-- Statistics --> <div class="grid grid-cols-3 gap-8 max-w-3xl mx-auto"> ${stats.map((stat) => renderTemplate`${renderComponent($$result, "StatItem", $$StatItem, { "value": stat.value, "label": stat.label })}`)} </div> </div> </section>`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/TrustedCultures.astro", void 0);

const $$Astro$3 = createAstro("https://bmg-granite.com");
const $$TestimonialCard = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$TestimonialCard;
  const { name, role, quote, rating = 5 } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div class="testimonial-card bg-white p-6 lg:p-8" data-astro-cid-ysasvp6c> <!-- Star Rating --> <div class="flex gap-0.5 mb-4" style="width: 101.002px; height: 17.216px;" data-astro-cid-ysasvp6c> ${Array.from({ length: 5 }).map((_, i) => renderTemplate`<img src="/images/Landing/star.png" alt="Star"${addAttribute(`h-full ${i < rating ? "" : "opacity-30"}`, "class")} style="height: 17.216px; width: auto;" data-astro-cid-ysasvp6c>`)} </div> <!-- Quote --> <p class="testimonial-quote mb-6" data-astro-cid-ysasvp6c> ${quote} </p> <!-- Author --> <div data-astro-cid-ysasvp6c> <p class="testimonial-name" data-astro-cid-ysasvp6c>${name}</p> <p class="testimonial-role" data-astro-cid-ysasvp6c>${role}</p> </div> </div> `;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/ui/TestimonialCard.astro", void 0);

const $$Astro$2 = createAstro("https://bmg-granite.com");
const $$Testimonials = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$Testimonials;
  const { t } = useI18n(Astro2.url);
  const testimonials = [
    {
      name: "Sabo Masties",
      role: "Founder @ Rolex",
      quote: "Yet preference connection unpleasant yet melancholy but end appearance. And excellence partiality estimating terminated day everything.",
      rating: 5
    },
    {
      name: "Sam",
      role: "Founder @ Migelko",
      quote: "Yet preference connection unpleasant yet melancholy but end appearance. And excellence partiality estimating terminated day everything.",
      rating: 5
    },
    {
      name: "Mansur",
      role: "Founder @ Google",
      quote: "Yet preference connection unpleasant yet melancholy but end appearance. And excellence partiality estimating terminated day everything.",
      rating: 5
    },
    {
      name: "Sarah Chen",
      role: "CEO @ TechVentures",
      quote: "Yet preference connection unpleasant yet melancholy but end appearance. And excellence partiality estimating terminated day everything.",
      rating: 5
    },
    {
      name: "Michael Brown",
      role: "Director @ Artisan Co",
      quote: "Yet preference connection unpleasant yet melancholy but end appearance. And excellence partiality estimating terminated day everything.",
      rating: 5
    },
    {
      name: "Emma Wilson",
      role: "Partner @ Design Studio",
      quote: "Yet preference connection unpleasant yet melancholy but end appearance. And excellence partiality estimating terminated day everything.",
      rating: 5
    }
  ];
  return renderTemplate`${maybeRenderHead()}<section id="about" class="py-16 lg:py-24 bg-white" data-astro-cid-dnksfipb> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" data-astro-cid-dnksfipb> <!-- Section Header --> <div class="text-center mb-12 lg:mb-16 max-w-2xl mx-auto" data-astro-cid-dnksfipb> <h2 class="text-3xl lg:text-4xl font-bold mb-4 uppercase text-brand-primary" style="font-family: 'Poppins', sans-serif;" data-astro-cid-dnksfipb> ${t.testimonials.title} </h2> <p class="text-gray-600" style="font-family: 'Poppins', sans-serif;" data-astro-cid-dnksfipb> ${t.testimonials.description} </p> </div> <!-- Testimonials Carousel Container --> <div class="relative" data-astro-cid-dnksfipb> <!-- Blue Background Block --> <div class="blue-background-block absolute left-8 right-8 lg:left-12 lg:right-12 bg-brand-primary" data-astro-cid-dnksfipb></div> <!-- Carousel Wrapper --> <div class="relative carousel-wrapper" data-astro-cid-dnksfipb> <!-- Testimonials Carousel --> <div class="testimonials-carousel overflow-hidden px-2 lg:px-0" data-astro-cid-dnksfipb> <div class="testimonials-track flex items-center transition-transform duration-500 ease-in-out" id="testimonials-track" data-astro-cid-dnksfipb> ${testimonials.map((testimonial, index) => renderTemplate`<div class="testimonial-slide flex-shrink-0 w-full md:w-1/2 lg:w-1/3 px-3" data-astro-cid-dnksfipb> ${renderComponent($$result, "TestimonialCard", $$TestimonialCard, { "name": testimonial.name, "role": testimonial.role, "quote": testimonial.quote, "rating": testimonial.rating, "data-astro-cid-dnksfipb": true })} </div>`)} </div> </div> <!-- Navigation Arrows --> <div class="flex justify-center mt-8 pb-12 relative z-10" data-astro-cid-dnksfipb> <div class="nav-controls inline-flex bg-white rounded-xl overflow-hidden shadow-lg p-1" data-astro-cid-dnksfipb> <!-- Left Arrow Button --> <button id="prev-btn" class="nav-arrow-btn left-arrow w-12 h-12 flex items-center justify-center transition-all duration-300"${addAttribute(t.testimonials.prevButton, "aria-label")} disabled data-astro-cid-dnksfipb> <img src="/images/Landing/arrow.svg" alt="Previous" class="nav-arrow-img w-5 h-auto rotate-180" id="prev-arrow-img" data-astro-cid-dnksfipb> </button> <!-- Right Arrow Button --> <button id="next-btn" class="nav-arrow-btn right-arrow w-12 h-12 flex items-center justify-center rounded-lg transition-all duration-300 bg-accent-red"${addAttribute(t.testimonials.nextButton, "aria-label")} data-astro-cid-dnksfipb> <img src="/images/Landing/arrow.svg" alt="Next" class="nav-arrow-img w-5 h-auto" id="next-arrow-img" data-astro-cid-dnksfipb> </button> </div> </div> </div> </div> </div> </section>  ${renderScript($$result, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/Testimonials.astro?astro&type=script&index=0&lang.ts")}`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/Testimonials.astro", void 0);

const $$Astro$1 = createAstro("https://bmg-granite.com");
const $$FormField = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$FormField;
  const {
    type,
    label,
    name,
    placeholder = "",
    required = false,
    rows = 4,
    maxLength,
    pattern,
    validationType,
    options = [],
    selectPlaceholder = "Please Select...",
    class: className = ""
  } = Astro2.props;
  const getValidationType = () => {
    if (validationType) return validationType;
    if (type === "email") return "email";
    if (type === "tel" || type === "phone") return "phone";
    if (type === "url") return "url";
    if (type === "select") return "select";
    return "text";
  };
  const isPhoneWithCountry = type === "phone";
  const isSelect = type === "select";
  const isTextarea = type === "textarea";
  const countryCodes = [
    { code: "+66", country: "Thailand" },
    { code: "+1", country: "USA/Canada" },
    { code: "+44", country: "UK" },
    { code: "+86", country: "China" },
    { code: "+91", country: "India" },
    { code: "+81", country: "Japan" },
    { code: "+82", country: "South Korea" },
    { code: "+65", country: "Singapore" },
    { code: "+971", country: "UAE" },
    { code: "+966", country: "Saudi Arabia" },
    { code: "+61", country: "Australia" },
    { code: "+49", country: "Germany" },
    { code: "+33", country: "France" }
  ];
  const normalizedOptions = options.map(
    (opt) => typeof opt === "string" ? { value: opt, label: opt } : opt
  );
  const baseInputClasses = "w-full px-3 rounded-md border border-border bg-white focus:ring-2 focus:ring-bmg-primary focus:border-transparent outline-none transition-all duration-200 text-gray-900 placeholder-gray-500";
  const inputClasses = `${baseInputClasses} h-[50px] flex flex-col justify-center items-start gap-3`;
  const textareaClasses = `${baseInputClasses} py-3 flex flex-col justify-start items-start gap-3`;
  const selectClasses = `${inputClasses} appearance-none cursor-pointer bg-[url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e")] bg-[length:1.5em_1.5em] bg-[right_0.5rem_center] bg-no-repeat pr-10`;
  const phoneSelectClasses = `h-[50px] px-3 border-r border-border bg-white focus:ring-2 focus:ring-bmg-primary focus:outline-none transition-all duration-200 text-gray-900 appearance-none cursor-pointer bg-[url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e")] bg-[length:1em_1em] bg-[right_0.25rem_center] bg-no-repeat pr-6`;
  const phoneInputClasses = "flex-1 h-[50px] px-3 bg-white focus:ring-2 focus:ring-bmg-primary focus:outline-none transition-all duration-200 text-gray-900 placeholder-gray-500";
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(["form-field space-y-2", className], "class:list")} data-form-field${addAttribute(name, "data-field-name")}${addAttribute(getValidationType(), "data-validation-type")}${addAttribute(required.toString(), "data-required")} data-astro-cid-p46g2kvx> <label${addAttribute(name, "for")} class="block text-sm font-medium text-gray-900" data-astro-cid-p46g2kvx> ${label} ${required && renderTemplate`<span class="text-red-500" data-astro-cid-p46g2kvx>*</span>`} </label> ${isPhoneWithCountry ? renderTemplate`<!-- Phone input with country code selector -->
    <div class="flex rounded-md border border-border bg-white overflow-hidden" data-phone-wrapper data-astro-cid-p46g2kvx> <select${addAttribute(`${name}-country`, "id")}${addAttribute(`${name}-country`, "name")}${addAttribute(phoneSelectClasses, "class")} aria-label="Country code" data-country-select data-astro-cid-p46g2kvx> ${countryCodes.map(({ code, country }) => renderTemplate`<option${addAttribute(code, "value")}${addAttribute(country, "title")} data-astro-cid-p46g2kvx>${code}</option>`)} </select> <input type="tel"${addAttribute(name, "id")}${addAttribute(name, "name")}${addAttribute(placeholder || label, "placeholder")}${addAttribute(required, "required")}${addAttribute(phoneInputClasses, "class")} inputmode="tel" autocomplete="tel" data-input data-astro-cid-p46g2kvx> </div>` : isSelect ? renderTemplate`<!-- Select dropdown -->
    <select${addAttribute(name, "id")}${addAttribute(name, "name")}${addAttribute(required, "required")}${addAttribute(selectClasses, "class")} data-input data-astro-cid-p46g2kvx> <option value="" disabled selected data-astro-cid-p46g2kvx>${selectPlaceholder}</option> ${normalizedOptions.map((opt) => renderTemplate`<option${addAttribute(opt.value, "value")} data-astro-cid-p46g2kvx>${opt.label}</option>`)} </select>` : isTextarea ? renderTemplate`<!-- Textarea -->
    <textarea${addAttribute(name, "id")}${addAttribute(name, "name")}${addAttribute(rows, "rows")}${addAttribute(placeholder || label, "placeholder")}${addAttribute(required, "required")}${addAttribute(maxLength, "maxlength")}${addAttribute(textareaClasses, "class")} data-input data-astro-cid-p46g2kvx></textarea>` : renderTemplate`<!-- Standard input (text, email, tel, url) -->
    <input${addAttribute(type === "phone" ? "tel" : type, "type")}${addAttribute(name, "id")}${addAttribute(name, "name")}${addAttribute(placeholder || label, "placeholder")}${addAttribute(required, "required")}${addAttribute(maxLength, "maxlength")}${addAttribute(pattern, "pattern")}${addAttribute(inputClasses, "class")} data-input data-astro-cid-p46g2kvx>`} <p class="form-field__error text-xs text-red-500 mt-1 hidden" data-error-message aria-live="polite" data-astro-cid-p46g2kvx></p> </div> `;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/ui/FormField.astro", void 0);

function parseCommaSeparated(value, defaultValue = []) {
  return defaultValue;
}
function parseSocials(value, defaultSocials2) {
  return defaultSocials2;
}
const defaultAddress = [
  "9/11 Moo 10 Borommaratchachonnani rd",
  "Sala Thammasop Thawi Watthana",
  "Bangkok 10170"
];
const defaultPhones = ["+66 2 888 7788", "+66 87 879 6226", "+66 81 445 9999"];
const defaultEmail = "bmgthai@bmg.co.th";
const defaultSocials = [
  {
    name: "Facebook",
    handle: "BMG บางกอกโมเดิร์นแกรนิต",
    url: "https://www.facebook.com/bmgthailand",
    icon: "facebook"
  },
  {
    name: "Line",
    handle: "@bmgstone",
    url: "https://page.line.me/bmgstone?openQrModal=true",
    icon: "line"
  },
  {
    name: "Instagram",
    handle: "bangkokmoderngranite",
    url: "https://www.instagram.com/bangkokmoderngranite",
    icon: "instagram"
  },
  {
    name: "YouTube",
    handle: "bmgthai granite",
    url: "https://www.youtube.com/channel/UC9FCyP3XZHRkvK9vnnh8IMg",
    icon: "youtube"
  }
];
function getContactConfig() {
  return {
    address: parseCommaSeparated(
      undefined                               ,
      defaultAddress
    ),
    phone: parseCommaSeparated(
      undefined                              ,
      defaultPhones
    ),
    email: defaultEmail,
    socials: parseSocials(
      undefined                               ,
      defaultSocials
    )
  };
}
const contactConfig = getContactConfig();

const positions = ["salesManager","projectManager","designer","architect","developer","other"];
const projectTypes = ["residential","commercial","industrial","hospitality","publicSpace","other"];
const budgetRanges = ["under10k","10kTo50k","50kTo100k","100kTo500k","over500k"];
const considerations = ["quality","price","timeline","design","allOfTheAbove"];
const timelines = ["immediate","within1Month","1To3Months","3To6Months","6PlusMonths"];
const formOptionsConfig = {
  positions,
  projectTypes,
  budgetRanges,
  considerations,
  timelines,
};

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(raw || cooked.slice()) }));
var _a;
const $$Astro = createAstro("https://bmg-granite.com");
const $$Contact = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Contact;
  const { t } = useI18n(Astro2.url);
  const contactInfo = contactConfig;
  const positions = formOptionsConfig.positions.map(
    (key) => t.contact.positions[key]
  );
  const projectTypes = formOptionsConfig.projectTypes.map(
    (key) => t.contact.projectTypes[key]
  );
  const budgetRanges = formOptionsConfig.budgetRanges.map(
    (key) => t.contact.budgetRanges[key]
  );
  const considerations = formOptionsConfig.considerations.map(
    (key) => t.contact.considerations[key]
  );
  const timelines = formOptionsConfig.timelines.map(
    (key) => t.contact.timelines[key]
  );
  const validationTranslations = JSON.stringify({
    required: t.validation?.required || "This field is required",
    invalidEmail: t.validation?.invalidEmail || "Please enter a valid email address",
    invalidPhone: t.validation?.invalidPhone || "Please enter a valid phone number (7-15 digits)",
    invalidUrl: t.validation?.invalidUrl || "Please enter a valid URL (including http:// or https://)",
    invalidName: t.validation?.invalidName || "Please enter a valid name (letters only)",
    tooShort: t.validation?.tooShort || "This field is too short",
    tooLong: t.validation?.tooLong || "This field is too long",
    invalidFormat: t.validation?.invalidFormat || "Invalid format",
    formSuccess: t.validation?.formSuccess || "Thank you! Your message has been sent successfully.",
    formError: t.validation?.formError || "There was an error submitting your form. Please try again.",
    submitting: t.validation?.submitting || "Submitting..."
  });
  return renderTemplate(_a || (_a = __template(["", '<section id="contact" class="py-16 lg:py-24 bg-white"> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"> <div class="grid lg:grid-cols-2 gap-12 lg:gap-16 items-start"> <!-- Contact Form --> <div class="bg-white rounded-2xl p-6 lg:p-8 shadow-[0_4px_24px_rgba(0,0,0,0.08)]"> <form class="space-y-6" id="contact-form" novalidate> <div class="grid sm:grid-cols-2 gap-6"> ', " ", ' </div> <div class="grid sm:grid-cols-2 gap-6"> ', " ", ' </div> <div class="grid sm:grid-cols-2 gap-6"> ', " ", ' </div> <div class="grid sm:grid-cols-2 gap-6"> ', " ", ' </div> <div class="grid sm:grid-cols-2 gap-6"> ', " ", " </div> ", ' <!-- Checkbox --> <label class="flex items-start gap-3 cursor-pointer"> <input type="checkbox" name="consent" class="mt-1 w-4 h-4 rounded border-gray-300 text-bmg-primary focus:ring-bmg-primary"> <span class="text-sm text-gray-600"> ', " </span> </label> ", ' </form> </div> <!-- Contact Information --> <div> <h2 class="text-3xl lg:text-4xl font-bold mb-4 text-brand-primary"> ', ' </h2> <p class="text-gray-600 mb-8"> ', ' </p> <div class="space-y-6"> <!-- Address --> <div class="flex gap-4"> <div class="flex-shrink-0 w-6 h-6"> <img src="/images/Landing/property-location.svg" alt="Location" class="w-full h-full"> </div> <div class="text-gray-600"> ', ' </div> </div> <!-- Phone --> <div class="flex gap-4"> <div class="flex-shrink-0 w-6 h-6"> <img src="/images/Landing/mobile-chat.svg" alt="Phone" class="w-full h-full"> </div> <div class="text-gray-600"> ', ' </div> </div> <!-- Email --> <div class="flex gap-4"> <div class="flex-shrink-0 w-6 h-6"> <img src="/images/Landing/email.svg" alt="Email" class="w-full h-full"> </div> <a', ' class="text-gray-600 hover:text-bmg-primary transition-colors"> ', ' </a> </div> <!-- Social Links --> <div class="pt-4 space-y-4"> ', " </div> </div> </div> </div> </div> </section> <script>(function(){", `
  // Parse translations from server
  const translations = JSON.parse(validationTranslations);

  // ============================================
  // CSRF TOKEN GENERATION
  // ============================================

  const CSRF_TOKEN_KEY = 'bmg_csrf_token';
  const TOKEN_EXPIRY_MS = 30 * 60 * 1000; // 30 minutes

  function generateSecureToken(length = 32) {
    const array = new Uint8Array(length);
    crypto.getRandomValues(array);
    return Array.from(array, (byte) => byte.toString(16).padStart(2, '0')).join('');
  }

  function generateCSRFToken() {
    try {
      const stored = sessionStorage.getItem(CSRF_TOKEN_KEY);
      if (stored) {
        const tokenData = JSON.parse(stored);
        if (tokenData.expiresAt > Date.now()) {
          return tokenData.token;
        }
      }
    } catch (e) {
      // Ignore parsing errors
    }

    // Generate new token
    const token = generateSecureToken();
    const tokenData = {
      token,
      timestamp: Date.now(),
      expiresAt: Date.now() + TOKEN_EXPIRY_MS,
    };

    try {
      sessionStorage.setItem(CSRF_TOKEN_KEY, JSON.stringify(tokenData));
    } catch (e) {
      // Ignore storage errors
    }

    return token;
  }

  // ============================================
  // VALIDATION PATTERNS
  // ============================================

  const VALIDATION_PATTERNS = {
    email: /^[a-zA-Z0-9](?:[a-zA-Z0-9._%+-]*[a-zA-Z0-9])?@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\\.[a-zA-Z]{2,})+$/,
    phone: /^[\\d\\s\\-()]+$/,
    name: /^[\\p{L}\\p{M}][\\p{L}\\p{M}\\s\\-']*[\\p{L}\\p{M}]$|^[\\p{L}\\p{M}]$/u,
  };

  // ============================================
  // SANITIZATION FUNCTIONS
  // ============================================

  const HTML_ENTITIES = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#x27;',
    '/': '&#x2F;',
    '\`': '&#x60;',
    '=': '&#x3D;',
  };

  function sanitizeHTML(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/[&<>"'\`=/]/g, (char) => HTML_ENTITIES[char] || char);
  }

  function stripHTMLTags(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/<[^>]*>/g, '');
  }

  function sanitizeForDisplay(input) {
    if (typeof input !== 'string') return '';
    return sanitizeHTML(stripHTMLTags(input));
  }

  function sanitizePhone(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/[^\\d+\\-() ]/g, '').trim();
  }

  function sanitizeEmail(input) {
    if (typeof input !== 'string') return '';
    return input.toLowerCase().trim();
  }

  function sanitizeName(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/[^\\p{L}\\p{M}\\s\\-']/gu, '').trim();
  }

  // ============================================
  // VALIDATION FUNCTIONS
  // ============================================

  function validateRequired(value) {
    const trimmed = value?.trim() || '';
    return {
      isValid: trimmed.length > 0,
      error: trimmed.length > 0 ? undefined : translations.required,
    };
  }

  function validateEmail(value) {
    if (!value || value.trim() === '') return { isValid: true };
    const sanitized = sanitizeEmail(value);
    const isValid = VALIDATION_PATTERNS.email.test(sanitized);
    return {
      isValid,
      error: isValid ? undefined : translations.invalidEmail,
    };
  }

  function validatePhone(value) {
    if (!value || value.trim() === '') return { isValid: true };
    const sanitized = sanitizePhone(value);
    if (!VALIDATION_PATTERNS.phone.test(sanitized)) {
      return { isValid: false, error: translations.invalidPhone };
    }
    const digitsOnly = sanitized.replace(/\\D/g, '');
    const isValidLength = digitsOnly.length >= 7 && digitsOnly.length <= 15;
    return {
      isValid: isValidLength,
      error: isValidLength ? undefined : translations.invalidPhone,
    };
  }

  function validateName(value) {
    if (!value || value.trim() === '') return { isValid: true };
    const sanitized = sanitizeName(value);
    const isValid = VALIDATION_PATTERNS.name.test(sanitized) && sanitized.length >= 1;
    return {
      isValid,
      error: isValid ? undefined : translations.invalidName,
    };
  }

  function validateMaxLength(value, maxLength) {
    const length = value?.length || 0;
    const isValid = length <= maxLength;
    return {
      isValid,
      error: isValid ? undefined : translations.tooLong,
    };
  }

  // ============================================
  // FORM VALIDATION
  // ============================================

  function validateField(fieldElement) {
    const fieldName = fieldElement.dataset.fieldName || '';
    const validationType = fieldElement.dataset.validationType || 'text';
    const isRequired = fieldElement.dataset.required === 'true';
    const input = fieldElement.querySelector('[data-input]');
    const errorMessage = fieldElement.querySelector('[data-error-message]');

    if (!input) return { isValid: true };

    const value = input.value;
    let result = { isValid: true };

    // Check required first
    if (isRequired) {
      result = validateRequired(value);
      if (!result.isValid) {
        showError(fieldElement, errorMessage, result.error || '');
        return result;
      }
    }

    // If empty and not required, it's valid
    if (!value || value.trim() === '') {
      clearError(fieldElement, errorMessage);
      return { isValid: true };
    }

    // Type-specific validation
    switch (validationType) {
      case 'email':
        result = validateEmail(value);
        break;
      case 'phone':
        result = validatePhone(value);
        break;
      case 'name':
        result = validateName(value);
        break;
      case 'text':
        result = validateMaxLength(value, 2000);
        break;
      case 'select':
        result = { isValid: true };
        break;
    }

    if (result.isValid) {
      showValid(fieldElement, errorMessage);
    } else {
      showError(fieldElement, errorMessage, result.error || '');
    }

    return result;
  }

  function showError(fieldElement, errorMessage, message) {
    fieldElement.classList.remove('is-valid');
    fieldElement.classList.add('has-error');
    if (errorMessage) {
      errorMessage.textContent = message;
    }
  }

  function showValid(fieldElement, errorMessage) {
    fieldElement.classList.remove('has-error');
    fieldElement.classList.add('is-valid');
    if (errorMessage) {
      errorMessage.textContent = '';
    }
  }

  function clearError(fieldElement, errorMessage) {
    fieldElement.classList.remove('has-error', 'is-valid');
    if (errorMessage) {
      errorMessage.textContent = '';
    }
  }

  function validateAllFields(form) {
    const fields = form.querySelectorAll('[data-form-field]');
    let allValid = true;

    fields.forEach((field) => {
      const result = validateField(field);
      if (!result.isValid) {
        allValid = false;
      }
    });

    return allValid;
  }

  function getFormData(form) {
    const formData = new FormData(form);
    const data = {};

    formData.forEach((value, key) => {
      if (typeof value === 'string') {
        switch (key) {
          case 'email':
            data[key] = sanitizeEmail(value);
            break;
          case 'phone':
          case 'whatsapp':
          case 'phone-country':
            data[key] = sanitizePhone(value);
            break;
          case 'firstName':
          case 'surname':
            data[key] = sanitizeName(value);
            break;
          default:
            data[key] = sanitizeForDisplay(value);
        }
      }
    });

    return data;
  }

  function showFormMessage(form, message, type) {
    let messageEl = form.querySelector('[data-form-message]');

    if (!messageEl) {
      messageEl = document.createElement('div');
      messageEl.setAttribute('data-form-message', '');
      messageEl.setAttribute('role', 'alert');
      messageEl.className = 'mt-4 p-4 rounded-md text-sm';
      form.appendChild(messageEl);
    }

    messageEl.textContent = message;
    messageEl.classList.remove('bg-green-50', 'text-green-800', 'bg-red-50', 'text-red-800', 'hidden');

    if (type === 'success') {
      messageEl.classList.add('bg-green-50', 'text-green-800');
    } else {
      messageEl.classList.add('bg-red-50', 'text-red-800');
    }
  }

  // ============================================
  // FORM INITIALIZATION
  // ============================================

  document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('contact-form');
    if (!form) return;

    let isSubmitting = false;

    // Attach blur event listeners for real-time validation
    const fields = form.querySelectorAll('[data-form-field]');
    fields.forEach((field) => {
      const input = field.querySelector('[data-input]');
      if (input) {
        input.addEventListener('blur', () => validateField(field));
        input.addEventListener('input', () => {
          if (field.classList.contains('has-error')) {
            validateField(field);
          }
        });
      }
    });

    // Handle form submission
    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      if (isSubmitting) return;

      // Validate all fields
      const isValid = validateAllFields(form);

      if (!isValid) {
        const firstError = form.querySelector('.has-error [data-input]');
        if (firstError) {
          firstError.focus();
        }
        return;
      }

      // Get sanitized form data
      const data = getFormData(form);

      // Show loading state
      isSubmitting = true;
      const submitButton = form.querySelector('button[type="submit"]');
      const originalButtonText = submitButton?.textContent || '';

      if (submitButton) {
        submitButton.disabled = true;
        submitButton.textContent = translations.submitting;
      }

      try {
        // Generate CSRF token
        const csrfToken = generateCSRFToken();

        const response = await fetch('/api/contact', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': csrfToken,
          },
          body: JSON.stringify(data),
        });

        if (response.ok) {
          showFormMessage(form, translations.formSuccess, 'success');
          form.reset();
          // Clear all validation states
          fields.forEach((field) => {
            const errorMessage = field.querySelector('[data-error-message]');
            clearError(field, errorMessage);
          });
        } else {
          const errorData = await response.json().catch(() => ({}));
          showFormMessage(form, errorData.message || translations.formError, 'error');
        }
      } catch (error) {
        console.error('Network error:', error);
        showFormMessage(form, translations.formError, 'error');
      } finally {
        isSubmitting = false;
        if (submitButton) {
          submitButton.disabled = false;
          submitButton.textContent = originalButtonText;
        }
      }
    });
  });
})();<\/script>`], ["", '<section id="contact" class="py-16 lg:py-24 bg-white"> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"> <div class="grid lg:grid-cols-2 gap-12 lg:gap-16 items-start"> <!-- Contact Form --> <div class="bg-white rounded-2xl p-6 lg:p-8 shadow-[0_4px_24px_rgba(0,0,0,0.08)]"> <form class="space-y-6" id="contact-form" novalidate> <div class="grid sm:grid-cols-2 gap-6"> ', " ", ' </div> <div class="grid sm:grid-cols-2 gap-6"> ', " ", ' </div> <div class="grid sm:grid-cols-2 gap-6"> ', " ", ' </div> <div class="grid sm:grid-cols-2 gap-6"> ', " ", ' </div> <div class="grid sm:grid-cols-2 gap-6"> ', " ", " </div> ", ' <!-- Checkbox --> <label class="flex items-start gap-3 cursor-pointer"> <input type="checkbox" name="consent" class="mt-1 w-4 h-4 rounded border-gray-300 text-bmg-primary focus:ring-bmg-primary"> <span class="text-sm text-gray-600"> ', " </span> </label> ", ' </form> </div> <!-- Contact Information --> <div> <h2 class="text-3xl lg:text-4xl font-bold mb-4 text-brand-primary"> ', ' </h2> <p class="text-gray-600 mb-8"> ', ' </p> <div class="space-y-6"> <!-- Address --> <div class="flex gap-4"> <div class="flex-shrink-0 w-6 h-6"> <img src="/images/Landing/property-location.svg" alt="Location" class="w-full h-full"> </div> <div class="text-gray-600"> ', ' </div> </div> <!-- Phone --> <div class="flex gap-4"> <div class="flex-shrink-0 w-6 h-6"> <img src="/images/Landing/mobile-chat.svg" alt="Phone" class="w-full h-full"> </div> <div class="text-gray-600"> ', ' </div> </div> <!-- Email --> <div class="flex gap-4"> <div class="flex-shrink-0 w-6 h-6"> <img src="/images/Landing/email.svg" alt="Email" class="w-full h-full"> </div> <a', ' class="text-gray-600 hover:text-bmg-primary transition-colors"> ', ' </a> </div> <!-- Social Links --> <div class="pt-4 space-y-4"> ', " </div> </div> </div> </div> </div> </section> <script>(function(){", `
  // Parse translations from server
  const translations = JSON.parse(validationTranslations);

  // ============================================
  // CSRF TOKEN GENERATION
  // ============================================

  const CSRF_TOKEN_KEY = 'bmg_csrf_token';
  const TOKEN_EXPIRY_MS = 30 * 60 * 1000; // 30 minutes

  function generateSecureToken(length = 32) {
    const array = new Uint8Array(length);
    crypto.getRandomValues(array);
    return Array.from(array, (byte) => byte.toString(16).padStart(2, '0')).join('');
  }

  function generateCSRFToken() {
    try {
      const stored = sessionStorage.getItem(CSRF_TOKEN_KEY);
      if (stored) {
        const tokenData = JSON.parse(stored);
        if (tokenData.expiresAt > Date.now()) {
          return tokenData.token;
        }
      }
    } catch (e) {
      // Ignore parsing errors
    }

    // Generate new token
    const token = generateSecureToken();
    const tokenData = {
      token,
      timestamp: Date.now(),
      expiresAt: Date.now() + TOKEN_EXPIRY_MS,
    };

    try {
      sessionStorage.setItem(CSRF_TOKEN_KEY, JSON.stringify(tokenData));
    } catch (e) {
      // Ignore storage errors
    }

    return token;
  }

  // ============================================
  // VALIDATION PATTERNS
  // ============================================

  const VALIDATION_PATTERNS = {
    email: /^[a-zA-Z0-9](?:[a-zA-Z0-9._%+-]*[a-zA-Z0-9])?@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\\\\.[a-zA-Z]{2,})+$/,
    phone: /^[\\\\d\\\\s\\\\-()]+$/,
    name: /^[\\\\p{L}\\\\p{M}][\\\\p{L}\\\\p{M}\\\\s\\\\-']*[\\\\p{L}\\\\p{M}]$|^[\\\\p{L}\\\\p{M}]$/u,
  };

  // ============================================
  // SANITIZATION FUNCTIONS
  // ============================================

  const HTML_ENTITIES = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#x27;',
    '/': '&#x2F;',
    '\\\`': '&#x60;',
    '=': '&#x3D;',
  };

  function sanitizeHTML(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/[&<>"'\\\`=/]/g, (char) => HTML_ENTITIES[char] || char);
  }

  function stripHTMLTags(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/<[^>]*>/g, '');
  }

  function sanitizeForDisplay(input) {
    if (typeof input !== 'string') return '';
    return sanitizeHTML(stripHTMLTags(input));
  }

  function sanitizePhone(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/[^\\\\d+\\\\-() ]/g, '').trim();
  }

  function sanitizeEmail(input) {
    if (typeof input !== 'string') return '';
    return input.toLowerCase().trim();
  }

  function sanitizeName(input) {
    if (typeof input !== 'string') return '';
    return input.replace(/[^\\\\p{L}\\\\p{M}\\\\s\\\\-']/gu, '').trim();
  }

  // ============================================
  // VALIDATION FUNCTIONS
  // ============================================

  function validateRequired(value) {
    const trimmed = value?.trim() || '';
    return {
      isValid: trimmed.length > 0,
      error: trimmed.length > 0 ? undefined : translations.required,
    };
  }

  function validateEmail(value) {
    if (!value || value.trim() === '') return { isValid: true };
    const sanitized = sanitizeEmail(value);
    const isValid = VALIDATION_PATTERNS.email.test(sanitized);
    return {
      isValid,
      error: isValid ? undefined : translations.invalidEmail,
    };
  }

  function validatePhone(value) {
    if (!value || value.trim() === '') return { isValid: true };
    const sanitized = sanitizePhone(value);
    if (!VALIDATION_PATTERNS.phone.test(sanitized)) {
      return { isValid: false, error: translations.invalidPhone };
    }
    const digitsOnly = sanitized.replace(/\\\\D/g, '');
    const isValidLength = digitsOnly.length >= 7 && digitsOnly.length <= 15;
    return {
      isValid: isValidLength,
      error: isValidLength ? undefined : translations.invalidPhone,
    };
  }

  function validateName(value) {
    if (!value || value.trim() === '') return { isValid: true };
    const sanitized = sanitizeName(value);
    const isValid = VALIDATION_PATTERNS.name.test(sanitized) && sanitized.length >= 1;
    return {
      isValid,
      error: isValid ? undefined : translations.invalidName,
    };
  }

  function validateMaxLength(value, maxLength) {
    const length = value?.length || 0;
    const isValid = length <= maxLength;
    return {
      isValid,
      error: isValid ? undefined : translations.tooLong,
    };
  }

  // ============================================
  // FORM VALIDATION
  // ============================================

  function validateField(fieldElement) {
    const fieldName = fieldElement.dataset.fieldName || '';
    const validationType = fieldElement.dataset.validationType || 'text';
    const isRequired = fieldElement.dataset.required === 'true';
    const input = fieldElement.querySelector('[data-input]');
    const errorMessage = fieldElement.querySelector('[data-error-message]');

    if (!input) return { isValid: true };

    const value = input.value;
    let result = { isValid: true };

    // Check required first
    if (isRequired) {
      result = validateRequired(value);
      if (!result.isValid) {
        showError(fieldElement, errorMessage, result.error || '');
        return result;
      }
    }

    // If empty and not required, it's valid
    if (!value || value.trim() === '') {
      clearError(fieldElement, errorMessage);
      return { isValid: true };
    }

    // Type-specific validation
    switch (validationType) {
      case 'email':
        result = validateEmail(value);
        break;
      case 'phone':
        result = validatePhone(value);
        break;
      case 'name':
        result = validateName(value);
        break;
      case 'text':
        result = validateMaxLength(value, 2000);
        break;
      case 'select':
        result = { isValid: true };
        break;
    }

    if (result.isValid) {
      showValid(fieldElement, errorMessage);
    } else {
      showError(fieldElement, errorMessage, result.error || '');
    }

    return result;
  }

  function showError(fieldElement, errorMessage, message) {
    fieldElement.classList.remove('is-valid');
    fieldElement.classList.add('has-error');
    if (errorMessage) {
      errorMessage.textContent = message;
    }
  }

  function showValid(fieldElement, errorMessage) {
    fieldElement.classList.remove('has-error');
    fieldElement.classList.add('is-valid');
    if (errorMessage) {
      errorMessage.textContent = '';
    }
  }

  function clearError(fieldElement, errorMessage) {
    fieldElement.classList.remove('has-error', 'is-valid');
    if (errorMessage) {
      errorMessage.textContent = '';
    }
  }

  function validateAllFields(form) {
    const fields = form.querySelectorAll('[data-form-field]');
    let allValid = true;

    fields.forEach((field) => {
      const result = validateField(field);
      if (!result.isValid) {
        allValid = false;
      }
    });

    return allValid;
  }

  function getFormData(form) {
    const formData = new FormData(form);
    const data = {};

    formData.forEach((value, key) => {
      if (typeof value === 'string') {
        switch (key) {
          case 'email':
            data[key] = sanitizeEmail(value);
            break;
          case 'phone':
          case 'whatsapp':
          case 'phone-country':
            data[key] = sanitizePhone(value);
            break;
          case 'firstName':
          case 'surname':
            data[key] = sanitizeName(value);
            break;
          default:
            data[key] = sanitizeForDisplay(value);
        }
      }
    });

    return data;
  }

  function showFormMessage(form, message, type) {
    let messageEl = form.querySelector('[data-form-message]');

    if (!messageEl) {
      messageEl = document.createElement('div');
      messageEl.setAttribute('data-form-message', '');
      messageEl.setAttribute('role', 'alert');
      messageEl.className = 'mt-4 p-4 rounded-md text-sm';
      form.appendChild(messageEl);
    }

    messageEl.textContent = message;
    messageEl.classList.remove('bg-green-50', 'text-green-800', 'bg-red-50', 'text-red-800', 'hidden');

    if (type === 'success') {
      messageEl.classList.add('bg-green-50', 'text-green-800');
    } else {
      messageEl.classList.add('bg-red-50', 'text-red-800');
    }
  }

  // ============================================
  // FORM INITIALIZATION
  // ============================================

  document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('contact-form');
    if (!form) return;

    let isSubmitting = false;

    // Attach blur event listeners for real-time validation
    const fields = form.querySelectorAll('[data-form-field]');
    fields.forEach((field) => {
      const input = field.querySelector('[data-input]');
      if (input) {
        input.addEventListener('blur', () => validateField(field));
        input.addEventListener('input', () => {
          if (field.classList.contains('has-error')) {
            validateField(field);
          }
        });
      }
    });

    // Handle form submission
    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      if (isSubmitting) return;

      // Validate all fields
      const isValid = validateAllFields(form);

      if (!isValid) {
        const firstError = form.querySelector('.has-error [data-input]');
        if (firstError) {
          firstError.focus();
        }
        return;
      }

      // Get sanitized form data
      const data = getFormData(form);

      // Show loading state
      isSubmitting = true;
      const submitButton = form.querySelector('button[type="submit"]');
      const originalButtonText = submitButton?.textContent || '';

      if (submitButton) {
        submitButton.disabled = true;
        submitButton.textContent = translations.submitting;
      }

      try {
        // Generate CSRF token
        const csrfToken = generateCSRFToken();

        const response = await fetch('/api/contact', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': csrfToken,
          },
          body: JSON.stringify(data),
        });

        if (response.ok) {
          showFormMessage(form, translations.formSuccess, 'success');
          form.reset();
          // Clear all validation states
          fields.forEach((field) => {
            const errorMessage = field.querySelector('[data-error-message]');
            clearError(field, errorMessage);
          });
        } else {
          const errorData = await response.json().catch(() => ({}));
          showFormMessage(form, errorData.message || translations.formError, 'error');
        }
      } catch (error) {
        console.error('Network error:', error);
        showFormMessage(form, translations.formError, 'error');
      } finally {
        isSubmitting = false;
        if (submitButton) {
          submitButton.disabled = false;
          submitButton.textContent = originalButtonText;
        }
      }
    });
  });
})();<\/script>`])), maybeRenderHead(), renderComponent($$result, "FormField", $$FormField, { "type": "text", "label": t.contact.form.firstName, "name": "firstName", "validationType": "name", "required": true }), renderComponent($$result, "FormField", $$FormField, { "type": "text", "label": t.contact.form.surname, "name": "surname", "validationType": "name", "required": true }), renderComponent($$result, "FormField", $$FormField, { "type": "phone", "label": t.contact.form.phone, "name": "phone", "required": true }), renderComponent($$result, "FormField", $$FormField, { "type": "email", "label": t.contact.form.email, "name": "email", "required": true }), renderComponent($$result, "FormField", $$FormField, { "type": "tel", "label": t.contact.form.whatsapp, "name": "whatsapp" }), renderComponent($$result, "FormField", $$FormField, { "type": "select", "label": t.contact.form.position, "name": "position", "options": positions }), renderComponent($$result, "FormField", $$FormField, { "type": "select", "label": t.contact.form.projectType, "name": "projectType", "options": projectTypes }), renderComponent($$result, "FormField", $$FormField, { "type": "select", "label": t.contact.form.budget, "name": "budget", "options": budgetRanges }), renderComponent($$result, "FormField", $$FormField, { "type": "select", "label": t.contact.form.consideration, "name": "consideration", "options": considerations }), renderComponent($$result, "FormField", $$FormField, { "type": "select", "label": t.contact.form.timeline, "name": "timeline", "options": timelines }), renderComponent($$result, "FormField", $$FormField, { "type": "textarea", "label": t.contact.form.remark, "name": "remark", "rows": 4, "maxLength": 2e3 }), t.contact.form.consent, renderComponent($$result, "Button", $$Button, { "type": "submit", "variant": "process", "class": "w-full sm:w-auto" }, { "default": async ($$result2) => renderTemplate`${t.contact.form.submit}` }), t.contact.title, t.contact.description, contactInfo.address.map((line) => renderTemplate`<p>${line}</p>`), contactInfo.phone.map((phone) => renderTemplate`<p>${phone}</p>`), addAttribute(`mailto:${contactInfo.email}`, "href"), contactInfo.email, contactInfo.socials.map((social) => renderTemplate`<a${addAttribute(social.url, "href")} target="_blank" rel="noopener noreferrer" class="flex items-center gap-4 hover:opacity-70 transition-opacity group"> <div class="w-8 h-8 flex items-center justify-center"> <img${addAttribute(`/images/Landing/${social.icon}.svg`, "src")}${addAttribute(social.name, "alt")} class="w-full h-full"> </div> <span class="text-gray-600 group-hover:text-bmg-primary transition-colors">${social.handle}</span> </a>`), defineScriptVars({ validationTranslations }));
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/Contact.astro", void 0);

export { $$Hero as $, $$Showcase as a, $$Process as b, $$PriceEstimation as c, $$TrustedCultures as d, $$Testimonials as e, $$Contact as f };
