import { e as createAstro, f as createComponent, m as maybeRenderHead, h as addAttribute, r as renderTemplate, k as renderComponent, l as renderScript } from '../chunks/astro/server_C-hQQPI9.mjs';
import 'piccolore';
import { u as useI18n, c as getLocalizedPath, $ as $$BaseLayout, a as $$Header, b as $$Footer } from '../chunks/Footer_BplOwl4A.mjs';
import { m as materialsData } from '../chunks/materials_-mZ1D3yF.mjs';
import 'clsx';
/* empty css                                     */
import { $ as $$MaterialCarousel } from '../chunks/MaterialCarousel_CdLwKCq-.mjs';
export { renderers } from '../renderers.mjs';

const $$Astro$6 = createAstro("https://bmg-granite.com");
const $$FilterSearch = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$6, $$props, $$slots);
  Astro2.self = $$FilterSearch;
  const { t } = useI18n(Astro2.url);
  return renderTemplate`${maybeRenderHead()}<div class="filter-search" data-astro-cid-m5ovb2pl> <label for="material-search" class="block text-sm font-medium text-gray-700 mb-2" data-astro-cid-m5ovb2pl> ${t.materials.filters.search} </label> <div class="relative" data-astro-cid-m5ovb2pl> <input type="text" id="material-search" class="w-full px-4 py-2.5 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-brand-primary text-sm"${addAttribute(t.materials.filters.searchPlaceholder, "placeholder")} data-filter-search data-astro-cid-m5ovb2pl> <button type="button" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 hidden" data-search-clear aria-label="Clear search" data-astro-cid-m5ovb2pl> <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" data-astro-cid-m5ovb2pl> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" data-astro-cid-m5ovb2pl></path> </svg> </button> <svg class="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24" data-search-icon data-astro-cid-m5ovb2pl> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" data-astro-cid-m5ovb2pl></path> </svg> </div> </div> `;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/materials/FilterSearch.astro", void 0);

const $$Astro$5 = createAstro("https://bmg-granite.com");
const $$FilterHeader = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$FilterHeader;
  const { t } = useI18n(Astro2.url);
  const totalMaterials = materialsData.categories.reduce(
    (acc, cat) => acc + cat.materials.length,
    0
  );
  return renderTemplate`${maybeRenderHead()}<div class="filter-header flex items-center justify-between mb-4 pb-4 border-b border-gray-200"> <div class="flex items-center gap-2"> <span class="text-sm text-gray-600" data-results-count> <span data-count>${totalMaterials}</span> ${t.materials.filters.results} </span> </div> <button type="button" class="text-sm text-brand-primary hover:text-brand-primary/80 font-medium hidden" data-clear-filters> ${t.materials.filters.clearAll} </button> </div>`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/materials/FilterHeader.astro", void 0);

const $$Astro$4 = createAstro("https://bmg-granite.com");
const $$FilterCheckboxGroup = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$FilterCheckboxGroup;
  const { title, filterKey, options, collapsible = true } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div class="filter-checkbox-group"${addAttribute(filterKey, "data-filter-group")} data-astro-cid-563xk6xt> <button type="button"${addAttribute([
    "flex items-center justify-between w-full text-sm font-medium text-gray-700 mb-3",
    collapsible && "cursor-pointer"
  ], "class:list")}${addAttribute(collapsible ? filterKey : void 0, "data-collapse-toggle")} aria-expanded="true" data-astro-cid-563xk6xt> <span data-astro-cid-563xk6xt>${title}</span> ${collapsible && renderTemplate`<svg class="w-4 h-4 transition-transform" data-collapse-icon fill="none" stroke="currentColor" viewBox="0 0 24 24" data-astro-cid-563xk6xt> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" data-astro-cid-563xk6xt></path> </svg>`} </button> <div class="space-y-2"${addAttribute(collapsible ? filterKey : void 0, "data-collapse-content")} data-astro-cid-563xk6xt> ${options.map((option) => renderTemplate`<label class="flex items-center gap-3 cursor-pointer group" data-astro-cid-563xk6xt> <input type="checkbox" class="w-4 h-4 text-brand-primary border-gray-300 rounded focus:ring-brand-primary focus:ring-2"${addAttribute(option.value, "value")}${addAttribute(filterKey, "data-filter-checkbox")} data-astro-cid-563xk6xt> <span class="text-sm text-gray-600 group-hover:text-gray-900" data-astro-cid-563xk6xt>${option.label}</span> </label>`)} </div> </div> `;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/materials/FilterCheckboxGroup.astro", void 0);

const $$Astro$3 = createAstro("https://bmg-granite.com");
const $$FilterColorSwatches = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$FilterColorSwatches;
  const { t } = useI18n(Astro2.url);
  const colors = materialsData.filterMetadata.colors;
  return renderTemplate`${maybeRenderHead()}<div class="filter-color-swatches" data-filter-group="colors" data-astro-cid-slyndlue> <span class="block text-sm font-medium text-gray-700 mb-3" data-astro-cid-slyndlue> ${t.materials.filters.color} </span> <div class="flex flex-wrap gap-2" data-astro-cid-slyndlue> ${colors.map((color) => renderTemplate`<button type="button" class="color-swatch relative w-8 h-8 rounded-full border-2 border-gray-200 hover:border-gray-400 transition-all focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-primary"${addAttribute(`background-color: ${color.hex};`, "style")}${addAttribute(color.id, "data-filter-color")}${addAttribute(t.materials.colors[color.id], "title")}${addAttribute(t.materials.colors[color.id], "aria-label")} data-astro-cid-slyndlue> <svg class="absolute inset-0 m-auto w-4 h-4 text-white opacity-0 transition-opacity check-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" data-astro-cid-slyndlue> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7" data-astro-cid-slyndlue></path> </svg> </button>`)} </div> </div> `;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/materials/FilterColorSwatches.astro", void 0);

const $$Astro$2 = createAstro("https://bmg-granite.com");
const $$FilterSidebar = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$FilterSidebar;
  const { t } = useI18n(Astro2.url);
  const tierOptions = [
    { value: "A++", label: "A++ - " + t.materials.categories["semi-precious"].title },
    { value: "A+", label: "A+ - " + t.materials.categories["luxury"].title },
    { value: "A", label: "A - " + t.materials.categories["classic"].title }
  ];
  const categoryOptions = [
    { value: "semi-precious", label: t.materials.categories["semi-precious"].title },
    { value: "luxury", label: t.materials.categories["luxury"].title },
    { value: "classic", label: t.materials.categories["classic"].title }
  ];
  const stoneTypeOptions = materialsData.filterMetadata.stoneTypes.map((type) => ({
    value: type,
    label: t.materials.stoneTypes[type]
  }));
  const originOptions = materialsData.filterMetadata.origins.map((origin) => ({
    value: origin.code,
    label: t.materials.origins[origin.code]
  }));
  return renderTemplate`<!-- Filter Toggle Button -->${maybeRenderHead()}<button type="button" class="inline-flex items-center gap-2 px-4 py-2.5 bg-white border border-gray-300 rounded-lg shadow-sm hover:bg-gray-50 transition-colors text-sm font-medium text-gray-700" data-filter-modal-toggle data-astro-cid-4kadxmgf> <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" data-astro-cid-4kadxmgf> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" data-astro-cid-4kadxmgf></path> </svg> <span data-astro-cid-4kadxmgf>${t.materials.filters.showFilters}</span> <span class="bg-brand-primary text-white text-xs font-bold px-2 py-0.5 rounded-full hidden" data-filter-badge data-astro-cid-4kadxmgf>0</span> </button> <!-- Modal Overlay --> <div class="fixed inset-0 bg-black/50 z-50 hidden opacity-0 transition-opacity duration-300" data-filter-modal-overlay data-astro-cid-4kadxmgf></div> <!-- Modal Container --> <div class="fixed inset-0 z-50 hidden items-center justify-center p-4" data-filter-modal-container data-astro-cid-4kadxmgf> <div class="filter-modal bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[85vh] flex flex-col transform scale-95 opacity-0 transition-all duration-300" data-filter-modal data-astro-cid-4kadxmgf> <!-- Modal Header --> <div class="flex items-center justify-between p-4 border-b border-gray-200" data-astro-cid-4kadxmgf> <h3 class="text-lg font-semibold text-gray-900" data-astro-cid-4kadxmgf>${t.materials.filters.title}</h3> <button type="button" class="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors" data-filter-modal-close data-astro-cid-4kadxmgf> <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" data-astro-cid-4kadxmgf> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" data-astro-cid-4kadxmgf></path> </svg> </button> </div> <!-- Modal Content (Scrollable) --> <div class="flex-1 overflow-y-auto p-4 space-y-6" data-astro-cid-4kadxmgf> ${renderComponent($$result, "FilterHeader", $$FilterHeader, { "data-astro-cid-4kadxmgf": true })} ${renderComponent($$result, "FilterSearch", $$FilterSearch, { "data-astro-cid-4kadxmgf": true })} <div class="border-t border-gray-200 pt-4" data-astro-cid-4kadxmgf> ${renderComponent($$result, "FilterCheckboxGroup", $$FilterCheckboxGroup, { "title": t.materials.filters.tier, "filterKey": "tiers", "options": tierOptions, "data-astro-cid-4kadxmgf": true })} </div> <div class="border-t border-gray-200 pt-4" data-astro-cid-4kadxmgf> ${renderComponent($$result, "FilterCheckboxGroup", $$FilterCheckboxGroup, { "title": t.materials.filters.category, "filterKey": "categories", "options": categoryOptions, "data-astro-cid-4kadxmgf": true })} </div> <div class="border-t border-gray-200 pt-4" data-astro-cid-4kadxmgf> ${renderComponent($$result, "FilterColorSwatches", $$FilterColorSwatches, { "data-astro-cid-4kadxmgf": true })} </div> <div class="border-t border-gray-200 pt-4" data-astro-cid-4kadxmgf> ${renderComponent($$result, "FilterCheckboxGroup", $$FilterCheckboxGroup, { "title": t.materials.filters.stoneType, "filterKey": "stoneTypes", "options": stoneTypeOptions, "data-astro-cid-4kadxmgf": true })} </div> <div class="border-t border-gray-200 pt-4" data-astro-cid-4kadxmgf> ${renderComponent($$result, "FilterCheckboxGroup", $$FilterCheckboxGroup, { "title": t.materials.filters.origin, "filterKey": "origins", "options": originOptions, "data-astro-cid-4kadxmgf": true })} </div> </div> <!-- Modal Footer --> <div class="p-4 border-t border-gray-200 flex gap-3" data-astro-cid-4kadxmgf> <button type="button" class="flex-1 px-4 py-2.5 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-colors" data-clear-filters data-astro-cid-4kadxmgf> ${t.materials.filters.clearAll} </button> <button type="button" class="flex-1 px-4 py-2.5 bg-brand-primary text-white rounded-lg font-medium hover:bg-brand-primary/90 transition-colors" data-filter-modal-apply data-astro-cid-4kadxmgf>
Apply Filters
</button> </div> </div> </div> `;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/materials/FilterSidebar.astro", void 0);

const $$Astro$1 = createAstro("https://bmg-granite.com");
const $$MaterialGrid = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$MaterialGrid;
  const { t, lang } = useI18n(Astro2.url);
  const allMaterials = materialsData.categories.flatMap(
    (category) => category.materials.map((material) => ({
      ...material,
      categoryId: category.id,
      tier: category.tier,
      name: t.materials.items[material.id]?.name || material.id,
      description: t.materials.items[material.id]?.description || ""
    }))
  );
  return renderTemplate`${maybeRenderHead()}<div class="material-grid-container" data-material-grid data-astro-cid-cytcc74z> <!-- No Results Message --> <div class="hidden text-center py-12" data-no-results data-astro-cid-cytcc74z> <svg class="w-16 h-16 mx-auto text-gray-300 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" data-astro-cid-cytcc74z> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" data-astro-cid-cytcc74z></path> </svg> <p class="text-gray-500 text-lg" data-astro-cid-cytcc74z>${t.materials.filters.noResults}</p> </div> <!-- Grid of Materials --> <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-6" data-grid-content data-astro-cid-cytcc74z> ${allMaterials.map((material) => renderTemplate`<a${addAttribute(getLocalizedPath(lang, `/materials/${material.id}`), "href")} class="material-grid-card group block bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300"${addAttribute(material.id, "data-material-id")}${addAttribute(material.categoryId, "data-category")}${addAttribute(material.tier, "data-tier")}${addAttribute(JSON.stringify(material.colors), "data-colors")}${addAttribute(material.stoneType, "data-stone-type")}${addAttribute(material.origin, "data-origin")}${addAttribute(material.name.toLowerCase(), "data-name")}${addAttribute(material.description.toLowerCase(), "data-description")} data-astro-cid-cytcc74z> <div class="aspect-[4/3] overflow-hidden" data-astro-cid-cytcc74z> <img${addAttribute(material.image, "src")}${addAttribute(material.name, "alt")} class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" loading="lazy" data-astro-cid-cytcc74z> </div> <div class="p-4" data-astro-cid-cytcc74z> <div class="flex items-start justify-between gap-2 mb-1" data-astro-cid-cytcc74z> <h3 class="font-semibold text-gray-800 group-hover:text-brand-primary transition-colors" data-astro-cid-cytcc74z> ${material.name} </h3> <span class="flex-shrink-0 text-xs font-bold px-2 py-1 bg-gray-100 text-gray-600 rounded" data-astro-cid-cytcc74z> ${material.tier} </span> </div> <p class="text-sm text-gray-500 line-clamp-2" data-astro-cid-cytcc74z> ${material.description} </p> </div> </a>`)} </div> </div> `;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/materials/MaterialGrid.astro", void 0);

const $$MaterialsFilterableContent = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<div class="materials-filterable-content"> <div class="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 lg:px-8"> <!-- Filter Button Row --> <div class="flex justify-end mb-6"> ${renderComponent($$result, "FilterSidebar", $$FilterSidebar, {})} </div> <!-- Content Area --> <div> <!-- Carousels (default view when no filters) --> <div data-carousels-container> ${materialsData.categories.map((category, index) => renderTemplate`${renderComponent($$result, "MaterialCarousel", $$MaterialCarousel, { "categoryId": category.id, "materials": category.materials, "index": index })}`)} </div> <!-- Grid (shown when filters are active) --> <div class="hidden"> ${renderComponent($$result, "MaterialGrid", $$MaterialGrid, {})} </div> </div> </div> </div> ${renderScript($$result, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/MaterialsFilterableContent.astro?astro&type=script&index=0&lang.ts")}`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/components/sections/MaterialsFilterableContent.astro", void 0);

const $$Astro = createAstro("https://bmg-granite.com");
const $$Materials = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Materials;
  const { lang, t } = useI18n(Astro2.url);
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": `${t.materials.pageTitle} | ${t.meta.title}`, "description": t.meta.description, "lang": lang }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "Header", $$Header, { "pageType": "project" })} ${maybeRenderHead()}<main> <!-- Hero Section --> <section id="materials-hero" class="relative h-[140px] sm:h-[160px] md:h-[180px] lg:h-[200px] pt-16 sm:pt-18 md:pt-20 lg:pt-24"> <div class="absolute inset-0 z-0"> <img src="/images/Product/7b7fd75f2e187f580cfdc947187b80e2a1b9669f.png"${addAttribute(t.materials.heroAlt, "alt")} class="w-full h-full object-cover" fetchpriority="high" loading="eager" decoding="async"> </div> </section> <!-- Page Title --> <div class="bg-white py-6 sm:py-8 md:py-10 lg:py-12"> <h1 class="text-3xl sm:text-4xl md:text-4xl lg:text-5xl font-semibold text-brand-primary text-center tracking-tight px-4"> ${t.materials.pageTitle} </h1> </div> <!-- Filterable Materials Content --> <div class="bg-white"> ${renderComponent($$result2, "MaterialsFilterableContent", $$MaterialsFilterableContent, {})} </div> </main> ${renderComponent($$result2, "Footer", $$Footer, {})} ` })}`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/pages/materials.astro", void 0);

const $$file = "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/pages/materials.astro";
const $$url = "/materials";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Materials,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
