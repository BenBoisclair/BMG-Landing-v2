import { e as createAstro, f as createComponent, k as renderComponent, r as renderTemplate, m as maybeRenderHead } from '../../chunks/astro/server_BuHVecmu.mjs';
import 'piccolore';
import { g as getTranslations, $ as $$BaseLayout, d as defaultLang, a as $$Header, b as $$Footer } from '../../chunks/Footer_D-I_vCZH.mjs';
import { $ as $$ProjectDetailHero, a as $$ProjectDetailContent, b as $$ProjectDetailGallery, c as $$RelatedProjects } from '../../chunks/RelatedProjects_CLM58_vA.mjs';
import { p as projectsData } from '../../chunks/projects__2OPjxaC.mjs';
export { renderers } from '../../renderers.mjs';

const $$Astro = createAstro("https://bmg-granite.com");
function getStaticPaths() {
  const allProjects = projectsData.projectTypes.flatMap((type) => type.projects);
  return allProjects.map((project) => ({
    params: { slug: project.id },
    props: { project }
  }));
}
const $$slug = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$slug;
  const { slug } = Astro2.params;
  const { project } = Astro2.props;
  const t = getTranslations(defaultLang);
  const projectTranslations = t.project.projects;
  const projectContent = projectTranslations[project.id] || {
    name: project.id,
    artTitle: project.id,
    description: "",
    material: "",
    customer: "",
    location: ""
  };
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": `${projectContent.name} | ${t.meta.title}`, "description": projectContent.description.slice(0, 160), "lang": defaultLang }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "Header", $$Header, { "pageType": "project" })} ${maybeRenderHead()}<main> ${renderComponent($$result2, "ProjectDetailHero", $$ProjectDetailHero, { "heroImage": project.heroImage, "projectName": projectContent.name })} ${renderComponent($$result2, "ProjectDetailContent", $$ProjectDetailContent, { "artTitle": projectContent.artTitle, "description": projectContent.description, "material": projectContent.material, "customer": projectContent.customer, "location": projectContent.location })} ${renderComponent($$result2, "ProjectDetailGallery", $$ProjectDetailGallery, { "images": project.gallery, "projectName": projectContent.name })} ${renderComponent($$result2, "RelatedProjects", $$RelatedProjects, { "currentProjectId": project.id })} </main> ${renderComponent($$result2, "Footer", $$Footer, {})} ` })}`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/pages/projects/[slug].astro", void 0);

const $$file = "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/pages/projects/[slug].astro";
const $$url = "/projects/[slug]";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$slug,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
