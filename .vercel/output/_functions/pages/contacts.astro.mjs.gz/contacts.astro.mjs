import { e as createAstro, f as createComponent, k as renderComponent, r as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_DN3y_WhJ.mjs';
import 'piccolore';
import { u as useI18n, $ as $$BaseLayout, a as $$Header, b as $$Footer } from '../chunks/Footer_B0yHRcuM.mjs';
import { $ as $$ContactPageHero } from '../chunks/ContactPageHero_BkiS_vvw.mjs';
import { $ as $$Contact } from '../chunks/Contact_Dl0YxdaR.mjs';
export { renderers } from '../renderers.mjs';

const $$Astro = createAstro("https://bmg-granite.com");
const $$Contacts = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Contacts;
  const { lang, t } = useI18n(Astro2.url);
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": `${t.contactPage.title} | ${t.meta.title}`, "description": t.contact.description, "lang": lang }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "Header", $$Header, { "pageType": "process" })} ${maybeRenderHead()}<main> ${renderComponent($$result2, "ContactPageHero", $$ContactPageHero, {})} ${renderComponent($$result2, "Contact", $$Contact, {})} </main> ${renderComponent($$result2, "Footer", $$Footer, {})} ` })}`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/pages/contacts.astro", void 0);

const $$file = "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/pages/contacts.astro";
const $$url = "/contacts";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Contacts,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
