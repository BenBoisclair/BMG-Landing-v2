import { e as createAstro, f as createComponent, k as renderComponent, r as renderTemplate, m as maybeRenderHead } from '../../../chunks/astro/server_BuHVecmu.mjs';
import 'piccolore';
import { g as getTranslations, $ as $$BaseLayout, a as $$Header, b as $$Footer } from '../../../chunks/Footer_D-I_vCZH.mjs';
import { $ as $$MaterialDetailHero, a as $$MaterialDetailContent, b as $$MaterialDetailGallery, c as $$RelatedMaterials } from '../../../chunks/RelatedMaterials_CIoZmzhX.mjs';
import { m as materialsData } from '../../../chunks/materials_sbYiLFEh.mjs';
export { renderers } from '../../../renderers.mjs';

const $$Astro = createAstro("https://bmg-granite.com");
function getStaticPaths() {
  const allMaterials = materialsData.categories.flatMap(
    (cat) => cat.materials.map((m) => ({
      ...m,
      category: cat.id
    }))
  );
  return allMaterials.map((material) => ({
    params: { id: material.id },
    props: { material }
  }));
}
const $$id = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$id;
  const lang = "th";
  const { id } = Astro2.params;
  const { material } = Astro2.props;
  const t = getTranslations(lang);
  const materialTranslations = t.materials.items;
  const materialContent = materialTranslations[material.id] || {
    name: material.id,
    description: ""
  };
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": `${materialContent.name} | ${t.meta.title}`, "description": materialContent.description.slice(0, 160), "lang": lang }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "Header", $$Header, { "pageType": "project" })} ${maybeRenderHead()}<main> ${renderComponent($$result2, "MaterialDetailHero", $$MaterialDetailHero, { "heroImage": material.heroImage, "materialName": materialContent.name })} ${renderComponent($$result2, "MaterialDetailContent", $$MaterialDetailContent, { "artTitle": materialContent.name, "description": materialContent.description })} ${renderComponent($$result2, "MaterialDetailGallery", $$MaterialDetailGallery, { "images": material.gallery, "materialName": materialContent.name })} ${renderComponent($$result2, "RelatedMaterials", $$RelatedMaterials, { "currentMaterialId": material.id, "currentCategory": material.category })} </main> ${renderComponent($$result2, "Footer", $$Footer, {})} ` })}`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/pages/th/materials/[id].astro", void 0);

const $$file = "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/pages/th/materials/[id].astro";
const $$url = "/th/materials/[id]";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$id,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
