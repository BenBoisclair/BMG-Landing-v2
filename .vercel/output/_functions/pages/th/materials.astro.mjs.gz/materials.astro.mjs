import { e as createAstro, f as createComponent, r as renderTemplate, l as defineScriptVars, k as renderComponent, m as maybeRenderHead, h as addAttribute } from '../../chunks/astro/server_DN3y_WhJ.mjs';
import 'piccolore';
import { u as useI18n, $ as $$BaseLayout, a as $$Header, b as $$Footer } from '../../chunks/Footer_B0yHRcuM.mjs';
import { $ as $$MaterialsTabs, a as $$MaterialsFilter, b as $$MaterialsGrid } from '../../chunks/MaterialsGrid_8srysWiB.mjs';
import { m as materialsData } from '../../chunks/materials_BRasuCpm.mjs';
/* empty css                                        */
export { renderers } from '../../renderers.mjs';

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Astro = createAstro("https://bmg-granite.com");
const $$Materials = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Materials;
  const { lang, t } = useI18n(Astro2.url);
  const categories = materialsData.categories.map((cat) => ({
    id: cat.id,
    tier: cat.tier,
    label: t.materials.categoryLabels?.[cat.id] || cat.label
  }));
  return renderTemplate(_a || (_a = __template(["", " <script>(function(){", "\n  function initMaterialsPage() {\n    const categoryLabel = document.querySelector('.category-label');\n    const panels = document.querySelectorAll('.materials-panel');\n\n    // Handle tab changes\n    document.addEventListener('materials-tab-change', (e) => {\n      const { categoryId, categoryLabel: label } = e.detail;\n\n      // Update category label\n      if (categoryLabel) {\n        categoryLabel.textContent = label;\n      }\n\n      // Show/hide panels\n      panels.forEach((panel) => {\n        const panelCategory = panel.getAttribute('data-category');\n        if (panelCategory === categoryId) {\n          panel.classList.remove('hidden');\n        } else {\n          panel.classList.add('hidden');\n        }\n      });\n    });\n\n    // Handle filter changes (placeholder - can be expanded later)\n    document.addEventListener('materials-filter-change', (e) => {\n      const { filterId } = e.detail;\n      console.log('Filter changed:', filterId);\n    });\n  }\n\n  // Initialize on page load\n  initMaterialsPage();\n\n  // Re-initialize on Astro page transitions\n  document.addEventListener('astro:page-load', initMaterialsPage);\n})();<\/script> "])), renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": `${t.materials.pageTitle} | ${t.meta.title}`, "description": t.meta.description, "lang": lang, "data-astro-cid-6p3af5fk": true }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "Header", $$Header, { "pageType": "project", "data-astro-cid-6p3af5fk": true })} ${maybeRenderHead()}<main class="pt-28 pb-16 bg-white min-h-screen" data-astro-cid-6p3af5fk> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" data-astro-cid-6p3af5fk> <!-- Top Navigation Bar --> <div class="flex justify-center items-center mb-10 relative" data-astro-cid-6p3af5fk> ${renderComponent($$result2, "MaterialsTabs", $$MaterialsTabs, { "categories": categories, "data-astro-cid-6p3af5fk": true })} <!-- Filter Button - Positioned absolutely on the right --> <div class="absolute right-0 top-1/2 -translate-y-1/2 hidden lg:block" data-astro-cid-6p3af5fk> ${renderComponent($$result2, "MaterialsFilter", $$MaterialsFilter, { "data-astro-cid-6p3af5fk": true })} </div> </div> <!-- Mobile Filter Button --> <div class="flex justify-end mb-6 lg:hidden" data-astro-cid-6p3af5fk> ${renderComponent($$result2, "MaterialsFilter", $$MaterialsFilter, { "data-astro-cid-6p3af5fk": true })} </div> <!-- Category Label --> <h2 class="category-label text-lg font-semibold text-[#293039] mb-6"${addAttribute(categories[0]?.label, "data-default-label")} data-astro-cid-6p3af5fk> ${categories[0]?.label} </h2> <!-- Materials Grids (one per category, hidden/shown via JS) --> ${materialsData.categories.map((category, index) => renderTemplate`<div${addAttribute([
    "materials-panel",
    index !== 0 && "hidden"
  ], "class:list")}${addAttribute(`panel-${category.id}`, "id")}${addAttribute(category.id, "data-category")} role="tabpanel"${addAttribute(`tab-${category.id}`, "aria-labelledby")} data-astro-cid-6p3af5fk> ${renderComponent($$result2, "MaterialsGrid", $$MaterialsGrid, { "materials": category.materials, "categoryId": category.id, "data-astro-cid-6p3af5fk": true })} </div>`)} </div> </main> ${renderComponent($$result2, "Footer", $$Footer, { "data-astro-cid-6p3af5fk": true })} ` }), defineScriptVars({ categories }));
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/pages/th/materials.astro", void 0);

const $$file = "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/pages/th/materials.astro";
const $$url = "/th/materials";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Materials,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
