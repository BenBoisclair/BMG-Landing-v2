import { e as createAstro, f as createComponent, k as renderComponent, r as renderTemplate, m as maybeRenderHead, h as addAttribute } from '../../chunks/astro/server_C-hQQPI9.mjs';
import 'piccolore';
import { u as useI18n, $ as $$BaseLayout, a as $$Header, b as $$Footer } from '../../chunks/Footer_BplOwl4A.mjs';
import { $ as $$MaterialCarousel } from '../../chunks/MaterialCarousel_CdLwKCq-.mjs';
import { m as materialsData } from '../../chunks/materials_-mZ1D3yF.mjs';
export { renderers } from '../../renderers.mjs';

const $$Astro = createAstro("https://bmg-granite.com");
const $$Materials = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Materials;
  const { lang, t } = useI18n(Astro2.url);
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": `${t.materials.pageTitle} | ${t.meta.title}`, "description": t.meta.description, "lang": lang }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "Header", $$Header, { "pageType": "project" })} ${maybeRenderHead()}<main> <!-- Hero Section --> <section id="materials-hero" class="relative h-[200px] pt-20 lg:pt-24"> <div class="absolute inset-0 z-0"> <img src="/images/Product/7b7fd75f2e187f580cfdc947187b80e2a1b9669f.png"${addAttribute(t.materials.heroAlt, "alt")} class="w-full h-full object-cover" fetchpriority="high" loading="eager" decoding="async"> </div> </section> <!-- Page Title --> <div class="bg-white py-8 lg:py-12"> <h1 class="text-4xl lg:text-5xl font-semibold text-brand-primary text-center tracking-tight"> ${t.materials.pageTitle} </h1> </div> <!-- Material Carousels by Category --> <div class="bg-white"> ${materialsData.categories.map((category, index) => renderTemplate`${renderComponent($$result2, "MaterialCarousel", $$MaterialCarousel, { "categoryId": category.id, "materials": category.materials, "index": index })}`)} </div> </main> ${renderComponent($$result2, "Footer", $$Footer, {})} ` })}`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/pages/th/materials.astro", void 0);

const $$file = "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/pages/th/materials.astro";
const $$url = "/th/materials";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Materials,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
