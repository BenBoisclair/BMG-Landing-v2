import { c as createAstro, a as createComponent, r as renderComponent, b as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_Dl93DeC-.mjs';
import 'piccolore';
import { u as useI18n, $ as $$BaseLayout, a as $$Header, b as $$Footer } from '../chunks/Footer_DNsX0YeG.mjs';
import { $ as $$Hero, a as $$Showcase, b as $$Process, c as $$PriceEstimation, d as $$TrustedCultures, e as $$Testimonials, f as $$Contact } from '../chunks/Contact_B4g19rat.mjs';
export { renderers } from '../renderers.mjs';

const $$Astro = createAstro("https://bmg-granite.com");
const $$Index = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Index;
  const { lang, t } = useI18n(Astro2.url);
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": t.meta.title, "description": t.meta.description, "lang": lang }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "Header", $$Header, {})} ${maybeRenderHead()}<main> ${renderComponent($$result2, "Hero", $$Hero, {})} ${renderComponent($$result2, "Showcase", $$Showcase, {})} ${renderComponent($$result2, "Process", $$Process, {})} ${renderComponent($$result2, "PriceEstimation", $$PriceEstimation, {})} ${renderComponent($$result2, "TrustedCultures", $$TrustedCultures, {})} ${renderComponent($$result2, "Testimonials", $$Testimonials, {})} ${renderComponent($$result2, "Contact", $$Contact, {})} </main> ${renderComponent($$result2, "Footer", $$Footer, {})} ` })}`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/pages/ar/index.astro", void 0);

const $$file = "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/pages/ar/index.astro";
const $$url = "/ar";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
