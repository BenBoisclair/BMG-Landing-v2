import { e as createAstro, f as createComponent, k as renderComponent, r as renderTemplate, m as maybeRenderHead } from '../../chunks/astro/server_C-hQQPI9.mjs';
import 'piccolore';
import { u as useI18n, $ as $$BaseLayout, a as $$Header, b as $$Footer } from '../../chunks/Footer_BplOwl4A.mjs';
import { $ as $$ProjectHero, a as $$ProjectGrid } from '../../chunks/ProjectGrid_DaoB107s.mjs';
export { renderers } from '../../renderers.mjs';

const $$Astro = createAstro("https://bmg-granite.com");
const $$Index = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Index;
  const { lang, t } = useI18n(Astro2.url);
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": `${t.project.title} | ${t.meta.title}`, "description": t.meta.description, "lang": lang }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "Header", $$Header, { "pageType": "project" })} ${maybeRenderHead()}<main> ${renderComponent($$result2, "ProjectHero", $$ProjectHero, {})} ${renderComponent($$result2, "ProjectGrid", $$ProjectGrid, {})} </main> ${renderComponent($$result2, "Footer", $$Footer, {})} ` })}`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/pages/ar/projects/index.astro", void 0);

const $$file = "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/pages/ar/projects/index.astro";
const $$url = "/ar/projects";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
