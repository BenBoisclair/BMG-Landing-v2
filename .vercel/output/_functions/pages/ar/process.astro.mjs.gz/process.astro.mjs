import { c as createAstro, a as createComponent, r as renderComponent, b as renderTemplate, m as maybeRenderHead } from '../../chunks/astro/server_Dl93DeC-.mjs';
import 'piccolore';
import { u as useI18n, $ as $$BaseLayout, a as $$Header, b as $$Footer } from '../../chunks/Footer_NnoDF9yt.mjs';
import { $ as $$ProcessPageHero, a as $$ProcessPageSteps } from '../../chunks/ProcessPageSteps_CdIB3l_J.mjs';
export { renderers } from '../../renderers.mjs';

const $$Astro = createAstro("https://bmg-granite.com");
const $$Process = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Process;
  const { lang, t } = useI18n(Astro2.url);
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": `${t.processPage.title} | ${t.meta.title}`, "description": t.meta.description, "lang": lang }, { "default": ($$result2) => renderTemplate` ${renderComponent($$result2, "Header", $$Header, { "pageType": "process" })} ${maybeRenderHead()}<main> ${renderComponent($$result2, "ProcessPageHero", $$ProcessPageHero, {})} ${renderComponent($$result2, "ProcessPageSteps", $$ProcessPageSteps, {})} </main> ${renderComponent($$result2, "Footer", $$Footer, {})} ` })}`;
}, "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/pages/ar/process.astro", void 0);

const $$file = "/Users/benedictboisclair/Projects/BMG-Landing-v2/src/pages/ar/process.astro";
const $$url = "/ar/process";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Process,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
